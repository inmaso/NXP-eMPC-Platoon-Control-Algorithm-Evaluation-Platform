function []=comfort_analysis(a1,a2,a3,a4)
j1=jerkiness(a1);
j2=jerkiness(a2);
j3=jerkiness(a3);
j4=jerkiness(a4);

acc1=x_acc(a1);
acc2=x_acc(a2);
acc3=x_acc(a3);
acc4=x_acc(a4);

un1=uneven_speed(a1);
un2=uneven_speed(a2);
un3=uneven_speed(a3);
un4=uneven_speed(a4);

jerk=[j1;j2;j3;j4]
acceleration=[acc1;acc2;acc3;acc4]
uneven=[un1;un2;un3;un4]
end

function [j]=jerkiness(a)
value=80; %from 0 to 100
jerk=sort(abs(a(:,5)));
%j=mean(jerk); %Average of absolute jerk
%j=max(jerk); %Maximum absolute jerk
%j=prctile(jerk,value); %80th percentile
j=mean(jerk(ceil(length(jerk)*value/100):length(jerk))); %Average of the highest
%values

end

function [j]=x_acc(a)
value=80; %from 0 to 100
%acc=sort(abs(a(:,4)));
%j=mean(acc); %Average of absolute acc
%j=max(acc); %Maximum absolute acc
%j=prctile(acc,value); %80th percentile
%j=mean(acc(ceil(length(acc)*value/100):length(acc))); %Average of the highest
j=rms(a(:,4));
%values

end

function [res]=uneven_speed(a)
res=0;
index=1;
depth(index)=0;
vel=a(:,3);
window=250; %Window size is 50 * size in seconds 
peaks(1)=vel(1);
valleys(1)=vel(1);
for i=2:length(vel)
    if vel(i)>vel(i-1)
        peaks(i)=vel(i);
        peaks(i-1)=0;
    else
        peaks(i)=0;
    end
    if vel(i)<vel(i-1)
        valleys(i)=vel(i);
        valleys(i-1)=0;
    else
        valleys(i)=0;
    end
end
for i=1:length(vel)
    if peaks(i)~=0
        slicep=peaks(i+1:min(i+window,length(peaks)));
        slicev=valleys(i+1:min(i+window,length(peaks)));
        for j=1:length(slicev)
            if slicev(j)~=0 && max(slicep(j:length(slicep)))~=0
                depth(index)=min(max(slicep(j:length(slicep)))-slicev(j),peaks(i)-slicev(j));
                index=index+1;
            end
        end
    end
end
res=max(depth);
end


