function power_analysis(prl,prf,p1,p2,p3,p4)
    [inrl,warl]=energy_in(prl);
    [inrf,warf]=energy_in(prf);
    [in1,wa1]=energy_in(p1);
    [in2,wa2]=energy_in(p2);
    [in3,wa3]=energy_in(p3);
    [in4,wa4]=energy_in(p4);
    if warf==0
        warf=0.0001;
    end
    if warl==0
        warl=0.0001;
    end
    red_in=[in1/inrl;in2/inrf;in3/inrf;in4/inrf]
    red_wa=[wa1/warl;wa2/warf;wa3/warf;wa4/warf]
    
    lit_rf=E2L(inrf);
    lit_rl=E2L(inrl);
    lit_1=E2L(in1);
    lit_2=E2L(in2);
    lit_3=E2L(in3);
    lit_4=E2L(in4);
    
    liters_consumed_each=[lit_1;lit_2;lit_3;lit_4]
    liters_saved_each=[lit_rl-lit_1;lit_rf-lit_2;lit_rf-lit_3;lit_rf-lit_4]
    
end

function [liters]=E2L(energy)
    efficiency=0.45;%Based on literature 0.45 is reasonable
    density=0.846; %In kg/l
    calorific_power=45*10e6; %In J/kg
    
    energy_consumed=energy/efficiency;
    kilos=energy_consumed/calorific_power;
    liters=kilos/density;
end