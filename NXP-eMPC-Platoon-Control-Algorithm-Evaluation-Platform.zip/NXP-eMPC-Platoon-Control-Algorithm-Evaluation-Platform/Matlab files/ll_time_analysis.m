%%Extended timings
a=a4;
times=[];
for i=1:length(a)
    times=[times a(i,21:29) a(i,1)];
end

for i=1:length(times)-1
    diff(i)=times(i+1)-times(i);
end
hold on
plot(diff)
