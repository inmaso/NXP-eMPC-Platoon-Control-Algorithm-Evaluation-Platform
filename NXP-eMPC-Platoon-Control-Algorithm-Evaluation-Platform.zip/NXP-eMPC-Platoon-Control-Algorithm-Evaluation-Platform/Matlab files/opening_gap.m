% for i=1:320
%     mass(i)=3900+i*100;
%     for j=1:22
%         speed(j)=5+j*5;
%         res(i,j)=resistance(speed(j),10,mass(i));
%     end
% end
% mesh(mass,speed,res')
clear all
gap=10;
speed_pred=80;
speed=speed_pred;
mass=36000;
dt=0.0001;
t=0;
i=0;
a=0;
aconst=0.187;
while (gap<100)
    i=i+1;
    gap=gap+(speed_pred-speed)*dt+a*dt^2;
    speed=speed+a*dt;
    f=resistance(speed,10,mass);
    a=-(f/mass+aconst);
    t=t+dt;
    time(i)=t;
    g(i)=gap;
    v(i)=speed;
    acc(i)=-a;
end
t
gap
figure;
yyaxis left
plot(time,g);
hold on
plot(time,v);
yyaxis right
plot(time,acc);