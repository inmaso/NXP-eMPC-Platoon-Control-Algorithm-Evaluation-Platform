/**
 *
 * @section nxp_llc_examples LLC application
 *
 * @file
 * ex_chconfig: user space module
 *
 */

//------------------------------------------------------------------------------
// Copyright (c) 2015 NXP Semiconductors
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Included headers
//------------------------------------------------------------------------------
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "debug-levels.h"
#include <linux/cohda/llc/llc.h>

//------------------------------------------------------------------------------
// Macros & Constants
//------------------------------------------------------------------------------
#ifndef LLC_NO_BITFIELDS
/// Broadcast address field entry
tMKxAddressMatching AMS_Broadcast = {
    .Mask = 0xFFFFFFFFFFFF, .Addr = 0xFFFFFFFFFFFF, .MatchCtrl = 2};
/// Multicast address field entry
tMKxAddressMatching AMS_Multicast = {
    .Mask = 0xFFFFFFFFFFFF, .Addr = 0x000000000000, .MatchCtrl = 2};
/// Promiscuous address field entry
tMKxAddressMatching AMS_Promiscuous = {
    .Mask = 0x000000000000, .Addr = 0x000000000000, .MatchCtrl = 6};
#else
tMKxAddressMatching AMS_Broadcast = {
    .Mask = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
.Addr = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
.MatchCtrl = 2;
}
;
tMKxAddressMatching AMS_Multicast = {
    .Mask = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
.Addr = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
.MatchCtrl = 2;
}
;
tMKxAddressMatching AMS_Promiscuous = {
    .Mask = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
.Addr = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
.MatchCtrl = 6;
}
;
#endif

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// External Function definition
//------------------------------------------------------------------------------
/// MKx LLCRemote configure function
extern fMKx_Config LLC_Config;

//------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------
void ex_SetMode(struct MKx *pMKx, tMKxRadio Radio, tMKxRadioMode Mode);
void ex_ChConfig_SingleChannelRadio(struct MKx *pMKx, tMKxRadio Radio,
                                    uint16_t ChannelNo, uint8_t power);
void ex_ChConfig_Enablecast(struct MKx *pMKx, tMKxRadio Radio, uint8_t AMSIndex,
                            uint64_t UnicastMAC, uint64_t mask, uint8_t match);

//------------------------------------------------------------------------------
// Functions definitions
//------------------------------------------------------------------------------

/**
 * @brief ex_ChConfig_SingleChannelRadio configure single channel mode
 * @param pMKx      - pointer to device stucture
 * @param Radio     - radio selection
 * @param ChannelNo - channel
 * @param power     - defaultTX power (used for ACK/CTS)
 */
void ex_ChConfig_SingleChannelRadio(struct MKx *pMKx, tMKxRadio Radio,
                                    uint16_t ChannelNo, uint8_t power) {
  tMKxRadioConfig RadioCfg; // uninitialized Msg structure
  tMKxAntenna Antenna;

  d_fnstart(D_API, NULL, "(pMKx %p)\n", pMKx);

  Antenna = (Radio == MKX_RADIO_A) ? MKX_ANT_1 : MKX_ANT_2;

  // Fill private RadioCfg.RadioConfigData structure with current Radio A
  // configuration
  memcpy(&(RadioCfg.RadioConfigData), &(pMKx->Config.Radio[Radio]),
         sizeof(tMKxRadioConfigData));

  // Modify PHY Frequency for Channel_0 / Channel_1
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0].PHY.ChannelFreq =
      5000 + (ChannelNo * 5);
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0].PHY.TxAntenna = Antenna;
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0].PHY.RxAntenna = Antenna;
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0].PHY.DefaultTxPower = power;

  // Set Mode to CHANNEL_O switching
  RadioCfg.RadioConfigData.Mode = MKX_MODE_CHANNEL_0;

  // Apply configuration to specified radio
  LLC_Config(pMKx, Radio, &RadioCfg);

  d_fnend(D_API, NULL, "(pMKx %p)\n", pMKx);
}

/**
 * @brief ex_ChConfig_Enablecast, fill MAC-AMS table
 * @param pMKx       - pointer to device stucture
 * @param Radio      - radio selection
 * @param AMSIndex   - table index to fill
 * @param UnicastMAC - MAC address
 * @param mask       - mask
 * @param match      - match control
 */
void ex_ChConfig_Enablecast(struct MKx *pMKx, tMKxRadio Radio, uint8_t AMSIndex,
                            uint64_t UnicastMAC, uint64_t mask, uint8_t match) {
  tMKxRadioConfig RadioCfg; // uninitialized Msg structure

  d_fnstart(D_API, NULL, "(pMKx %p)\n", pMKx);

  // Fill private RadioCfg.RadioConfigData structure with current Radio A
  // configuration
  memcpy(&(RadioCfg.RadioConfigData), &(pMKx->Config.Radio[Radio]),
         sizeof(tMKxRadioConfigData));

  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0]
      .MAC.AMSTable[AMSIndex]
      .Addr = UnicastMAC;
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0]
      .MAC.AMSTable[AMSIndex]
      .Mask = mask;
  RadioCfg.RadioConfigData.ChanConfig[MKX_CHANNEL_0]
      .MAC.AMSTable[AMSIndex]
      .MatchCtrl = match;

  // Apply configuration for Radio
  LLC_Config(pMKx, Radio, &RadioCfg);

  d_fnend(D_API, NULL, "(pMKx %p)\n", pMKx);
}

/**
 * @brief ex_SetMode, configure Radio
 * @param pMKx  - pointer to device stucture
 * @param Radio - select radio A (=0) or B (=1)
 * @param Mode  - mode of radio
 */
void ex_SetMode(struct MKx *pMKx, tMKxRadio Radio, tMKxRadioMode Mode) {
  // Register local instance of API.Functions.Config (=assign function pointer)
  tMKxRadioConfig RadioCfg; // uninitialized Msg structure

  d_fnstart(D_API, NULL, "(pMKx %p, Radio %d, Mode %d)\n", pMKx, Radio, Mode);

  // Fill RadioCfg.RadioConfigData structure with indicated Radio configuration
  memcpy(&(RadioCfg.RadioConfigData), &(pMKx->Config.Radio[Radio]),
         sizeof(tMKxRadioConfigData));

  // Set new Radio Mode:
  RadioCfg.RadioConfigData.Mode = Mode;

  d_printf(D_INFO, NULL, " Calling API.Functions.Config - Radio %d\n", Radio);
  LLC_Config(pMKx, Radio, &RadioCfg);

  // Note, reading back this structure will only display what the Host considers
  // to be the active Radio Channel configuration. If the LLC_Config call failed
  // with an error (or got Error notification back), this structure will not be
  // up to date. To get current state, we need to send message with
  // Type=MKXIF_DEBUG, and DebugMsgData.Type = MKXDEBUG_RADIO_CONFIG and
  //  DebugMsgData.SubType = MKXDEBUG_SPECIFIC_DEBUG_RADIO_BOTH. The Response
  //  would have to be parsed in D4S_DebugInd.
  // Currently header file <llc-dbg.h> is not included in this package.

  d_fnend(D_API, NULL, "(pMKx %p)\n", pMKx);
}
