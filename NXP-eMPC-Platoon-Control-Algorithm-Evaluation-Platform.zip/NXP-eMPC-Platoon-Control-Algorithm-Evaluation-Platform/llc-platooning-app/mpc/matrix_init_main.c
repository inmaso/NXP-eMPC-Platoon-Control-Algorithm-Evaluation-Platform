/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main.c
 *
 * Code generation for function 'main'
 *
 */

/*************************************************************************/
/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/
/* Include files */
#include "rt_nonfinite.h"
#include "matrix_init.h"
#include "main.h"
#include "matrix_init_terminate.h"
#include "matrix_init_emxAPI.h"
#include "matrix_init_initialize.h"

/* Function Declarations */
static void argInit_1x2_real_T(double result[2]);
static double argInit_real_T(void);
static void main_matrix_init(void);

/* Function Definitions */
static void printColumn(emxArray_real_T* var){
	int i;
	printf("\n");
	for (i=0; i<*(var->size); i++){
		printf("%f\n",*(var->data+i));
	}
}

static void printColumn_std(double* var, int l){
	int i;
	printf("\n");
	for (i=0; i<l; i++){
		printf("%f\n",*(var+i));
	}
}

static void argInit_1x2_real_T(double result[2])
{
  result[0] = K1;
	result[1] = K2;

}

static void main_matrix_init(void)
{
  emxArray_real_T *G;
  emxArray_real_T *twoGamaQ_barfi;
  emxArray_real_T *twoGamaQ_barpsi;
  emxArray_real_T *L;
  emxArray_real_T *w;
  emxArray_real_T *Mpsi;
  emxArray_real_T *c;
  double dv4[2];
  emxInitArray_real_T(&G, 2);
  emxInitArray_real_T(&twoGamaQ_barfi, 2);
  emxInitArray_real_T(&twoGamaQ_barpsi, 2);
  emxInitArray_real_T(&L, 2);
  emxInitArray_real_T(&w, 2);
  emxInitArray_real_T(&Mpsi, 2);
  emxInitArray_real_T(&c, 1);
	double F[15];
  double bi[160];
	double twoGamaQ_barfi_array[60];
  double twoGamaQ_barpsi_array[225];
  double w_array[640];
  double Mpsi_array[2400];
  double c_array[160];
	double L_array[2700];
	double q0=95;
	double v0=2;
	double a0=0;
	double da0=0;
	double qTarget=100;
	double vTarget=2;
	double aTarget=0;
	double d0=5;
  /* Initialize function 'matrix_init' input arguments. */
  /* Initialize function input argument 'k1'. */
  /* Call the entry-point 'matrix_init'. */
  argInit_1x2_real_T(dv4);
  matrix_init(15, FF, dv4, 0.2, 100, 2, G, twoGamaQ_barfi, twoGamaQ_barpsi, L, w, Mpsi, c);
	printColumn(twoGamaQ_barfi);
	printColumn(Mpsi);
	printColumn(G);

	//FORMAT CONVERSION
	int i;
	for(i=0;i<60;i++){
		twoGamaQ_barfi_array[i]=*(twoGamaQ_barfi->data+i);
	}
 	for(i=0;i<225;i++){
		twoGamaQ_barpsi_array[i]=*(twoGamaQ_barpsi->data+i);
	}
	for(i=0;i<640;i++){
		w_array[i]=*(w->data+i);
	}
	for(i=0;i<2400;i++){
		Mpsi_array[i]=*(Mpsi->data+i);
	}
	for(i=0;i<160;i++){
		c_array[i]=*(c->data+i);
	}
	for(i=0;i<2700;i++){
		L_array[i]=*(L->data+i);
	}
printColumn_std(w_array,60);
	//Repetitive part
	matrix_final(q0, v0, a0, da0, qTarget, vTarget,
               aTarget, d0, twoGamaQ_barfi_array, twoGamaQ_barpsi_array, w_array, 
								Mpsi_array, c_array, 0.2, 15, F, bi);
	printf("done\n");
	//printColumn_std(bi,160);
	printColumn_std(F,15); 
	emxDestroyArray_real_T(c);
  emxDestroyArray_real_T(Mpsi);
  emxDestroyArray_real_T(w);
  emxDestroyArray_real_T(L);
  emxDestroyArray_real_T(twoGamaQ_barpsi);
  emxDestroyArray_real_T(twoGamaQ_barfi);
  emxDestroyArray_real_T(G);
}

int main(int argc, const char * const argv[])
{
  (void)argc;
  (void)argv;

  /* Initialize the application.
     You do not need to do this more than one time. */
  //matrix_init_initialize();

  /* Invoke the entry-point functions.
     You can call entry-point functions multiple times. */
  main_matrix_init();

  /* Terminate the application.
     You do not need to do this more than one time. */
  //matrix_init_terminate();
  return 0;
}

/* End of code generation (main.c) */
