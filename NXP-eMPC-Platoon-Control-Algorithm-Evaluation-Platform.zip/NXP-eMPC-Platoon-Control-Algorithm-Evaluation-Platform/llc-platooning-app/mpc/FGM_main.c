/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main.c
 *
 * Code generation for function 'main'
 *
 */

/*************************************************************************/
/* This automatically generated example C main file shows how to call    */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/
/* Include files */
#include "rt_nonfinite.h"
#include "matrix_final.h"
#include "main.h"
#include "matrix_init_emxAPI.h"
#include "matrix_init.h"
#include "FGM.h"
#include <stdio.h>

/* Function Declarations */
static void argInit_1x2_real_T(double result[2]);
static void argInit_15x15_real_T(double result[225]);
static void argInit_15x4_real_T(double result[60]);
static void argInit_160x15_real_T(double result[2400]);
static void argInit_160x1_real_T(double result[160]);
static void argInit_160x4_real_T(double result[640]);
static double argInit_real_T(void);
static void main_matrix_final(void);

/* Function Definitions */
static void printColumn(emxArray_real_T* var){
	int i;
	printf("\n");
	for (i=0; i<*(var->size); i++){
		printf("%f\n",*(var->data+i));
	}
}

static void printColumn_std(double* var, int l){
	int i;
	printf("\n");
	for (i=0; i<l; i++){
		printf("%f\n",*(var+i));
	}
}

static void argInit_1x2_real_T(double result[2])
{
  result[0] = K1;
	result[1] = K2;

}


static void argInit_15x15_real_T(double result[225])
{
  int idx0;
  int idx1;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 15; idx0++) {
    for (idx1 = 0; idx1 < 15; idx1++) {
      /* Set the value of the array element.
         Change this value to the value that the application requires. */
      result[idx0 + 15 * idx1] = argInit_real_T();
    }
  }
}

static void argInit_15x4_real_T(double result[60])
{
  int idx0;
  int idx1;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 15; idx0++) {
    for (idx1 = 0; idx1 < 4; idx1++) {
      /* Set the value of the array element.
         Change this value to the value that the application requires. */
      result[idx0 + 15 * idx1] = argInit_real_T();
    }
  }
}

static void argInit_160x15_real_T(double result[2400])
{
  int idx0;
  int idx1;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 160; idx0++) {
    for (idx1 = 0; idx1 < 15; idx1++) {
      /* Set the value of the array element.
         Change this value to the value that the application requires. */
      result[idx0 + 160 * idx1] = argInit_real_T();
    }
  }
}

static void argInit_160x1_real_T(double result[160])
{
  int idx0;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 160; idx0++) {
    /* Set the value of the array element.
       Change this value to the value that the application requires. */
    result[idx0] = argInit_real_T();
  }
}

static void argInit_160x4_real_T(double result[640])
{
  int idx0;
  int idx1;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 160; idx0++) {
    for (idx1 = 0; idx1 < 4; idx1++) {
      /* Set the value of the array element.
         Change this value to the value that the application requires. */
      result[idx0 + 160 * idx1] = argInit_real_T();
    }
  }
}

static void argInit_15x1_real_T(double result[15])
{
  int idx0;

  /* Loop over the array to initialize each element. */
  for (idx0 = 0; idx0 < 15; idx0++) {
    /* Set the value of the array element.
       Change this value to the value that the application requires. */
    result[idx0] = 0;
  }
}

static double argInit_real_T(void)
{
  return rand();
}

static void main_matrix_final(void)
{
	emxArray_real_T *G;
  emxArray_real_T *twoGamaQ_barfi;
  emxArray_real_T *twoGamaQ_barpsi;
  emxArray_real_T *L;
  emxArray_real_T *w;
  emxArray_real_T *Mpsi;
  emxArray_real_T *c;
  double dv4[2];
  emxInitArray_real_T(&G, 2);
  emxInitArray_real_T(&twoGamaQ_barfi, 2);
  emxInitArray_real_T(&twoGamaQ_barpsi, 2);
  emxInitArray_real_T(&L, 2);
  emxInitArray_real_T(&w, 2);
  emxInitArray_real_T(&Mpsi, 2);
  emxInitArray_real_T(&c, 1);
  double F[15];
  double bi[160];
	double G_array[225];
	double twoGamaQ_barfi_array[60];
  double twoGamaQ_barpsi_array[225];
  double w_array[640];
  double Mpsi_array[2400];
  double c_array[160];
	double L_array[2700];
	double u_start[15];
	double old_u[15];
	double q0=95;
	double v0=2;
	double a0=0;
	double da0=0;
	double qTarget=100;
	double vTarget=2;
	double aTarget=0;
	double d0=5;
	argInit_1x2_real_T(dv4);
  matrix_init(15, FF, dv4, 0.2, 100, 2, G, twoGamaQ_barfi, twoGamaQ_barpsi, L, w, Mpsi, c);
		//FORMAT CONVERSION
	int i;
	for(i=0;i<60;i++){
		twoGamaQ_barfi_array[i]=*(twoGamaQ_barfi->data+i);
	}
 	for(i=0;i<225;i++){
		twoGamaQ_barpsi_array[i]=*(twoGamaQ_barpsi->data+i);
	}
	for(i=0;i<640;i++){
		w_array[i]=*(w->data+i);
	}
	for(i=0;i<2400;i++){
		Mpsi_array[i]=*(Mpsi->data+i);
	}
	for(i=0;i<160;i++){
		c_array[i]=*(c->data+i);
	}
	for(i=0;i<2700;i++){
		L_array[i]=*(L->data+i);
	}
	for(i=0;i<225;i++){
		G_array[i]=*(G->data+i);
	}
printColumn_std(w_array,60);
  /* Initialize function 'matrix_final' input arguments. */
/*  argInit_160x4_real_T(w_array);*/
/*	argInit_15x4_real_T(twoGamaQ_barfi_array);*/
/*	argInit_15x15_real_T(twoGamaQ_barpsi_array);*/
/*	argInit_160x15_real_T(Mpsi_array);*/
/*	argInit_160x1_real_T(c_array);*/
/* Call the entry-point 'matrix_final'. */

  	matrix_final(q0, v0, a0, da0, qTarget, vTarget,
               aTarget, d0, twoGamaQ_barfi_array, twoGamaQ_barpsi_array, w_array, 
								Mpsi_array, c_array, 0.2, 15, F, bi);
	printColumn_std(F,15);
	argInit_15x1_real_T(old_u);
	  FGM(-3, 3, 0.01, 30, 225.3689, G_array, old_u, F, 15, u_start);
	printColumn_std(u_start,15);
}

int main(int argc, const char * const argv[])
{
  (void)argc;
  (void)argv;

  /* Initialize the application.
     You do not need to do this more than one time. */
  //matrix_final_initialize();
  /* Invoke the entry-point functions.
     You can call entry-point functions multiple times. */
  main_matrix_final();

  /* Terminate the application.
     You do not need to do this more than one time. */
  //matrix_final_terminate();
  return 0;
}

/* End of code generation (main.c) */
