/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_to_integer_power.c
 *
 * Code generation for function 'matrix_to_integer_power'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matrix_init.h"
#include "matrix_to_integer_power.h"
#include "inv.h"

/* Function Definitions */
void matrix_to_small_integer_power(double a[16], double b, double c[16])
{
  double y;
  int n;
  int b_n;
  int nbitson;
  int nb;
  boolean_T first;
  boolean_T aBufferInUse;
  boolean_T lsb;
  int i8;
  double cBuffer[16];
  int i9;
  double aBuffer[16];
  y = fabs(b);
  n = (int)fabs(b);
  b_n = (int)y;
  nbitson = 0;
  nb = -1;
  while (b_n > 0) {
    nb++;
    if ((b_n & 1) != 0) {
      nbitson++;
    }

    b_n >>= 1;
  }

  if ((int)y <= 2) {
    if (b == 2.0) {
      for (nbitson = 0; nbitson < 4; nbitson++) {
        for (i8 = 0; i8 < 4; i8++) {
          c[nbitson + (i8 << 2)] = 0.0;
          for (i9 = 0; i9 < 4; i9++) {
            c[nbitson + (i8 << 2)] += a[nbitson + (i9 << 2)] * a[i9 + (i8 << 2)];
          }
        }
      }
    } else if (b == 1.0) {
      memcpy(&c[0], &a[0], sizeof(double) << 4);
    } else if (b == -1.0) {
      invNxN(a, c);
    } else if (b == -2.0) {
      for (nbitson = 0; nbitson < 4; nbitson++) {
        for (i8 = 0; i8 < 4; i8++) {
          cBuffer[nbitson + (i8 << 2)] = 0.0;
          for (i9 = 0; i9 < 4; i9++) {
            cBuffer[nbitson + (i8 << 2)] += a[nbitson + (i9 << 2)] * a[i9 + (i8 <<
              2)];
          }
        }
      }

      invNxN(cBuffer, c);
    } else {
      memset(&c[0], 0, sizeof(double) << 4);
      for (b_n = 0; b_n < 4; b_n++) {
        c[b_n + (b_n << 2)] = 1.0;
      }
    }
  } else {
    first = true;
    aBufferInUse = false;
    lsb = ((nbitson & 1) != 0);
    if ((lsb && (b < 0.0)) || ((!lsb) && (b >= 0.0))) {
      lsb = true;
    } else {
      lsb = false;
    }

    for (b_n = 1; b_n <= nb; b_n++) {
      if ((n & 1) != 0) {
        if (first) {
          first = false;
          if (lsb) {
            if (aBufferInUse) {
              memcpy(&cBuffer[0], &aBuffer[0], sizeof(double) << 4);
            } else {
              memcpy(&cBuffer[0], &a[0], sizeof(double) << 4);
            }
          } else if (aBufferInUse) {
            memcpy(&c[0], &aBuffer[0], sizeof(double) << 4);
          } else {
            memcpy(&c[0], &a[0], sizeof(double) << 4);
          }
        } else {
          if (aBufferInUse) {
            if (lsb) {
              for (nbitson = 0; nbitson < 4; nbitson++) {
                for (i8 = 0; i8 < 4; i8++) {
                  c[nbitson + (i8 << 2)] = 0.0;
                  for (i9 = 0; i9 < 4; i9++) {
                    c[nbitson + (i8 << 2)] += cBuffer[nbitson + (i9 << 2)] *
                      aBuffer[i9 + (i8 << 2)];
                  }
                }
              }
            } else {
              for (nbitson = 0; nbitson < 4; nbitson++) {
                for (i8 = 0; i8 < 4; i8++) {
                  cBuffer[nbitson + (i8 << 2)] = 0.0;
                  for (i9 = 0; i9 < 4; i9++) {
                    cBuffer[nbitson + (i8 << 2)] += c[nbitson + (i9 << 2)] *
                      aBuffer[i9 + (i8 << 2)];
                  }
                }
              }
            }
          } else if (lsb) {
            for (nbitson = 0; nbitson < 4; nbitson++) {
              for (i8 = 0; i8 < 4; i8++) {
                c[nbitson + (i8 << 2)] = 0.0;
                for (i9 = 0; i9 < 4; i9++) {
                  c[nbitson + (i8 << 2)] += cBuffer[nbitson + (i9 << 2)] * a[i9
                    + (i8 << 2)];
                }
              }
            }
          } else {
            for (nbitson = 0; nbitson < 4; nbitson++) {
              for (i8 = 0; i8 < 4; i8++) {
                cBuffer[nbitson + (i8 << 2)] = 0.0;
                for (i9 = 0; i9 < 4; i9++) {
                  cBuffer[nbitson + (i8 << 2)] += c[nbitson + (i9 << 2)] * a[i9
                    + (i8 << 2)];
                }
              }
            }
          }

          lsb = !lsb;
        }
      }

      n >>= 1;
      if (aBufferInUse) {
        for (nbitson = 0; nbitson < 4; nbitson++) {
          for (i8 = 0; i8 < 4; i8++) {
            a[nbitson + (i8 << 2)] = 0.0;
            for (i9 = 0; i9 < 4; i9++) {
              a[nbitson + (i8 << 2)] += aBuffer[nbitson + (i9 << 2)] *
                aBuffer[i9 + (i8 << 2)];
            }
          }
        }
      } else {
        for (nbitson = 0; nbitson < 4; nbitson++) {
          for (i8 = 0; i8 < 4; i8++) {
            aBuffer[nbitson + (i8 << 2)] = 0.0;
            for (i9 = 0; i9 < 4; i9++) {
              aBuffer[nbitson + (i8 << 2)] += a[nbitson + (i9 << 2)] * a[i9 +
                (i8 << 2)];
            }
          }
        }
      }

      aBufferInUse = !aBufferInUse;
    }

    if (first) {
      if (b < 0.0) {
        if (aBufferInUse) {
          invNxN(aBuffer, c);
        } else {
          invNxN(a, c);
        }
      } else if (aBufferInUse) {
        memcpy(&c[0], &aBuffer[0], sizeof(double) << 4);
      } else {
        memcpy(&c[0], &a[0], sizeof(double) << 4);
      }
    } else if (b < 0.0) {
      if (aBufferInUse) {
        for (nbitson = 0; nbitson < 4; nbitson++) {
          for (i8 = 0; i8 < 4; i8++) {
            cBuffer[nbitson + (i8 << 2)] = 0.0;
            for (i9 = 0; i9 < 4; i9++) {
              cBuffer[nbitson + (i8 << 2)] += c[nbitson + (i9 << 2)] *
                aBuffer[i9 + (i8 << 2)];
            }
          }
        }
      } else {
        for (nbitson = 0; nbitson < 4; nbitson++) {
          for (i8 = 0; i8 < 4; i8++) {
            cBuffer[nbitson + (i8 << 2)] = 0.0;
            for (i9 = 0; i9 < 4; i9++) {
              cBuffer[nbitson + (i8 << 2)] += c[nbitson + (i9 << 2)] * a[i9 +
                (i8 << 2)];
            }
          }
        }
      }

      invNxN(cBuffer, c);
    } else if (aBufferInUse) {
      for (nbitson = 0; nbitson < 4; nbitson++) {
        for (i8 = 0; i8 < 4; i8++) {
          c[nbitson + (i8 << 2)] = 0.0;
          for (i9 = 0; i9 < 4; i9++) {
            c[nbitson + (i8 << 2)] += cBuffer[nbitson + (i9 << 2)] * aBuffer[i9
              + (i8 << 2)];
          }
        }
      }
    } else {
      for (nbitson = 0; nbitson < 4; nbitson++) {
        for (i8 = 0; i8 < 4; i8++) {
          c[nbitson + (i8 << 2)] = 0.0;
          for (i9 = 0; i9 < 4; i9++) {
            c[nbitson + (i8 << 2)] += cBuffer[nbitson + (i9 << 2)] * a[i9 + (i8 <<
              2)];
          }
        }
      }
    }
  }
}

/* End of code generation (matrix_to_integer_power.c) */
