/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_init.h
 *
 * Code generation for function 'matrix_init'
 *
 */

#ifndef MATRIX_INIT_H
#define MATRIX_INIT_H

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "matrix_init_types.h"

/* Function Declarations */
extern void matrix_init(double N, double F1, const double k1[2], double tauh,
  double h_upper, double h_lower, emxArray_real_T *G, emxArray_real_T
  *twoGamaQ_barfi, emxArray_real_T *twoGamaQ_barpsi, emxArray_real_T *L,
  emxArray_real_T *w, emxArray_real_T *Mpsi, emxArray_real_T *c);

#endif

/* End of code generation (matrix_init.h) */
