/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_init.c
 *
 * Code generation for function 'matrix_init'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matrix_init.h"
#include "mpower.h"
#include "matrix_init_emxutil.h"
#include "diag.h"
#include "eye.h"

/* Function Definitions */
void matrix_init(double N, double F1, const double k1[2], double tauh, double
                 h_upper, double h_lower, emxArray_real_T *G, emxArray_real_T
                 *twoGamaQ_barfi, emxArray_real_T *twoGamaQ_barpsi,
                 emxArray_real_T *L, emxArray_real_T *w, emxArray_real_T *Mpsi,
                 emxArray_real_T *c)
{
  double A_bar[16];
  double eta;
  double phi[16];
  const double b_phi[16]={ 0.999996484021898, -0.003296764379863, -0.00199999758002383000 * tauh - 0.00000199999876652836, -0.001999997580024,
										 0.001648382189931, 0.670303562213740, -0.00000175798905095811 * tauh - 0.00000000120998819307, -1.757989051E-6, 
										 0.0, 0.0, 1.0, 0.0, 
										 0.0, 0.0, 0.002, 1.0 }; //It goes by columns (row,col): (1,1),(2,1),...(1,2)...

  int i0;
  int i1;
  const double dv0[8]={ 0.999996484021898, -0.003296764379863, -0.00199999758002383000 * tauh - 0.00000199999876652836, -0.001999997580024,
									0.001648382189931, 0.670303562213740, -0.00000175798905095811 * tauh - 0.00000000120998819307, -1.757989051E-6};

  double a[4]={ 2.6369835765E-5, 0.024725732848969, -0.00000001814982113024 * tauh - 0.00000000000925053837, -1.8149821E-8 };

  double A_new[16];
  double B_new[16];
  int k;
  double G_new[16];
  double dv1[16];
  emxArray_real_T *fi;
  int ar;
  emxArray_real_T *C;
  emxArray_real_T *Gama;
  int i2;
  int i3;
  int i4;
  int m;
  emxArray_int32_T *r0;
  emxArray_real_T *b;
  double rows;
  int unnamed_idx_0;
  int cr;
  emxArray_real_T *b_G;
  emxArray_real_T *psi;
  int br;
  int ic;
  int ib;
  int ia;
  static const double b_b[4] = { 0.0, 0.0, 2.0E-6, 0.002 };

  emxArray_real_T *Q_bar;
  static const double dv2[4] = { 0.0, 1.0, 50.0, 30.0 };

  double y[4];
  emxArray_int32_T *r1;
  emxArray_real_T *E;
  emxArray_real_T *b_y;
  unsigned int b_unnamed_idx_0;
  unsigned int unnamed_idx_1;
  double Mi[40];
  static const signed char Ei[10] = { -1, 1, 0, 0, 0, 0, 0, 0, 0, 0 };

  double dv3[10];
  static const signed char bi[10] = { 4, 4, 4, 3, 3, 3, 4, 3, 3, 3 };

  (void)tauh;
  eye(A_bar);

  /*  Lower bound of the states */
  /*  upper bound on the control action (it can't be softened, it depends on the physical constaints of the actuators) */
  /*  */
  /*   %% 1 parameters */
  /*  tau = 100;Kt = 0.075; */
  /*  taua = .0050; */
  /*  Kta = 100;  */
  /*   */
  /*  Matrices for the continuous time System: */
  /*  A1=[0                                              1             ; */
  /*     -1/(tau*taua)         -(tau + taua)/(tau*taua); ]; */
  /*  B1=[0; (Kt*Kta)/(tau*taua);]; */
  /*  C1=[1 0]; */
  /*   */
  /*   %% 3  System2:  x2_dot=A2 x2+ A21 x1+ B2 u2: this is the model for the upper-level but */
  /*   % with only two states (delta d "error in position" and delta v "error in */
  /*   % velocity") the other two states will be added from the previous model */
  /*   % x1, u2 =a_p (the acceleration of the preceding vehicle).  */
  /*   % Now we define the system matrices:  */
  /*   A2=[0 1; 0 0]; A21=[-tauh 0;-1 0]; B2=[0;1]; */
  /*    */
  /*   %% the overall system: Comining both systems (System1 and System2) together. Consists of 4 states x=[a,da,delta d , delta v]. in */
  /*   %continuous time : x_dot=A*x(t)+B*u(t) & y=C*x. In discrete time: */
  /*   %x(k+1)=phi*x(k)+Gamma*u(k). u(k)=[u1(k);u2(k)], u1(k)= k1*x1(k) + */
  /*   %F1*a_des, u2 =a_p  */
  /*   A=blkdiag(A1,A2); */
  /*   A(3:4,1:2)=A21; */
  /*   B=blkdiag(B1,B2); */
  /*   C=blkdiag(1,1,1,1); */
  /*    */
  /*   % continuous-time state space */
  /*  sys_cont = ss(A,B,C,0); */
  /*   */
  /*  % ZOH based discrete system */
  /*  sys_disc= c2d(sys_cont, h_lower); */
  /*  phi = sys_disc.a */
  /*  Gamma = sys_disc.b */
  /*  %% system1:  x1_dot=A1 x1 + B1 u1 : this is the continuous time model of the */
  /*  low-level dynamics. after discretization: x1(k+1)= phi1*x1(k) + Gamma*u1(k) */
  /*  and u1(k)= k1*x1(k) + F1*a_des */
  /* tauh=0.2; % is the time headway (seconds) */
  eta = h_upper / h_lower;

  /*  */
  /*   %  with non-zero terminal constraint set use the following weights:   */
  /* %%% these weights works fine in case of zero terminal cost and terminal */
  /* %%% constraint set */
  /*  weights for the  */
  /*   */
  /*  Discrete time matrices are given from MATLAB */
  memcpy(&phi[0], &b_phi[0], sizeof(double) << 4);

  /*   */
  /*  the over all system is defined again as:  */
  /*     x(k+1)=A_new1*x(k)+B_new1*u_new(k)+G_new1*v(k), where u_new(k) is the control */
  /*     variable (the desired designed accleration = a_des) and v(k) is the disturbance (the accleration of the preceding vehicle =a_p) */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 2; i1++) {
      phi[i0 + (i1 << 2)] = dv0[i0 + (i1 << 2)] + a[i0] * k1[i1];
    }
  }

  /*  %% the model used for upper-level: x(k+50)=A_new x(k) + B_new u(k) + G_new v(k) */
  /*  where A_new, B_new, G_new are new matrices defined based on the previous */
  /*  model x(k+1)=A_new1*x(k)+B_new1*u_new(k)+G_new1*v(k) */
  mpower(phi, eta, A_new);
  eye(B_new);
  for (k = 0; k < (int)(eta - 1.0); k++) {
    mpower(phi, 1.0 + (double)k, dv1);
    for (i0 = 0; i0 < 16; i0++) {
      B_new[i0] += dv1[i0];
    }
  }

  eye(G_new);
  for (k = 0; k < (int)(eta - 1.0); k++) {
    mpower(phi, 1.0 + (double)k, dv1);
    for (i0 = 0; i0 < 16; i0++) {
      G_new[i0] += dv1[i0];
    }
  }

  emxInit_real_T(&fi, 2);

  /*  4  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%% PREDICTION MATRICES CALCULATION%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Xk=fi*x(k)+Gama*Uk+psi*Vk */
  i0 = fi->size[0] * fi->size[1];
  fi->size[0] = (int)(4.0 * N);
  fi->size[1] = 4;
  emxEnsureCapacity_real_T(fi, i0);
  ar = (int)(4.0 * N) << 2;
  for (i0 = 0; i0 < ar; i0++) {
    fi->data[i0] = 0.0;
  }

  /* Is like a crossed zero */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      fi->data[i1 + fi->size[0] * i0] = A_new[i1 + (i0 << 2)];
    }
  }

  /*  initial value */
  i0 = (int)((N * 4.0 + -1.0) / 4.0);
  k = 0;
  emxInit_real_T(&C, 2);
  while (k <= i0 - 1) {
    eta = 5.0 + (double)k * 4.0;
    if (eta - 4.0 > eta - 1.0) {
      i1 = 1;
      i2 = 1;
    } else {
      i1 = (int)(eta - 4.0);
      i2 = (int)(eta - 1.0) + 1;
    }

    if (eta > (eta + 4.0) - 1.0) {
      i3 = 0;
    } else {
      i3 = (int)eta - 1;
    }

    i4 = C->size[0] * C->size[1];
    C->size[0] = i2 - i1;
    emxEnsureCapacity_real_T(C, i4);
    m = i2 - i1;
    i4 = C->size[0] * C->size[1];
    C->size[1] = 4;
    emxEnsureCapacity_real_T(C, i4);
    for (i4 = 0; i4 < 4; i4++) {
      ar = C->size[0];
      for (cr = 0; cr < ar; cr++) {
        C->data[cr + C->size[0] * i4] = 0.0;
      }
    }

    if (i2 - i1 != 0) {
      unnamed_idx_0 = (i2 - i1) * 3;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i4 = cr + m;
        for (ic = cr; ic + 1 <= i4; ic++) {
          C->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        for (ib = br; ib + 1 <= br + 4; ib++) {
          if (A_new[ib] != 0.0) {
            ia = ar;
            i4 = cr + m;
            for (ic = cr; ic + 1 <= i4; ic++) {
              ia++;
              C->data[ic] += A_new[ib] * fi->data[((i1 + (ia - 1) % (i2 - i1)) +
                fi->size[0] * ((ia - 1) / (i2 - i1))) - 1];
            }
          }

          ar += m;
        }

        br += 4;
        cr += m;
      }
    }

    for (i1 = 0; i1 < 4; i1++) {
      ar = C->size[0];
      for (i2 = 0; i2 < ar; i2++) {
        fi->data[(i3 + i2) + fi->size[0] * i1] = C->data[i2 + C->size[0] * i1];
      }
    }

    k++;
  }

  emxInit_real_T(&Gama, 2);

  /*  m1 : states number, n1: inputs number */
  i0 = Gama->size[0] * Gama->size[1];
  Gama->size[0] = (int)(4.0 * N);
  Gama->size[1] = (int)N;
  emxEnsureCapacity_real_T(Gama, i0);
  ar = (int)(4.0 * N) * (int)N;
  for (i0 = 0; i0 < ar; i0++) {
    Gama->data[i0] = 0.0;
  }

  /* is like like a lamp :) */
  for (i0 = 0; i0 < 4; i0++) {
    Gama->data[i0] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      Gama->data[i0] += B_new[i0 + (i1 << 2)] * (F1 * a[i1]);
    }
  }

  i0 = (int)((N * 4.0 + -1.0) / 4.0);
  m = 0;
  emxInit_int32_T(&r0, 1);
  emxInit_real_T1(&b, 1);
  while (m <= i0 - 1) {
    rows = 5.0 + (double)m * 4.0;

    /*  Times A */
    if (rows - 4.0 > rows - 1.0) {
      i1 = 0;
      i2 = 0;
    } else {
      i1 = (int)(rows - 4.0) - 1;
      i2 = (int)(rows - 1.0);
    }

    if (rows > (rows + 4.0) - 1.0) {
      i3 = 0;
      i4 = 0;
    } else {
      i3 = (int)rows - 1;
      i4 = (int)((unsigned int)rows + 3U);
    }

    cr = r0->size[0];
    r0->size[0] = i4 - i3;
    emxEnsureCapacity_int32_T(r0, cr);
    ar = i4 - i3;
    for (i4 = 0; i4 < ar; i4++) {
      r0->data[i4] = i3 + i4;
    }

    i3 = b->size[0];
    b->size[0] = i2 - i1;
    emxEnsureCapacity_real_T1(b, i3);
    ar = i2 - i1;
    for (i3 = 0; i3 < ar; i3++) {
      b->data[i3] = Gama->data[i1 + i3];
    }

    if (i2 - i1 == 1) {
      for (i1 = 0; i1 < 4; i1++) {
        y[i1] = 0.0;
        for (i2 = 0; i2 < 4; i2++) {
          eta = y[i1] + A_new[i1 + (i2 << 2)] * b->data[i2];
          y[i1] = eta;
        }
      }
    } else if (4 == i2 - i1) {
      for (i1 = 0; i1 < 4; i1++) {
        y[i1] = 0.0;
        for (i2 = 0; i2 < 4; i2++) {
          eta = y[i1] + A_new[i1 + (i2 << 2)] * b->data[i2];
          y[i1] = eta;
        }
      }
    } else {
      for (ic = 0; ic < 4; ic++) {
        y[ic] = 0.0;
      }

      ar = 0;
      for (ib = 0; ib < 4; ib++) {
        if (Gama->data[i1 + ib] != 0.0) {
          ia = ar;
          for (ic = 0; ic < 4; ic++) {
            ia++;
            eta = y[ic] + Gama->data[i1 + ib] * A_new[ia - 1];
            y[ic] = eta;
          }
        }

        ar += 4;
      }
    }

    unnamed_idx_0 = r0->size[0];
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      Gama->data[r0->data[i1]] = y[i1];
    }

    m++;
  }

  k = 0;
  emxInit_real_T(&b_G, 2);
  while (k <= (int)(N + -1.0) - 1) {
    /*  reemplaze columns */
    i0 = (int)((N * 4.0 + -1.0) / 4.0);
    for (m = 0; m < i0; m++) {
      rows = 5.0 + (double)m * 4.0;

      /*   */
      if (rows - 4.0 > rows - 1.0) {
        i1 = 0;
        i2 = 0;
      } else {
        i1 = (int)(rows - 4.0) - 1;
        i2 = (int)(rows - 1.0);
      }

      if (rows > (rows + 4.0) - 1.0) {
        i3 = 0;
      } else {
        i3 = (int)rows - 1;
      }

      if (2.0 + (double)k > ((2.0 + (double)k) + 1.0) - 1.0) {
        i4 = 0;
      } else {
        i4 = (int)(2.0 + (double)k) - 1;
      }

      cr = b_G->size[0] * b_G->size[1];
      b_G->size[0] = i2 - i1;
      b_G->size[1] = 1;
      emxEnsureCapacity_real_T(b_G, cr);
      for (cr = 0; cr < 1; cr++) {
        br = i2 - i1;
        for (unnamed_idx_0 = 0; unnamed_idx_0 < br; unnamed_idx_0++) {
          b_G->data[unnamed_idx_0 + b_G->size[0] * cr] = Gama->data[(i1 +
            unnamed_idx_0) + Gama->size[0] * (((int)((2.0 + (double)k) - 1.0) +
            cr) - 1)];
        }
      }

      ar = b_G->size[1];
      for (i1 = 0; i1 < ar; i1++) {
        br = b_G->size[0];
        for (i2 = 0; i2 < br; i2++) {
          Gama->data[(i3 + i2) + Gama->size[0] * (i4 + i1)] = b_G->data[i2 +
            b_G->size[0] * i1];
        }
      }
    }

    k++;
  }

  emxInit_real_T(&psi, 2);
  i0 = psi->size[0] * psi->size[1];
  psi->size[0] = (int)(4.0 * N);
  psi->size[1] = (int)N;
  emxEnsureCapacity_real_T(psi, i0);
  ar = (int)(4.0 * N) * (int)N;
  for (i0 = 0; i0 < ar; i0++) {
    psi->data[i0] = 0.0;
  }

  /* is like like a lamp :) */
  for (i0 = 0; i0 < 4; i0++) {
    psi->data[i0] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      psi->data[i0] += G_new[i0 + (i1 << 2)] * b_b[i1];
    }
  }

  i0 = (int)((N * 4.0 + -1.0) / 4.0);
  for (m = 0; m < i0; m++) {
    rows = 5.0 + (double)m * 4.0;

    /*  Times A */
    if (rows - 4.0 > rows - 1.0) {
      i1 = 0;
      i2 = 0;
    } else {
      i1 = (int)(rows - 4.0) - 1;
      i2 = (int)(rows - 1.0);
    }

    if (rows > (rows + 4.0) - 1.0) {
      i3 = 0;
      i4 = 0;
    } else {
      i3 = (int)rows - 1;
      i4 = (int)((unsigned int)rows + 3U);
    }

    cr = r0->size[0];
    r0->size[0] = i4 - i3;
    emxEnsureCapacity_int32_T(r0, cr);
    ar = i4 - i3;
    for (i4 = 0; i4 < ar; i4++) {
      r0->data[i4] = i3 + i4;
    }

    i3 = b->size[0];
    b->size[0] = i2 - i1;
    emxEnsureCapacity_real_T1(b, i3);
    ar = i2 - i1;
    for (i3 = 0; i3 < ar; i3++) {
      b->data[i3] = psi->data[i1 + i3];
    }

    if (i2 - i1 == 1) {
      for (i1 = 0; i1 < 4; i1++) {
        y[i1] = 0.0;
        for (i2 = 0; i2 < 4; i2++) {
          eta = y[i1] + A_new[i1 + (i2 << 2)] * b->data[i2];
          y[i1] = eta;
        }
      }
    } else if (4 == i2 - i1) {
      for (i1 = 0; i1 < 4; i1++) {
        y[i1] = 0.0;
        for (i2 = 0; i2 < 4; i2++) {
          eta = y[i1] + A_new[i1 + (i2 << 2)] * b->data[i2];
          y[i1] = eta;
        }
      }
    } else {
      for (ic = 0; ic < 4; ic++) {
        y[ic] = 0.0;
      }

      ar = 0;
      for (ib = 0; ib < 4; ib++) {
        if (psi->data[i1 + ib] != 0.0) {
          ia = ar;
          for (ic = 0; ic < 4; ic++) {
            ia++;
            eta = y[ic] + psi->data[i1 + ib] * A_new[ia - 1];
            y[ic] = eta;
          }
        }

        ar += 4;
      }
    }

    unnamed_idx_0 = r0->size[0];
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      psi->data[r0->data[i1]] = y[i1];
    }
  }

  emxFree_real_T(&b);
  for (k = 0; k < (int)(N + -1.0); k++) {
    /*  reemplaze columns */
    i0 = (int)((N * 4.0 + -1.0) / 4.0);
    for (m = 0; m < i0; m++) {
      rows = 5.0 + (double)m * 4.0;

      /*   */
      if (rows - 4.0 > rows - 1.0) {
        i1 = 0;
        i2 = 0;
      } else {
        i1 = (int)(rows - 4.0) - 1;
        i2 = (int)(rows - 1.0);
      }

      if (rows > (rows + 4.0) - 1.0) {
        i3 = 0;
      } else {
        i3 = (int)rows - 1;
      }

      if (2.0 + (double)k > ((2.0 + (double)k) + 1.0) - 1.0) {
        i4 = 0;
      } else {
        i4 = (int)(2.0 + (double)k) - 1;
      }

      cr = b_G->size[0] * b_G->size[1];
      b_G->size[0] = i2 - i1;
      b_G->size[1] = 1;
      emxEnsureCapacity_real_T(b_G, cr);
      for (cr = 0; cr < 1; cr++) {
        br = i2 - i1;
        for (unnamed_idx_0 = 0; unnamed_idx_0 < br; unnamed_idx_0++) {
          b_G->data[unnamed_idx_0 + b_G->size[0] * cr] = psi->data[(i1 +
            unnamed_idx_0) + psi->size[0] * (((int)((2.0 + (double)k) - 1.0) +
            cr) - 1)];
        }
      }

      ar = b_G->size[1];
      for (i1 = 0; i1 < ar; i1++) {
        br = b_G->size[0];
        for (i2 = 0; i2 < br; i2++) {
          psi->data[(i3 + i2) + psi->size[0] * (i4 + i1)] = b_G->data[i2 +
            b_G->size[0] * i1];
        }
      }
    }
  }

  emxInit_real_T(&Q_bar, 2);

  /*  6 the cost matrices: Q and R and P: */
  diag(dv2, phi);

  /*  zero terminal  cost  */
  /* Terminal set = 0 */
  /*  */
  /* %% COST FUNCTION MATRICES %%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%% */
  /*  J(x(k),Uk)=x(k)^T*Q*x(k)+Xk^T*Q_bar*Xk+Uk^T*R_bar*Uk */
  i0 = Q_bar->size[0] * Q_bar->size[1];
  Q_bar->size[0] = (int)(N * 4.0);
  Q_bar->size[1] = (int)(N * 4.0);
  emxEnsureCapacity_real_T(Q_bar, i0);
  ar = (int)(N * 4.0) * (int)(N * 4.0);
  for (i0 = 0; i0 < ar; i0++) {
    Q_bar->data[i0] = 0.0;
  }

  i0 = (int)(((N * 4.0 - 4.0) + 3.0) / 4.0);
  m = 0;
  emxInit_int32_T(&r1, 1);
  while (m <= i0 - 1) {
    rows = 1.0 + (double)m * 4.0;
    if (rows > (rows + 4.0) - 1.0) {
      i1 = 0;
      i2 = 0;
      i3 = 0;
      i4 = 0;
    } else {
      i1 = (int)rows - 1;
      i2 = (int)((unsigned int)rows + 3U);
      i3 = (int)rows - 1;
      i4 = (int)((unsigned int)rows + 3U);
    }

    cr = r0->size[0];
    r0->size[0] = i2 - i1;
    emxEnsureCapacity_int32_T(r0, cr);
    ar = i2 - i1;
    for (i2 = 0; i2 < ar; i2++) {
      r0->data[i2] = i1 + i2;
    }

    i1 = r1->size[0];
    r1->size[0] = i4 - i3;
    emxEnsureCapacity_int32_T(r1, i1);
    ar = i4 - i3;
    for (i1 = 0; i1 < ar; i1++) {
      r1->data[i1] = i3 + i1;
    }

    unnamed_idx_0 = r0->size[0];
    k = r1->size[0];
    for (i1 = 0; i1 < k; i1++) {
      for (i2 = 0; i2 < unnamed_idx_0; i2++) {
        Q_bar->data[r0->data[i2] + Q_bar->size[0] * r1->data[i1]] = phi[i2 +
          unnamed_idx_0 * i1];
      }
    }

    m++;
  }

  eta = (N * 4.0 - 4.0) + 1.0;
  rows = N * 4.0;
  if (eta > rows) {
    i0 = 0;
    i1 = 0;
  } else {
    i0 = (int)eta - 1;
    i1 = (int)rows;
  }

  eta = (N * 4.0 - 4.0) + 1.0;
  rows = N * 4.0;
  if (eta > rows) {
    i2 = 0;
    i3 = 0;
  } else {
    i2 = (int)eta - 1;
    i3 = (int)rows;
  }

  i4 = r0->size[0];
  r0->size[0] = i1 - i0;
  emxEnsureCapacity_int32_T(r0, i4);
  ar = i1 - i0;
  for (i1 = 0; i1 < ar; i1++) {
    r0->data[i1] = i0 + i1;
  }

  i0 = r1->size[0];
  r1->size[0] = i3 - i2;
  emxEnsureCapacity_int32_T(r1, i0);
  ar = i3 - i2;
  for (i0 = 0; i0 < ar; i0++) {
    r1->data[i0] = i2 + i0;
  }

  unnamed_idx_0 = r0->size[0];
  k = r1->size[0];
  for (i0 = 0; i0 < k; i0++) {
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      Q_bar->data[r0->data[i1] + Q_bar->size[0] * r1->data[i0]] = 0.0;
    }
  }

  i0 = G->size[0] * G->size[1];
  G->size[0] = (int)N;
  G->size[1] = (int)N;
  emxEnsureCapacity_real_T(G, i0);
  ar = (int)N * (int)N;
  for (i0 = 0; i0 < ar; i0++) {
    G->data[i0] = 0.0;
  }

  for (m = 0; m < (int)N; m++) {
    if (1.0 + (double)m > ((1.0 + (double)m) + 1.0) - 1.0) {
      i0 = 0;
      i1 = 0;
      i2 = 0;
      i3 = 0;
    } else {
      i0 = m;
      i1 = (int)(((1.0 + (double)m) + 1.0) - 1.0);
      i2 = m;
      i3 = (int)(((1.0 + (double)m) + 1.0) - 1.0);
    }

    unnamed_idx_0 = i1 - i0;
    ar = i3 - i2;
    for (i1 = 0; i1 < ar; i1++) {
      for (i3 = 0; i3 < unnamed_idx_0; i3++) {
        G->data[(i0 + i3) + G->size[0] * (i2 + i1)] = 30.0;
      }
    }
  }

  emxInit_real_T(&E, 2);
  emxInit_real_T(&b_y, 2);
  i0 = E->size[0] * E->size[1];
  E->size[0] = Gama->size[1];
  E->size[1] = Gama->size[0];
  emxEnsureCapacity_real_T(E, i0);
  ar = Gama->size[0];
  for (i0 = 0; i0 < ar; i0++) {
    br = Gama->size[1];
    for (i1 = 0; i1 < br; i1++) {
      E->data[i1 + E->size[0] * i0] = Gama->data[i0 + Gama->size[0] * i1];
    }
  }

  if ((E->size[1] == 1) || (Q_bar->size[0] == 1)) {
    i0 = b_y->size[0] * b_y->size[1];
    b_y->size[0] = E->size[0];
    b_y->size[1] = Q_bar->size[1];
    emxEnsureCapacity_real_T(b_y, i0);
    ar = E->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = Q_bar->size[1];
      for (i1 = 0; i1 < br; i1++) {
        b_y->data[i0 + b_y->size[0] * i1] = 0.0;
        k = E->size[1];
        for (i2 = 0; i2 < k; i2++) {
          b_y->data[i0 + b_y->size[0] * i1] += E->data[i0 + E->size[0] * i2] *
            Q_bar->data[i2 + Q_bar->size[0] * i1];
        }
      }
    }
  } else {
    k = E->size[1];
    b_unnamed_idx_0 = (unsigned int)E->size[0];
    unnamed_idx_1 = (unsigned int)Q_bar->size[1];
    i0 = b_y->size[0] * b_y->size[1];
    b_y->size[0] = (int)b_unnamed_idx_0;
    b_y->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(b_y, i0);
    m = E->size[0];
    i0 = b_y->size[0] * b_y->size[1];
    emxEnsureCapacity_real_T(b_y, i0);
    ar = b_y->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = b_y->size[0];
      for (i1 = 0; i1 < br; i1++) {
        b_y->data[i1 + b_y->size[0] * i0] = 0.0;
      }
    }

    if ((E->size[0] == 0) || (Q_bar->size[1] == 0)) {
    } else {
      unnamed_idx_0 = E->size[0] * (Q_bar->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          b_y->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (Q_bar->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              b_y->data[ic] += Q_bar->data[ib] * E->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  if ((b_y->size[1] == 1) || (Gama->size[0] == 1)) {
    i0 = E->size[0] * E->size[1];
    E->size[0] = b_y->size[0];
    E->size[1] = Gama->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = b_y->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = Gama->size[1];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i0 + E->size[0] * i1] = 0.0;
        k = b_y->size[1];
        for (i2 = 0; i2 < k; i2++) {
          E->data[i0 + E->size[0] * i1] += b_y->data[i0 + b_y->size[0] * i2] *
            Gama->data[i2 + Gama->size[0] * i1];
        }
      }
    }
  } else {
    k = b_y->size[1];
    b_unnamed_idx_0 = (unsigned int)b_y->size[0];
    unnamed_idx_1 = (unsigned int)Gama->size[1];
    i0 = E->size[0] * E->size[1];
    E->size[0] = (int)b_unnamed_idx_0;
    E->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(E, i0);
    m = b_y->size[0];
    i0 = E->size[0] * E->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = E->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = E->size[0];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i1 + E->size[0] * i0] = 0.0;
      }
    }

    if ((b_y->size[0] == 0) || (Gama->size[1] == 0)) {
    } else {
      unnamed_idx_0 = b_y->size[0] * (Gama->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          E->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (Gama->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              E->data[ic] += Gama->data[ib] * b_y->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  i0 = G->size[0] * G->size[1];
  emxEnsureCapacity_real_T(G, i0);
  k = G->size[0];
  unnamed_idx_0 = G->size[1];
  ar = k * unnamed_idx_0;
  for (i0 = 0; i0 < ar; i0++) {
    G->data[i0] = 2.0 * (G->data[i0] + E->data[i0]);
  }

  i0 = b_G->size[0] * b_G->size[1];
  b_G->size[0] = G->size[0];
  b_G->size[1] = G->size[1];
  emxEnsureCapacity_real_T(b_G, i0);
  ar = G->size[1];
  for (i0 = 0; i0 < ar; i0++) {
    br = G->size[0];
    for (i1 = 0; i1 < br; i1++) {
      b_G->data[i1 + b_G->size[0] * i0] = (G->data[i1 + G->size[0] * i0] +
        G->data[i0 + G->size[0] * i1]) / 2.0;
    }
  }

  i0 = G->size[0] * G->size[1];
  G->size[0] = b_G->size[0];
  G->size[1] = b_G->size[1];
  emxEnsureCapacity_real_T(G, i0);
  ar = b_G->size[1];
  for (i0 = 0; i0 < ar; i0++) {
    br = b_G->size[0];
    for (i1 = 0; i1 < br; i1++) {
      G->data[i1 + G->size[0] * i0] = b_G->data[i1 + b_G->size[0] * i0];
    }
  }

  emxFree_real_T(&b_G);
  i0 = b_y->size[0] * b_y->size[1];
  b_y->size[0] = Gama->size[1];
  b_y->size[1] = Gama->size[0];
  emxEnsureCapacity_real_T(b_y, i0);
  ar = Gama->size[0];
  for (i0 = 0; i0 < ar; i0++) {
    br = Gama->size[1];
    for (i1 = 0; i1 < br; i1++) {
      b_y->data[i1 + b_y->size[0] * i0] = 2.0 * Gama->data[i0 + Gama->size[0] *
        i1];
    }
  }

  if ((b_y->size[1] == 1) || (Q_bar->size[0] == 1)) {
    i0 = E->size[0] * E->size[1];
    E->size[0] = b_y->size[0];
    E->size[1] = Q_bar->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = b_y->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = Q_bar->size[1];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i0 + E->size[0] * i1] = 0.0;
        k = b_y->size[1];
        for (i2 = 0; i2 < k; i2++) {
          E->data[i0 + E->size[0] * i1] += b_y->data[i0 + b_y->size[0] * i2] *
            Q_bar->data[i2 + Q_bar->size[0] * i1];
        }
      }
    }
  } else {
    k = b_y->size[1];
    b_unnamed_idx_0 = (unsigned int)b_y->size[0];
    unnamed_idx_1 = (unsigned int)Q_bar->size[1];
    i0 = E->size[0] * E->size[1];
    E->size[0] = (int)b_unnamed_idx_0;
    E->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(E, i0);
    m = b_y->size[0];
    i0 = E->size[0] * E->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = E->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = E->size[0];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i1 + E->size[0] * i0] = 0.0;
      }
    }

    if ((b_y->size[0] == 0) || (Q_bar->size[1] == 0)) {
    } else {
      unnamed_idx_0 = b_y->size[0] * (Q_bar->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          E->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (Q_bar->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              E->data[ic] += Q_bar->data[ib] * b_y->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  if ((E->size[1] == 1) || (fi->size[0] == 1)) {
    i0 = twoGamaQ_barfi->size[0] * twoGamaQ_barfi->size[1];
    twoGamaQ_barfi->size[0] = E->size[0];
    twoGamaQ_barfi->size[1] = 4;
    emxEnsureCapacity_real_T(twoGamaQ_barfi, i0);
    ar = E->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        twoGamaQ_barfi->data[i0 + twoGamaQ_barfi->size[0] * i1] = 0.0;
        br = E->size[1];
        for (i2 = 0; i2 < br; i2++) {
          twoGamaQ_barfi->data[i0 + twoGamaQ_barfi->size[0] * i1] += E->data[i0
            + E->size[0] * i2] * fi->data[i2 + fi->size[0] * i1];
        }
      }
    }
  } else {
    k = E->size[1];
    b_unnamed_idx_0 = (unsigned int)E->size[0];
    i0 = twoGamaQ_barfi->size[0] * twoGamaQ_barfi->size[1];
    twoGamaQ_barfi->size[0] = (int)b_unnamed_idx_0;
    emxEnsureCapacity_real_T(twoGamaQ_barfi, i0);
    m = E->size[0];
    i0 = twoGamaQ_barfi->size[0] * twoGamaQ_barfi->size[1];
    twoGamaQ_barfi->size[1] = 4;
    emxEnsureCapacity_real_T(twoGamaQ_barfi, i0);
    for (i0 = 0; i0 < 4; i0++) {
      ar = twoGamaQ_barfi->size[0];
      for (i1 = 0; i1 < ar; i1++) {
        twoGamaQ_barfi->data[i1 + twoGamaQ_barfi->size[0] * i0] = 0.0;
      }
    }

    if (E->size[0] != 0) {
      unnamed_idx_0 = E->size[0] * 3;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          twoGamaQ_barfi->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (fi->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              twoGamaQ_barfi->data[ic] += fi->data[ib] * E->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  i0 = b_y->size[0] * b_y->size[1];
  b_y->size[0] = Gama->size[1];
  b_y->size[1] = Gama->size[0];
  emxEnsureCapacity_real_T(b_y, i0);
  ar = Gama->size[0];
  for (i0 = 0; i0 < ar; i0++) {
    br = Gama->size[1];
    for (i1 = 0; i1 < br; i1++) {
      b_y->data[i1 + b_y->size[0] * i0] = 2.0 * Gama->data[i0 + Gama->size[0] *
        i1];
    }
  }

  if ((b_y->size[1] == 1) || (Q_bar->size[0] == 1)) {
    i0 = E->size[0] * E->size[1];
    E->size[0] = b_y->size[0];
    E->size[1] = Q_bar->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = b_y->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = Q_bar->size[1];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i0 + E->size[0] * i1] = 0.0;
        k = b_y->size[1];
        for (i2 = 0; i2 < k; i2++) {
          E->data[i0 + E->size[0] * i1] += b_y->data[i0 + b_y->size[0] * i2] *
            Q_bar->data[i2 + Q_bar->size[0] * i1];
        }
      }
    }
  } else {
    k = b_y->size[1];
    b_unnamed_idx_0 = (unsigned int)b_y->size[0];
    unnamed_idx_1 = (unsigned int)Q_bar->size[1];
    i0 = E->size[0] * E->size[1];
    E->size[0] = (int)b_unnamed_idx_0;
    E->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(E, i0);
    m = b_y->size[0];
    i0 = E->size[0] * E->size[1];
    emxEnsureCapacity_real_T(E, i0);
    ar = E->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = E->size[0];
      for (i1 = 0; i1 < br; i1++) {
        E->data[i1 + E->size[0] * i0] = 0.0;
      }
    }

    if ((b_y->size[0] == 0) || (Q_bar->size[1] == 0)) {
    } else {
      unnamed_idx_0 = b_y->size[0] * (Q_bar->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          E->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (Q_bar->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              E->data[ic] += Q_bar->data[ib] * b_y->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  emxFree_real_T(&b_y);
  if ((E->size[1] == 1) || (psi->size[0] == 1)) {
    i0 = twoGamaQ_barpsi->size[0] * twoGamaQ_barpsi->size[1];
    twoGamaQ_barpsi->size[0] = E->size[0];
    twoGamaQ_barpsi->size[1] = psi->size[1];
    emxEnsureCapacity_real_T(twoGamaQ_barpsi, i0);
    ar = E->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = psi->size[1];
      for (i1 = 0; i1 < br; i1++) {
        twoGamaQ_barpsi->data[i0 + twoGamaQ_barpsi->size[0] * i1] = 0.0;
        k = E->size[1];
        for (i2 = 0; i2 < k; i2++) {
          twoGamaQ_barpsi->data[i0 + twoGamaQ_barpsi->size[0] * i1] += E->
            data[i0 + E->size[0] * i2] * psi->data[i2 + psi->size[0] * i1];
        }
      }
    }
  } else {
    k = E->size[1];
    b_unnamed_idx_0 = (unsigned int)E->size[0];
    unnamed_idx_1 = (unsigned int)psi->size[1];
    i0 = twoGamaQ_barpsi->size[0] * twoGamaQ_barpsi->size[1];
    twoGamaQ_barpsi->size[0] = (int)b_unnamed_idx_0;
    twoGamaQ_barpsi->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(twoGamaQ_barpsi, i0);
    m = E->size[0];
    i0 = twoGamaQ_barpsi->size[0] * twoGamaQ_barpsi->size[1];
    emxEnsureCapacity_real_T(twoGamaQ_barpsi, i0);
    ar = twoGamaQ_barpsi->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = twoGamaQ_barpsi->size[0];
      for (i1 = 0; i1 < br; i1++) {
        twoGamaQ_barpsi->data[i1 + twoGamaQ_barpsi->size[0] * i0] = 0.0;
      }
    }

    if ((E->size[0] == 0) || (psi->size[1] == 0)) {
    } else {
      unnamed_idx_0 = E->size[0] * (psi->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          twoGamaQ_barpsi->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (psi->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              twoGamaQ_barpsi->data[ic] += psi->data[ib] * E->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  /* F=2GamaQ_barfi*X_init+2GamaQ_barpsi*Vk */
  /* %%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%%% CONSTRAINTS MATRICES%%%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%% */
  for (i0 = 0; i0 < 4; i0++) {
    Mi[10 * i0] = 0.0;
    Mi[1 + 10 * i0] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      Mi[(i1 + 10 * i0) + 2] = -A_bar[i1 + (i0 << 2)];
      Mi[(i1 + 10 * i0) + 6] = A_bar[i1 + (i0 << 2)];
    }
  }

  /*  # of new terminal state equations created */
  i0 = w->size[0] * w->size[1];
  w->size[0] = (int)((N * 10.0 + 8.0) + 2.0);
  w->size[1] = 4;
  emxEnsureCapacity_real_T(w, i0);
  ar = (int)((N * 10.0 + 8.0) + 2.0) << 2;
  for (i0 = 0; i0 < ar; i0++) {
    w->data[i0] = 0.0;
  }

  /*   */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 10; i1++) {
      w->data[i1 + w->size[0] * i0] = Mi[i1 + 10 * i0];
    }
  }

  /*  M matrix */
  i0 = Q_bar->size[0] * Q_bar->size[1];
  Q_bar->size[0] = (int)((10.0 * N + 8.0) + 2.0);
  Q_bar->size[1] = (int)(N * 4.0);
  emxEnsureCapacity_real_T(Q_bar, i0);
  ar = (int)((10.0 * N + 8.0) + 2.0) * (int)(N * 4.0);
  for (i0 = 0; i0 < ar; i0++) {
    Q_bar->data[i0] = 0.0;
  }

  eta = 1.0;
  i0 = (int)((10.0 * (N - 1.0) + -1.0) / 10.0);
  for (m = 0; m < i0; m++) {
    rows = 11.0 + (double)m * 10.0;
    if (rows > ((rows + 8.0) + 2.0) - 1.0) {
      i1 = 0;
      i2 = 0;
    } else {
      i1 = (int)rows - 1;
      i2 = (int)((unsigned int)rows + 9U);
    }

    if (eta > (eta + 4.0) - 1.0) {
      i3 = 0;
      i4 = 0;
    } else {
      i3 = (int)eta - 1;
      i4 = (int)((unsigned int)eta + 3U);
    }

    cr = r0->size[0];
    r0->size[0] = i2 - i1;
    emxEnsureCapacity_int32_T(r0, cr);
    ar = i2 - i1;
    for (i2 = 0; i2 < ar; i2++) {
      r0->data[i2] = i1 + i2;
    }

    i1 = r1->size[0];
    r1->size[0] = i4 - i3;
    emxEnsureCapacity_int32_T(r1, i1);
    ar = i4 - i3;
    for (i1 = 0; i1 < ar; i1++) {
      r1->data[i1] = i3 + i1;
    }

    unnamed_idx_0 = r0->size[0];
    k = r1->size[0];
    for (i1 = 0; i1 < k; i1++) {
      for (i2 = 0; i2 < unnamed_idx_0; i2++) {
        Q_bar->data[r0->data[i2] + Q_bar->size[0] * r1->data[i1]] = Mi[i2 +
          unnamed_idx_0 * i1];
      }
    }

    eta += 4.0;
  }

  if (Q_bar->size[0] - 9 > Q_bar->size[0]) {
    i0 = 1;
    i1 = 0;
  } else {
    i0 = Q_bar->size[0] - 9;
    i1 = Q_bar->size[0];
  }

  eta = (N - 1.0) * 4.0 + 1.0;
  rows = N * 4.0;
  if (eta > rows) {
    i2 = 0;
    i3 = 0;
  } else {
    i2 = (int)eta - 1;
    i3 = (int)rows;
  }

  i4 = r0->size[0];
  r0->size[0] = (i1 - i0) + 1;
  emxEnsureCapacity_int32_T(r0, i4);
  ar = (i1 - i0) + 1;
  for (i1 = 0; i1 < ar; i1++) {
    r0->data[i1] = (i0 + i1) - 1;
  }

  i0 = r1->size[0];
  r1->size[0] = i3 - i2;
  emxEnsureCapacity_int32_T(r1, i0);
  ar = i3 - i2;
  for (i0 = 0; i0 < ar; i0++) {
    r1->data[i0] = i2 + i0;
  }

  for (i0 = 0; i0 < 4; i0++) {
    memset(&Mi[i0 * 10], 0, 10U * sizeof(double));
  }

  unnamed_idx_0 = r0->size[0];
  k = r1->size[0];
  for (i0 = 0; i0 < k; i0++) {
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      Q_bar->data[r0->data[i1] + Q_bar->size[0] * r1->data[i0]] = Mi[i1 +
        unnamed_idx_0 * i0];
    }
  }

  emxFree_int32_T(&r1);

  /* replacing new terminal set */
  /*   Epsilon Matrix.  */
  i0 = E->size[0] * E->size[1];
  E->size[0] = (int)((10.0 * N + 8.0) + 2.0);
  E->size[1] = (int)N;
  emxEnsureCapacity_real_T(E, i0);
  ar = (int)((10.0 * N + 8.0) + 2.0) * (int)N;
  for (i0 = 0; i0 < ar; i0++) {
    E->data[i0] = 0.0;
  }

  eta = 1.0;
  i0 = (int)((10.0 * N + 9.0) / 10.0);
  for (m = 0; m < i0; m++) {
    rows = 1.0 + (double)m * 10.0;
    if (rows > (rows + 8.0) + 1.0) {
      i1 = 0;
      i2 = 0;
    } else {
      i1 = (int)rows - 1;
      i2 = (int)((unsigned int)rows + 9U);
    }

    i3 = r0->size[0];
    r0->size[0] = i2 - i1;
    emxEnsureCapacity_int32_T(r0, i3);
    ar = i2 - i1;
    for (i2 = 0; i2 < ar; i2++) {
      r0->data[i2] = i1 + i2;
    }

    unnamed_idx_0 = r0->size[0];
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      E->data[r0->data[i1] + E->size[0] * ((int)eta - 1)] = Ei[i1];
    }

    eta++;
  }

  /*  c Matrix */
  i0 = c->size[0];
  c->size[0] = (int)((10.0 * N + 8.0) + 2.0);
  emxEnsureCapacity_real_T1(c, i0);
  ar = (int)((10.0 * N + 8.0) + 2.0);
  for (i0 = 0; i0 < ar; i0++) {
    c->data[i0] = 0.0;
  }

  i0 = (int)((10.0 * N + 9.0) / 10.0);
  for (m = 0; m < i0; m++) {
    rows = 1.0 + (double)m * 10.0;
    if (rows > (rows + 8.0) + 1.0) {
      i1 = 0;
      i2 = 0;
    } else {
      i1 = (int)rows - 1;
      i2 = (int)((unsigned int)rows + 9U);
    }

    i3 = r0->size[0];
    r0->size[0] = i2 - i1;
    emxEnsureCapacity_int32_T(r0, i3);
    ar = i2 - i1;
    for (i2 = 0; i2 < ar; i2++) {
      r0->data[i2] = i1 + i2;
    }

    unnamed_idx_0 = r0->size[0];
    for (i1 = 0; i1 < unnamed_idx_0; i1++) {
      c->data[r0->data[i1]] = bi[i1];
    }
  }

  if (c->size[0] - 9 > c->size[0]) {
    i0 = 1;
    i1 = 0;
  } else {
    i0 = c->size[0] - 9;
    i1 = c->size[0];
  }

  i2 = r0->size[0];
  r0->size[0] = (i1 - i0) + 1;
  emxEnsureCapacity_int32_T(r0, i2);
  ar = (i1 - i0) + 1;
  for (i1 = 0; i1 < ar; i1++) {
    r0->data[i1] = (i0 + i1) - 1;
  }

  memset(&dv3[0], 0, 10U * sizeof(double));
  unnamed_idx_0 = r0->size[0];
  for (i0 = 0; i0 < unnamed_idx_0; i0++) {
    c->data[r0->data[i0]] = dv3[i0];
  }

  emxFree_int32_T(&r0);

  /* replacing new terminal set */
  /*  L*Uk<=c+Wx(k) % Eliminanting Xk using prediction matrices (Xk=fi*x(k)+Gama*Uk+psi*Vk) */
  /*  L and W Matrix */
  if ((Q_bar->size[1] == 1) || (Gama->size[0] == 1)) {
    i0 = L->size[0] * L->size[1];
    L->size[0] = Q_bar->size[0];
    L->size[1] = Gama->size[1];
    emxEnsureCapacity_real_T(L, i0);
    ar = Q_bar->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = Gama->size[1];
      for (i1 = 0; i1 < br; i1++) {
        L->data[i0 + L->size[0] * i1] = 0.0;
        k = Q_bar->size[1];
        for (i2 = 0; i2 < k; i2++) {
          L->data[i0 + L->size[0] * i1] += Q_bar->data[i0 + Q_bar->size[0] * i2]
            * Gama->data[i2 + Gama->size[0] * i1];
        }
      }
    }
  } else {
    k = Q_bar->size[1];
    b_unnamed_idx_0 = (unsigned int)Q_bar->size[0];
    unnamed_idx_1 = (unsigned int)Gama->size[1];
    i0 = L->size[0] * L->size[1];
    L->size[0] = (int)b_unnamed_idx_0;
    L->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(L, i0);
    m = Q_bar->size[0];
    i0 = L->size[0] * L->size[1];
    emxEnsureCapacity_real_T(L, i0);
    ar = L->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = L->size[0];
      for (i1 = 0; i1 < br; i1++) {
        L->data[i1 + L->size[0] * i0] = 0.0;
      }
    }

    if ((Q_bar->size[0] == 0) || (Gama->size[1] == 0)) {
    } else {
      unnamed_idx_0 = Q_bar->size[0] * (Gama->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          L->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (Gama->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              L->data[ic] += Gama->data[ib] * Q_bar->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  emxFree_real_T(&Gama);
  i0 = L->size[0] * L->size[1];
  emxEnsureCapacity_real_T(L, i0);
  k = L->size[0];
  unnamed_idx_0 = L->size[1];
  ar = k * unnamed_idx_0;
  for (i0 = 0; i0 < ar; i0++) {
    L->data[i0] += E->data[i0];
  }

  emxFree_real_T(&E);
  if ((Q_bar->size[1] == 1) || (fi->size[0] == 1)) {
    i0 = C->size[0] * C->size[1];
    C->size[0] = Q_bar->size[0];
    C->size[1] = 4;
    emxEnsureCapacity_real_T(C, i0);
    ar = Q_bar->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        C->data[i0 + C->size[0] * i1] = 0.0;
        br = Q_bar->size[1];
        for (i2 = 0; i2 < br; i2++) {
          C->data[i0 + C->size[0] * i1] += Q_bar->data[i0 + Q_bar->size[0] * i2]
            * fi->data[i2 + fi->size[0] * i1];
        }
      }
    }
  } else {
    k = Q_bar->size[1];
    b_unnamed_idx_0 = (unsigned int)Q_bar->size[0];
    i0 = C->size[0] * C->size[1];
    C->size[0] = (int)b_unnamed_idx_0;
    emxEnsureCapacity_real_T(C, i0);
    m = Q_bar->size[0];
    i0 = C->size[0] * C->size[1];
    C->size[1] = 4;
    emxEnsureCapacity_real_T(C, i0);
    for (i0 = 0; i0 < 4; i0++) {
      ar = C->size[0];
      for (i1 = 0; i1 < ar; i1++) {
        C->data[i1 + C->size[0] * i0] = 0.0;
      }
    }

    if (Q_bar->size[0] != 0) {
      unnamed_idx_0 = Q_bar->size[0] * 3;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          C->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (fi->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              C->data[ic] += fi->data[ib] * Q_bar->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  emxFree_real_T(&fi);
  i0 = w->size[0] * w->size[1];
  w->size[1] = 4;
  emxEnsureCapacity_real_T(w, i0);
  k = w->size[0];
  unnamed_idx_0 = w->size[1];
  ar = k * unnamed_idx_0;
  for (i0 = 0; i0 < ar; i0++) {
    w->data[i0] = -w->data[i0] - C->data[i0];
  }

  emxFree_real_T(&C);
  if ((Q_bar->size[1] == 1) || (psi->size[0] == 1)) {
    i0 = Mpsi->size[0] * Mpsi->size[1];
    Mpsi->size[0] = Q_bar->size[0];
    Mpsi->size[1] = psi->size[1];
    emxEnsureCapacity_real_T(Mpsi, i0);
    ar = Q_bar->size[0];
    for (i0 = 0; i0 < ar; i0++) {
      br = psi->size[1];
      for (i1 = 0; i1 < br; i1++) {
        Mpsi->data[i0 + Mpsi->size[0] * i1] = 0.0;
        k = Q_bar->size[1];
        for (i2 = 0; i2 < k; i2++) {
          Mpsi->data[i0 + Mpsi->size[0] * i1] += Q_bar->data[i0 + Q_bar->size[0]
            * i2] * psi->data[i2 + psi->size[0] * i1];
        }
      }
    }
  } else {
    k = Q_bar->size[1];
    b_unnamed_idx_0 = (unsigned int)Q_bar->size[0];
    unnamed_idx_1 = (unsigned int)psi->size[1];
    i0 = Mpsi->size[0] * Mpsi->size[1];
    Mpsi->size[0] = (int)b_unnamed_idx_0;
    Mpsi->size[1] = (int)unnamed_idx_1;
    emxEnsureCapacity_real_T(Mpsi, i0);
    m = Q_bar->size[0];
    i0 = Mpsi->size[0] * Mpsi->size[1];
    emxEnsureCapacity_real_T(Mpsi, i0);
    ar = Mpsi->size[1];
    for (i0 = 0; i0 < ar; i0++) {
      br = Mpsi->size[0];
      for (i1 = 0; i1 < br; i1++) {
        Mpsi->data[i1 + Mpsi->size[0] * i0] = 0.0;
      }
    }

    if ((Q_bar->size[0] == 0) || (psi->size[1] == 0)) {
    } else {
      unnamed_idx_0 = Q_bar->size[0] * (psi->size[1] - 1);
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        i0 = cr + m;
        for (ic = cr; ic + 1 <= i0; ic++) {
          Mpsi->data[ic] = 0.0;
        }

        cr += m;
      }

      br = 0;
      cr = 0;
      while ((m > 0) && (cr <= unnamed_idx_0)) {
        ar = 0;
        i0 = br + k;
        for (ib = br; ib + 1 <= i0; ib++) {
          if (psi->data[ib] != 0.0) {
            ia = ar;
            i1 = cr + m;
            for (ic = cr; ic + 1 <= i1; ic++) {
              ia++;
              Mpsi->data[ic] += psi->data[ib] * Q_bar->data[ia - 1];
            }
          }

          ar += m;
        }

        br += k;
        cr += m;
      }
    }
  }

  emxFree_real_T(&Q_bar);
  emxFree_real_T(&psi);

  /* bi=c+W*x_init+Mpsi*Vk; */
}

/* End of code generation (matrix_init.c) */
