/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * diag.c
 *
 * Code generation for function 'diag'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matrix_init.h"
#include "diag.h"

/* Function Definitions */
void diag(const double v[4], double d[16])
{
  int j;
  memset(&d[0], 0, sizeof(double) << 4);
  for (j = 0; j < 4; j++) {
    d[j + (j << 2)] = v[j];
  }
}

/* End of code generation (diag.c) */
