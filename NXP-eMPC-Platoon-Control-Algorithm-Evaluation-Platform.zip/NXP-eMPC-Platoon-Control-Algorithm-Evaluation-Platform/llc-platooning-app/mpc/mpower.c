/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mpower.c
 *
 * Code generation for function 'mpower'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matrix_init.h"
#include "mpower.h"
#include "matrix_to_integer_power.h"
#include "inv.h"

/* Function Definitions */
void mpower(const double a[16], double b, double c[16])
{
  double b_a[16];
  int i5;
  double e;
  boolean_T firstmult;
  int exitg1;
  double ed2;
  int i6;
  double b_c[16];
  int i7;
  if (floor(b) == b) {
    memcpy(&b_a[0], &a[0], sizeof(double) << 4);
    if (2.147483647E+9 >= fabs(b)) {
      memcpy(&b_a[0], &a[0], sizeof(double) << 4);
      matrix_to_small_integer_power(b_a, b, c);
    } else if ((!rtIsInf(b)) && (!rtIsNaN(b))) {
      e = fabs(b);
      firstmult = true;
      do {
        exitg1 = 0;
        ed2 = floor(e / 2.0);
        if (2.0 * ed2 != e) {
          if (firstmult) {
            memcpy(&c[0], &b_a[0], sizeof(double) << 4);
            firstmult = false;
          } else {
            for (i5 = 0; i5 < 4; i5++) {
              for (i6 = 0; i6 < 4; i6++) {
                b_c[i5 + (i6 << 2)] = 0.0;
                for (i7 = 0; i7 < 4; i7++) {
                  b_c[i5 + (i6 << 2)] += c[i5 + (i7 << 2)] * b_a[i7 + (i6 << 2)];
                }
              }
            }

            for (i5 = 0; i5 < 4; i5++) {
              for (i6 = 0; i6 < 4; i6++) {
                c[i6 + (i5 << 2)] = b_c[i6 + (i5 << 2)];
              }
            }
          }
        }

        if (ed2 == 0.0) {
          exitg1 = 1;
        } else {
          e = ed2;
          for (i5 = 0; i5 < 4; i5++) {
            for (i6 = 0; i6 < 4; i6++) {
              b_c[i5 + (i6 << 2)] = 0.0;
              for (i7 = 0; i7 < 4; i7++) {
                b_c[i5 + (i6 << 2)] += b_a[i5 + (i7 << 2)] * b_a[i7 + (i6 << 2)];
              }
            }
          }

          for (i5 = 0; i5 < 4; i5++) {
            for (i6 = 0; i6 < 4; i6++) {
              b_a[i6 + (i5 << 2)] = b_c[i6 + (i5 << 2)];
            }
          }
        }
      } while (exitg1 == 0);

      if (b < 0.0) {
        memcpy(&b_c[0], &c[0], sizeof(double) << 4);
        invNxN(b_c, c);
      }
    } else {
      for (i5 = 0; i5 < 16; i5++) {
        c[i5] = rtNaN;
      }
    }
  }
}

/* End of code generation (mpower.c) */
