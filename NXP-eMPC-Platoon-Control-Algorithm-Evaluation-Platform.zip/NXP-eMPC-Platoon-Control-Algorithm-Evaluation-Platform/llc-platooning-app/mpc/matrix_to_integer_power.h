/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_to_integer_power.h
 *
 * Code generation for function 'matrix_to_integer_power'
 *
 */

#ifndef MATRIX_TO_INTEGER_POWER_H
#define MATRIX_TO_INTEGER_POWER_H

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "matrix_init_types.h"

/* Function Declarations */
extern void matrix_to_small_integer_power(double a[16], double b, double c[16]);

#endif

/* End of code generation (matrix_to_integer_power.h) */
