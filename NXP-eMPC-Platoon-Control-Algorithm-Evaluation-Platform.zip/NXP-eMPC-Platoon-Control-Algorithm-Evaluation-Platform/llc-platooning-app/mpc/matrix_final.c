/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_final.c
 *
 * Code generation for function 'matrix_final'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "matrix_final.h"
#include "matrix_init_emxutil.h"
#include <stdio.h>

/* Function Definitions */
void matrix_final(double gap, double v0, double a0, double da0, double vTarget, double aTarget, double d0, 
	const double twoGamaQ_barfi[60], const double twoGamaQ_barpsi[225], const double w[640],
  const double Mpsi[2400], const double c[160], double tauh, double N, double F[15], double bi[160])//,int pos)
{
  double x_init[4];
  emxArray_real_T *b_aTarget;
  int ib;
  //double y[160];
  int ar;
  int ia;
  int ic;
  double b_y;
  double c_y[15];

  /*      %%  */
  /* a_p=aTarget; % acceleration of the preceding vehicle (change it to aTarget) */
  /* v_p=vTarget; % velocity of preceding vehicle (change later to vTarget) */
  /* d_max=60; %maximum distance gap between vehicles  */
  /* d0=5; %minmum distance gap between vehicles (standstill + vehicle length) */
  x_init[0] = a0;
  x_init[1] = da0;
  x_init[2] = (gap)-d0-tauh*v0;
  x_init[3] = vTarget-v0;
/*if (pos == 2)*/
/*fprintf(stderr,"aTarget= %f, a0= %f, da0= %f, dq= %f, dv= %f\n",aTarget, x_init[0],x_init[1],x_init[2],x_init[3]);*/
  emxInit_real_T(&b_aTarget, 1);
/*  if ((int)N == 1) {*/
/*    ib = b_aTarget->size[0];*/
/*    b_aTarget->size[0] = (int)N;*/
/*    emxEnsureCapacity_real_T(b_aTarget, ib);*/
/*    ar = (int)N;*/
/*    for (ib = 0; ib < ar; ib++) {*/
/*      b_aTarget->data[ib] = aTarget;*/
/*    }*/

/*    for (ib = 0; ib < 160; ib++) {*/
/*      y[ib] = 0.0;*/
/*      for (ar = 0; ar < 15; ar++) {*/
/*        b_y = y[ib] + Mpsi[ib + 160 * ar] * b_aTarget->data[ar];*/
/*        y[ib] = b_y;*/
/*      }*/
/*    }*/
/*  } else if (15 == (int)N) {*/
/*    ib = b_aTarget->size[0];*/
/*    b_aTarget->size[0] = (int)N;*/
/*    emxEnsureCapacity_real_T(b_aTarget, ib);*/
/*    ar = (int)N;*/
/*    for (ib = 0; ib < ar; ib++) {*/
/*      b_aTarget->data[ib] = aTarget;*/
/*    }*/

/*    for (ib = 0; ib < 160; ib++) {*/
/*      y[ib] = 0.0;*/
/*      for (ar = 0; ar < 15; ar++) {*/
/*        b_y = y[ib] + Mpsi[ib + 160 * ar] * b_aTarget->data[ar];*/
/*        y[ib] = b_y;*/
/*      }*/
/*    }*/
/*  } else {*/
/*    memset(&y[0], 0, 160U * sizeof(double));*/
/*    ar = -1;*/
/*    for (ib = 0; ib < 15; ib++) {*/
/*      if (aTarget != 0.0) {*/
/*        ia = ar;*/
/*        for (ic = 0; ic < 160; ic++) {*/
/*          ia++;*/
/*          y[ic] += aTarget * Mpsi[ia];*/
/*        }*/
/*      }*/

/*      ar += 160;*/
/*    }*/
/*  }*/

/*  for (ib = 0; ib < 160; ib++) {*/
/*    b_y = 0.0;*/
/*    for (ar = 0; ar < 4; ar++) {*/
/*      b_y += w[ib + 160 * ar] * x_init[ar];*/
/*    }*/
/*    bi[ib] = (c[ib] + b_y) + y[ib];*/
/*  }*/

  if ((int)N == 1) {
    ib = b_aTarget->size[0];
    b_aTarget->size[0] = (int)N;
    emxEnsureCapacity_real_T(b_aTarget, ib);
    ar = (int)N;
    for (ib = 0; ib < ar; ib++) {
      b_aTarget->data[ib] = aTarget;
    }

    for (ib = 0; ib < 15; ib++) {
      c_y[ib] = 0.0;
      for (ar = 0; ar < 15; ar++) {
        b_y = c_y[ib] + twoGamaQ_barpsi[ib + 15 * ar] * b_aTarget->data[ar];
        c_y[ib] = b_y;
      }
    }
  } else if (15 == (int)N) {
    ib = b_aTarget->size[0];
    b_aTarget->size[0] = (int)N;
    emxEnsureCapacity_real_T(b_aTarget, ib);
    ar = (int)N;
    for (ib = 0; ib < ar; ib++) {
      b_aTarget->data[ib] = aTarget;
    }

    for (ib = 0; ib < 15; ib++) {
      c_y[ib] = 0.0;
      for (ar = 0; ar < 15; ar++) {
        b_y = c_y[ib] + twoGamaQ_barpsi[ib + 15 * ar] * b_aTarget->data[ar];
        c_y[ib] = b_y;
      }
    }
  } else {
    memset(&c_y[0], 0, 15U * sizeof(double));
    ar = -1;
    for (ib = 0; ib < 15; ib++) {
      if (aTarget != 0.0) {
        ia = ar;
        for (ic = 0; ic < 15; ic++) {
          ia++;
          c_y[ic] += aTarget * twoGamaQ_barpsi[ia];
        }
      }

      ar += 15;
    }
  }

  emxFree_real_T(&b_aTarget);
  for (ib = 0; ib < 15; ib++) {
    b_y = 0.0;
    for (ar = 0; ar < 4; ar++) {
      b_y += twoGamaQ_barfi[ib + 15 * ar] * x_init[ar];
    }

    F[ib] = b_y + c_y[ib];
  }
}

/* End of code generation (matrix_final.c) */
