/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * FGM.c
 *
 * Code generation for function 'FGM'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "FGM.h"
/* Function Definitions */

/*
 * function [u_start]=FGM(umin,umax,eta,mu,L,G,old_u,F,N)
 */
void FGM(double umin, double umax, double eta, double mu, double L, const double
         G[225], const double old_u[15], const double F[15], double N, double
         u_start[15])
{
  double v_old[15];
  double w[15];
  double dpower2;
  double x;
  double b_dpower2;
  int i;
  int b_i;
  double d0;
  int i0;

  /*  mu = eigs(G,1,'sm'); % min eigenvalue */
  /*  L = eigs(G,1);% max eigenvalue */
  /*  v_init = [-3.5 -3.5 -3.5;-3.5 -3.5 -3.5;-3.5 -3.5 -3.5]; */
  /*  w_init = [-1.5 -1.5 -1.5;-1.5 -1.5 -1.5;-1.5 -1.5 -1.5]; */
  /* 'FGM:11' v_init = old_u; */
  /* 'FGM:12' w_init = old_u; */
  /* 'FGM:13' v_old = v_init; */
  /* 'FGM:14' v = v_init; */
  /* 'FGM:15' w = w_init; */
  memcpy(&v_old[0], &old_u[0], 15U * sizeof(double));
  memcpy(&u_start[0], &old_u[0], 15U * sizeof(double));
  memcpy(&w[0], &old_u[0], 15U * sizeof(double));

  /* 'FGM:16' li = umin; */
  /* 'FGM:17' ri = umax; */
  /* 'FGM:19' dpower2 = N*((ri-li)^2)/2; */
  dpower2 = umax - umin;
  dpower2 = N * (dpower2 * dpower2) / 2.0;

  /* 'FGM:20' i_max = min((log(2*eta)-log(L*dpower2)/(log(1-sqrt(mu/L)))),(sqrt((2*L*dpower2)/eta)-2)); */
  x = sqrt(2.0 * L * dpower2 / eta);
  dpower2 = log(2.0 * eta) - log(L * dpower2) / log(1.0 - sqrt(mu / L));

  /* 'FGM:21' i_max=ceil(i_max); */
  if ((dpower2 < x - 2.0) || rtIsNaN(x - 2.0)) {
    b_dpower2 = dpower2;
  } else {
    b_dpower2 = x - 2.0;
  }

  dpower2 = ceil(b_dpower2);
  /* t_ex = cputime; */
  /* 'FGM:23' for i = 1:i_max + 10 */
  for (i = 0; i < (int)(dpower2 + 10.0); i++) {
    /* 'FGM:24' v = w - (1/L)*(G*w + F); */
    x = 1.0 / L;
    for (b_i = 0; b_i < 15; b_i++) {
      d0 = 0.0;
      for (i0 = 0; i0 < 15; i0++) {
        d0 += G[b_i + 15 * i0] * w[i0];
      }

      u_start[b_i] = w[b_i] - x * (d0 + F[b_i]);
    }
    /*      if v < li */
    /*         v = li; */
    /*      elseif v > ri */
    /*          v = ri; */
    /*      else  */
    /* 'FGM:30' w = v + ((sqrt(L)-sqrt(mu))/(sqrt(L)+sqrt(mu)))*(v - v_old); */
    x = (sqrt(L) - sqrt(mu)) / (sqrt(L) + sqrt(mu));

    /*     end   */
    /* 'FGM:32' v_old = v; */
    for (b_i = 0; b_i < 15; b_i++) {
      w[b_i] = u_start[b_i] + x * (u_start[b_i] - v_old[b_i]);
      v_old[b_i] = u_start[b_i];
    }
  }
  /* e_myMinimizer = cputime-t_ex */
  /* 'FGM:35' u_start=v(:,1); */
  /* 'FGM:36' old_u=v(:,1); */
}

void FGM_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

void FGM_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (FGM.c) */
