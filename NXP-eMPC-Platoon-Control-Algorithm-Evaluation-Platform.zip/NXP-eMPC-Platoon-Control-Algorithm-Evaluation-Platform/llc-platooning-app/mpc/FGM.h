/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * FGM.h
 *
 * Code generation for function 'FGM'
 *
 */

#ifndef FGM_H
#define FGM_H

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"

/* Function Declarations */
extern void FGM(double umin, double umax, double eta, double mu, double L, const
                double G[225], const double old_u[15], const double F[15],
                double N, double u_start[15]);
extern void FGM_initialize(void);
extern void FGM_terminate(void);

#endif

/* End of code generation (FGM.h) */
