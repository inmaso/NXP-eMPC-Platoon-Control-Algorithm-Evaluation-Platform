/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * matrix_final.h
 *
 * Code generation for function 'matrix_final'
 *
 */

#ifndef MATRIX_FINAL_H
#define MATRIX_FINAL_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "matrix_init_types.h"

/* Function Declarations */
extern void matrix_final(double gap, double v0, double a0, double da0, double vTarget, double aTarget, double d0, 
	const double twoGamaQ_barfi[60], const double twoGamaQ_barpsi[225], const double w[640],
  const double Mpsi[2400], const double c[160], double tauh, double N, double F[15], double bi[160]);//, int pos);

#endif

/* End of code generation (matrix_final.h) */
