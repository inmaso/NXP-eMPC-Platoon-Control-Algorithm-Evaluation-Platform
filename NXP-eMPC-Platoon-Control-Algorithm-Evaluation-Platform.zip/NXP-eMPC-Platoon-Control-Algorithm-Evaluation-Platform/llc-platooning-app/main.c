/**
 * @section main function
 * @author Sijie Zhu
 * @date May/2018
 * @copyright NXP Semiconductors NV
 * @file
 * main function: starts a node of the platoon control algorithm validation framework,
 * which is configured as leader node (LN), follower node (FN) or the virtual node (VN).
 * The main function parses the configuration file, starts the relavent threads and manages
 * the threads properly until the test ends.
 *
 */
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/if_tun.h>
#include <linux/serial.h>
#include <net/if.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#include "debug-levels.h"
#include <linux/cohda/llc/llc.h>

#include "V2X-lib.h"
#include "readConfig.h"

#include "version.h"
// customized
#include "controller.h"
#include <netdb.h>
/// App/command state
struct MyApp _Dev = {
    .pMKx = NULL,
    .Exit = false,
};
struct MyApp *pDev = &(_Dev);
double *profileData;
extern int enableLED;
/**
 * @brief Help information
 *
 */
static void PrintUsage(void) {
  fprintf(stderr,
          "Usage: llc-communication-test [OPTION...]\n"
          "\n"
          "  -h                 Print this help output\n"
          "  -f <conf-file>     Name of the configuration file (mandatory)\n"
          "  -v                 Increase the verbose level.\n"
          "  -l                 Toggle LED on transmission."
          "\n");
}
/**
 * @brief Parse the console commands
 * @param Argc   command line argument count
 * @param ppArgv command line parameter list
 *
 */
void parseCommand(int Argc, char **ppArgv) {
  int C;
  int lResult;
  char fileName[FILENAME_BUFFER_SIZE + 1];
  memset(fileName, '\0', FILENAME_BUFFER_SIZE + 1);
  // parse command line options using getopt() for POSIX compatibility
  while ((C = getopt(Argc, ppArgv, "+h?vf:l")) != -1) {
    switch (C) {
    case 'h':
      PrintUsage();
      exit(0);
      break;

    case 'f':
      strcpy(fileName, optarg);
      if (strlen(fileName) == 0) {
        d_error(D_ERR, NULL,
                "Must specify the filename containing the configuration\n");
        PrintUsage();
        exit(10);
      } else {
        // Read the configuration
        memset(&(pDev->Config), '\0', sizeof(pDev->Config));
        lResult = readConfig(fileName, &(pDev->Config));
        if (lResult != 0) {
          d_printf(D_ERR, NULL, "Error reading the configuration: %d\n",
                   lResult);
          PrintUsage();
          exit(1);
        }
      }
      break;

    case 'l':
      enableLED++;
      break;
    case 'v':
      verbose++;
      d_printf(D_DBG, NULL, "Verbose level set to: %d\n", verbose);
      break;

    case '?':
      if (isprint(optopt))
        d_error(D_ERR, NULL, "Unknown option '-%c'\n", optopt);
      else
        d_printf(D_ERR, NULL, "Unknown option character `\\x%x'\n", optopt);
      exit(2);

    default:
      d_assert(0);
      break;
    }
  }
}
/**
 * @brief Convert the index into specific encoding method
 * @param cval index of the encoding method
 * @return a string indecating modulation method
 */
char *condingToStr(uint8_t cval) {
  switch (cval) {
  case MKXMCS_R12BPSK:
    return "MKXMCS_R12BPSK";
    break;
  case MKXMCS_R34BPSK:
    return "MKXMCS_R34BPSK";
    break;
  case MKXMCS_R12QPSK:
    return "MKXMCS_R12QPSK";
    break;
  case MKXMCS_R34QPSK:
    return "MKXMCS_R34QPSK";
    break;
  case MKXMCS_R12QAM16:
    return "MKXMCS_R12QAM16";
    break;
  case MKXMCS_R34QAM16:
    return "MKXMCS_R34QAM16";
    break;
  case MKXMCS_R23QAM64:
    return "MKXMCS_R23QAM64";
    break;
  case MKXMCS_R34QAM64:
    return "MKXMCS_R34QAM64";
    break;
  default:
    break;
  }
  return "UNKNOWN";
}
/**
 * @brief Print the configurations of the current test
 *
 */
void PrintConfig(void) {
  printf("Configuration:\n");
  printf("  Radio    = %s\n",
         (pDev->Config.LLC.LLCRadio == MKX_RADIO_A) ? "A" : "B");
  printf("  Channel  = %d (%d MHz)\n", pDev->Config.LLC.LLCChannelNo,
         (5000 + (pDev->Config.LLC.LLCChannelNo * 5)));
  printf("  Bitrate  = %d\n", pDev->Config.LLC.LLCBitrate);
  printf("  Coding   = %s\n", condingToStr(pDev->Config.LLC.LLCCoding));
  printf("  Delay    = %f msec\n", pDev->Config.LLC.LLCDelay);
  printf("  Role     = %d\n", pDev->Config.LLC.LLCRole);

  if (pDev->Config.LLC.CACCAccler == 2)
    printf(" Adaptive Cruise Control Mode\n");
  else
    printf("  CACC Mode: Transmitting %s\n", (pDev->Config.LLC.CACCAccler == 0)
                                                 ? "Desired Acceleration"
                                                 : "Actual Acceleration");

  printf("  HLC_Inteval   = %d msec\n", pDev->Config.LLC.CACCHlc);
  // printf ("  High level Frequency   = %d Hz\n", pDev->Config.LLC.CACCHlc);
  printf("  Time Headway   = %.1f sec\n", pDev->Config.LLC.CACCHeadway);
  printf("  Engine Lag Time Constant   = %.1f sec\n",
         pDev->Config.LLC.CACCEnginelag);
}
/**
 * @brief Controller Threads Management
 * @return Zero if successful, otherwise a negative errno
 */
int ControllerThreadManagement() {
	int s;
  pthread_attr_t attr;
  pthread_attr_t *attrp;
  struct sched_param param;

	s = pthread_attr_init(&attr);
	if (s != 0)
		 fprintf(stderr, "pthread_attr_init(%d)\n",s);
	attrp = &attr;
  
  s = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
  if (s != 0)
     fprintf(stderr, "pthread_attr_setinheritsched(%d)\n",s);
  s = pthread_attr_setschedpolicy(&attr, SCHED_RR);
  if (s != 0)
     fprintf(stderr, "pthread_attr_setschedpolicy(%d)\n",s);
  param.sched_priority=20;
  s = pthread_attr_setschedparam(&attr, &param);
  if (s != 0)
     fprintf(stderr, "pthread_attr_setschedparam(%d)\n",s);

  pthread_t low_level;
	s=pthread_create(&low_level, attrp, low_level_thread, NULL);
  if (s != 0) {
    fprintf(stderr, "Error creating low_level_thread(%d)\n",s);
    return 1;
  }

  if (pDev->Config.LLC.LLCRole == 1) {
    //  Leader (LN)
    pthread_t sendingThread;
    if (pthread_create(&sendingThread, attrp, sendingThreadRadar, NULL)) {
      fprintf(stderr, "Error creating sendingThreadRadar thread\n");
      return 1;
    }
    pthread_t high_level;

    param.sched_priority=40;
    s = pthread_attr_setschedparam(&attr, &param);
    if (s != 0)
       fprintf(stderr, "pthread_attr_setschedparam(%d)\n",s);

    if (pthread_create(&high_level, attrp, high_level_thread, NULL)) {
      fprintf(stderr, "Error creating high_level_thread\n");
      return 1;
    }

  } else if ((pDev->Config.LLC.LLCRole > 1) &&
             (pDev->Config.LLC.LLCRole != 255)) {
    //  Followers (FN)
    pthread_t receivingThread;
    if (pthread_create(&receivingThread, attrp, receivingThreadRadar, NULL)) {
      fprintf(stderr, "Error creating receivingThreadRadar thread\n");
      return 1;
    }
    pthread_t sendingThread;
    if (pthread_create(&sendingThread, attrp, sendingThreadRadar, NULL)) {
      fprintf(stderr, "Error creating sendingThreadRadar thread\n");
      return 1;
    }

    pthread_t high_level;

    param.sched_priority=40;
    s = pthread_attr_setschedparam(&attr, &param);
    if (s != 0)
       fprintf(stderr, "pthread_attr_setschedparam(%d)\n",s);

    if (pthread_create(&high_level, attrp, high_level_thread, NULL)) {
      fprintf(stderr, "Error creating high_level_thread\n");
      return 1;
    }

  }
  return 0;
}
/**
 * @brief Application entry point
 * @param argc Number of command line arguments
 * @param argv Array of command line arguments
 * @return Zero if successful, otherwise a negative errno
 */
int main(int Argc, char **ppArgv) {
  int res;
  parseCommand(Argc, ppArgv);
  PrintConfig();
	srand(clock());
	// char *profilename = "amr_profile1.csv";
  char *profilename = "a_stringstability_100Hz.csv";
  // char *profilename = "a_real_100Hz.csv";
  // char *profilename = "a_quicktest_100Hz.csv";
  profileData = readSimulationProfile(profilename);
  res = ControllerThreadManagement();
	fprintf(stderr, "Vehicle %d starting\n", pDev->Config.LLC.LLCRole);
  if (InitPlatooning() != 0) {
    fprintf(stderr,"\nLLC Initialization Failed!\n");
  } else {
    //fprintf(stderr,"\nLLC Interface Initialized!\n");
    res = DisseminationBasicService();
    fprintf(stderr,"\nAt the end of plattoning-test\n");
  }
	fflush(stdout);
	fflush(stderr);
  return res;
}
