#!/usr/bin/env bash
make clean
make
sshpass -p 'user' scp /home/duser/Desktop/cvxgen10/testsolver user@[fe80::6e5:48ff:fe20:00ec%eth1]:/home/user
sshpass -p 'user' ssh user@fe80::6e5:48ff:fe20:00ec%eth1 "/home/user/testsolver;rm /home/user/testsolver"
