/**
 * @section nxp_llc_examples readConfig
 *
 * @copyright NXP Semiconductors NV
 * @file
 * readConfig.c: Read the configurations of the test setup
 */
/*
 * readConfig.c
 *
 *  Created on: Feb 15, 2016
 *      Author: Han Raaijmakers
 */
//---------------------------------------------------------------------------
// Copyright (c) 2015 NXP Semiconductors NV
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Included headers
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <netinet/in.h>
#include <poll.h>
#include <net/if.h>
#include <linux/if_tun.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <termios.h>
#include <stdint.h>
#include <time.h>
#include <linux/serial.h>
#include <pthread.h>

#include "debug-levels.h"
#include <linux/cohda/llc/llc.h>

#include "V2X-lib.h"
#include "readConfig.h"

//------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------

/**
 * @brief getlabel, read line from fw_printenv environment
 * @param s, pointer to line of environment
 * @param lab, returns pointer to start of string
 * @param value, returns pointer to start of label
 */
void getlabel(char *s, char **lab, char **value)
{

  *lab = s;
  while (*s && (*s != '=')) s++;

  if (*s == '=') {
    *s++ = '\0';
    *value = s;
    while (*s && (*s != '\n')) s++;
    *s = '\0';
  }
}

/**
 * @brief getEnvParam, read parameter value from environment file
 *       /tmp/fw_printenv. This file should have been filled with
 *       fw_printenv > /tmp/fw_printenv
 * @param param, pointer to string containing the searched parameter
 * @param value, pointer to the value of the string (if found)
 * @param maxlen, maximum number of bytes in buffer (including terminator)
 * @return 1 if parameter found, otherwise 0
 */
int getEnvParam(char *param, char *value, int maxlen)
{
   FILE *fp;
   char line[1024];
   char *label, *val;
   int  lcnt = 0, rval = 0;

   fp = fopen("/tmp/fw_printenv", "rt");
   while (fgets(line, 1023, fp)) {
     lcnt++;
     getlabel(line, &label, &val);
     if (strcmp(label, param) == 0) {
    	 if (verbose) {
           printf("%d:%s value found: '%s'\n", lcnt, param, val);
    	 }
         strncpy(value, val, maxlen-1);
         value[maxlen-1] = '\0';
         rval = 1;
     }
   }
   fclose(fp);

   return(rval);
}

/**
 * @brief getByte, convert hexbyte string to binary
 * @param s, pointer to text string
 * @return if found value first two characters, otherwise -1
 *
 */
int getByte(char *s)
{
	char p[3];
	int  rval;

	strncpy(p, s, 2);
	if (sscanf(p, "%x", &rval) == 1) {
		return (rval & 0xFF);
	} else {
		return -1;
	}
}

/**
 * @brief getAddr, read MAC address from text string
 * @param s, pointer to text string, ':' allowed between hex bytes
 * @param addr, pointer to start of 6 byte output buffer
 * @return if found, returns 1 and MAC in addr buffer, otherwise 0 is returned
 *
 */
int getAddr(char *s, uint8_t *addr)
{
	int rval = 1;
	int i = 0, v;

	while ((i < 6) && rval && *s) {
		v = getByte(s);
		s += 2;
		while (*s && (*s == ':')) s++;
		if (v < 0) {
			rval = 0;
		} else {
			*addr++ = (uint8_t) (v & 0xFF);
			i++;
		}
	}
	return rval;
}

/**
 * @brief conCoding, convert datarate into channel decoding
 * @param sval  datarate in kbps
 * @return tMKxMCS packet coding
 *
 */
uint8_t conCoding(int sval)
{
	uint8_t rval = MKXMCS_DEFAULT;

	switch (sval) {
	case  3000: rval = MKXMCS_R12BPSK; break;
	case  4500: rval = MKXMCS_R34BPSK; break;
	case  6000: rval = MKXMCS_R12QPSK; break;
	case  9000: rval = MKXMCS_R34QPSK; break;
	case 12000: rval = MKXMCS_R12QAM16; break;
	case 18000: rval = MKXMCS_R34QAM16; break;
	case 24000: rval = MKXMCS_R23QAM64; break;
	case 27000: rval = MKXMCS_R34QAM64; break;
	default:    break;
	}
	return rval;
}

/**
 * @brief readConfig, Read the configuration from file
 * @param filename			Name of the file containing the configuration
 * @param config	Pointer to area to store the configuration
 * @return Zero if successful, otherwise a negative errno
 *
 */
int readConfig( char* filename, tAppConfig* config)
{
	int 	lRetVal 				= 0;
	FILE*	lFile   				= NULL;
	char	lFileLineBuffer[ FILE_LINE_BUFFER_SIZE + 1 ];
	char	lItemNameField[ ITEM_NAME_BUFFER_SIZE + 1 ];
	int		lRadioField    	= 0;
	int		lChannelField  	= 0;
	int		lPowerField    	= 0;
	int		lBitrateField  	= 0;
  float   lDelayField     = 0;
  int   lRoleField       = 0;
  int		lAcclerField    	= 0;
  int		lHlcField  	= 0;
  float   lHeadwayField     = 0;
  float   lEnginelagField       = 0;
  //char  lRoleField      = ' ';
	char	lItemNameLLC        [ ITEM_NAME_BUFFER_SIZE + 1 ] = "LLC";
	int		lItemNameLLCFound         = 0;
	int		lCountRead                = 0;

	// Check if the file can be accessed
	if ( access( filename, F_OK ) != -1 )
	{
		// Open the file for reading
		lFile = fopen( filename, "r");
		if( lFile != NULL)
		{
			memset( lFileLineBuffer, '\0', sizeof(lFileLineBuffer));
			memset( lItemNameField, '\0', sizeof(lItemNameField));

			// Process the lines in the file as long as no error has been detected
			while(( fscanf( lFile, "%[^\n]\n", lFileLineBuffer ) != EOF ) && ( lRetVal == 0))
			{
				d_printf(D_INFO, NULL, "Line read from configuration file: [%s]\n", lFileLineBuffer);

				if ( lFileLineBuffer[ 0 ] == '#' )	// Comment detected
				{
					d_printf(D_INFO, NULL, "   Comment line: [%s]\n", lFileLineBuffer);
				}
				else
				{
					sscanf( lFileLineBuffer, "%s=", lItemNameField );
					d_printf(D_INFO, NULL, "   Item: [%s]\n", lItemNameField);

					// Process the supported set of item names: LLC


					// Process the LLC item
					if( strncmp( lItemNameField, lItemNameLLC, strlen( lItemNameLLC )) == 0 ){
						lCountRead = sscanf( lFileLineBuffer, "%[^=]=%d,%d,%d,%d,%f,%d,%d,%d,%f,%f",
																 lItemNameField,
																 &lRadioField, &lChannelField,
																 &lPowerField, &lBitrateField,
																 &lDelayField, &lRoleField,
																 &lAcclerField, &lHlcField,
																 &lHeadwayField, &lEnginelagField);
						d_printf(D_INFO, NULL, "   LLC: [%s] [%d] [%d] [%d] [%d] [%f] [%d]\n",
									 lItemNameField,
									 lRadioField, lChannelField,
									 lPowerField, lBitrateField,
									 lDelayField, lRoleField);
						if( lCountRead == 11 )
						{
							if(( lRadioField == 0 ) || ( lRadioField == 1 ))
							{
								config->LLC.LLCRadio = (int8_t)lRadioField;
								d_printf(D_INFO, NULL, "      LCC Radio: [%d]\n", config->LLC.LLCRadio);

								if(( lChannelField == 172 ) || ( lChannelField == 174 ) || ( lChannelField == 176 ) || ( lChannelField == 178 ) ||
									 ( lChannelField == 180 ) || ( lChannelField == 182 ) || ( lChannelField == 184 ))
								{
									config->LLC.LLCChannelNo = (int16_t)lChannelField;
									d_printf(D_INFO, NULL, "      LLC Channel number: [%d]\n", config->LLC.LLCChannelNo);

									if(( lPowerField >= 0 ) && ( lPowerField <= 46 ))
									{
										config->LLC.LLCPower = (int8_t)lPowerField;
										d_printf(D_INFO, NULL, "      LLC power value: [%d]\n", config->LLC.LLCPower);

										if(( lBitrateField ==  3000 ) || ( lBitrateField ==  4500 ) || ( lBitrateField ==  6000 ) || ( lBitrateField ==  9000 ) ||
											 ( lBitrateField == 12000 ) || ( lBitrateField == 18000 ) || ( lBitrateField == 24000 ) || ( lBitrateField == 27000 )) {
											config->LLC.LLCBitrate = (int16_t)lBitrateField;
											d_printf(D_INFO, NULL, "      LLC bitrate: [%d]\n", config->LLC.LLCBitrate);

											config->LLC.LLCCoding = (int16_t)conCoding( config->LLC.LLCBitrate );
											d_printf(D_INFO, NULL, "      LLC coding: [%d]\n", config->LLC.LLCCoding);

		                  if(( lDelayField > 0 ) && ( lDelayField <= 10000 ))
		                  {
		                    config->LLC.LLCDelay = lDelayField;
		                    d_printf(D_INFO, NULL, "      LLC delay: [%f]\n", config->LLC.LLCDelay);

                        if(lRoleField!=0)
	                      {
	                        config->LLC.LLCRole = (uint8_t)lRoleField;
	                        d_printf(D_INFO, NULL, "      LLC Role: [%d]\n", config->LLC.LLCRole);

                          if(( lAcclerField == 0 ) || ( lAcclerField == 1 ) || ( lAcclerField == 2 ))
                          {
                            config->LLC.CACCAccler = (int8_t)lAcclerField;
                            d_printf(D_INFO, NULL, "      CACC Accler: [%d]\n", config->LLC.CACCAccler);

                            if(( lHlcField == 10 ) || ( lHlcField == 50 ) || ( lHlcField == 100 ))
                            {
                              config->LLC.CACCHlc = (uint8_t)lHlcField;
                              d_printf(D_INFO, NULL, "      CACC HLC: [%d]\n", config->LLC.CACCHlc);

                              if(( lHeadwayField > 0 ) && ( lHeadwayField <= 5 ))
                              {
                                config->LLC.CACCHeadway = lHeadwayField;
                                d_printf(D_INFO, NULL, "      CACC Headway: [%f]\n", config->LLC.CACCHeadway);

                                if( lEnginelagField > 0 )
                                {
                                  config->LLC.CACCEnginelag = lEnginelagField;
                                  d_printf(D_INFO, NULL, "      CACC Engine Lag: [%f]\n", config->LLC.CACCEnginelag);

                                  lItemNameLLCFound = 1;
                                } else {
        	                        d_printf(D_ERR, NULL, "Invalid CACC Engine Lag in communication test. Valid values: lag > 0\n");
        	                        lRetVal = -20;
        	                      }
                              } else {
      	                        d_printf(D_ERR, NULL, "Invalid CACC Time Headway in communication test. Valid values: 0 < delay <= 3.0\n");
      	                        lRetVal = -19;
      	                      }
                            } else {
                              d_printf(D_ERR, NULL, "Invalid CACC High_level Frequency in communication test. Valid values: 20, 100 (Hz)\n");
                              lRetVal = -18;
                            }
                          } else {
                            d_printf(D_ERR, NULL, "Invalid CACC Acceleration selection in communication test. Valid values: 0 or 1\n");
                            lRetVal = -17;
                          }
	                      } else {
	                        d_printf(D_ERR, NULL, "Invalid LLC role in communication test. Valid values: 'T' and 'R'\n");
	                        lRetVal = -16;
	                      }
		                  } else {
	                      d_printf(D_ERR, NULL, "Invalid LLC delay to send messages. Valid range: 10 <= delay <= 10000\n");
	                      lRetVal = -15;
		                  }
										} else {
											d_printf(D_ERR, NULL, "Invalid LLC bitrate to send messages. Valid values: 3000, 45000, 6000, 9000, 12000, 18000, 24000 and 27000\n");
											lRetVal = -14;
										}
									} else {
										d_printf(D_ERR, NULL, "Invalid LLC power. Valid range: 0 <= power <= 46\n");
										lRetVal = -13;
									}
								} else {
									d_printf(D_ERR, NULL, "Invalid LLC channel number. Valid values: 172, 174, 176, 178, 180, 182, 184\n");
									lRetVal = -12;
								}
							} else {
								d_printf(D_ERR, NULL, "Invalid LLC radio. Valid values: 0 or 1\n");
								lRetVal = -11;
							}
						} else {
							d_printf(D_ERR, NULL, "Not all LLC settings are read\n");
							lRetVal = -10;
						}
					}
		  	}
			} // end while

		  memset( lFileLineBuffer, '\0', sizeof(lFileLineBuffer));
		  memset( lItemNameField, '\0', sizeof(lItemNameField));

		} else {
			d_printf(D_ERR, NULL, "Error opening configuration file.\n");
			lRetVal = -2;
		}
	} else {
		d_printf(D_ERR, NULL, "Specified configuration file not found.\n");
		lRetVal = -1;
	}

	// Check if all items are processed
	if (( lRetVal == 0 ) &&
		  ( lItemNameLLCFound != 1 )) {
		lRetVal = -100;
	}

	return lRetVal;
}
