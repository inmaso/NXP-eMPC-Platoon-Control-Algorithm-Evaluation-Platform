var structMyApp =
[
    [ "Config", "structMyApp.html#a3d5732c1b577b4c5ca125288db24e492", null ],
    [ "Exit", "structMyApp.html#a8f538a1ebc4046150e45f24f1f27104b", null ],
    [ "Fd", "structMyApp.html#abda43b140ca4d5a9fadc390a22b20521", null ],
    [ "MsgBuff", "structMyApp.html#abf5bbe1a01114e84d9210efd1fc6023d", null ],
    [ "pMKx", "structMyApp.html#a215b304ccc43635eafbb376e9ac35eba", null ]
];