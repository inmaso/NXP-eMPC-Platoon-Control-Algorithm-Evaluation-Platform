var searchData=
[
  ['platooningbeacon',['PlatooningBeacon',['../structPlatooningBeacon.html',1,'']]]
];
