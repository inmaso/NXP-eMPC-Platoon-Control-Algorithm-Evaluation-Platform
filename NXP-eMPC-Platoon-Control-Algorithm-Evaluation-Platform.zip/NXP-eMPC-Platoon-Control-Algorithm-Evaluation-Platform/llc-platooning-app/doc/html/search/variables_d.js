var searchData=
[
  ['sequencenumber',['sequenceNumber',['../structPlatooningBeacon.html#a2d38c5cab4c11a0212dbc06554a6e1e0',1,'PlatooningBeacon']]],
  ['subtype',['SubType',['../structMKxDebugMsgData.html#a9f3a2c9034670aec5bace09dfdaf6ff5',1,'MKxDebugMsgData::SubType()'],['../V2X-lib_8h.html#a9f3a2c9034670aec5bace09dfdaf6ff5',1,'SubType():&#160;V2X-lib.h']]]
];
