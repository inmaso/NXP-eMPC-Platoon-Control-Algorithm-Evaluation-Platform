var searchData=
[
  ['v2x_2dlib_2ec',['V2X-lib.c',['../V2X-lib_8c.html',1,'']]],
  ['v2x_2dlib_2eh',['V2X-lib.h',['../V2X-lib_8h.html',1,'']]],
  ['vehicle_5flength',['VEHICLE_LENGTH',['../controller_8h.html#ae131b5867f2c800783712be4f74b488d',1,'controller.h']]],
  ['vehicleid',['vehicleId',['../structPlatooningBeacon.html#a1605e9af268c554e573594509a840259',1,'PlatooningBeacon']]],
  ['velocity',['velocity',['../structcar__state.html#accacf4e9263030d70ed79f8516c0eac5',1,'car_state']]],
  ['verbose',['verbose',['../readConfig_8h.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;V2X-lib.c'],['../V2X-lib_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;V2X-lib.c']]],
  ['virtualradar',['virtualRADAR',['../controller_8c.html#a08e0aa57f90022a2c91289316f5b6e77',1,'virtualRADAR(struct accRadar *AccRadar, char *data, int count):&#160;controller.c'],['../controller_8h.html#a08e0aa57f90022a2c91289316f5b6e77',1,'virtualRADAR(struct accRadar *AccRadar, char *data, int count):&#160;controller.c']]]
];
