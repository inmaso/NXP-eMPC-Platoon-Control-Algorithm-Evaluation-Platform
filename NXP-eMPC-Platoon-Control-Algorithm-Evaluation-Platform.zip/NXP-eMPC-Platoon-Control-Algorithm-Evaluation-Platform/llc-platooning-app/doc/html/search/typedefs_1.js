var searchData=
[
  ['platooningbeacon',['platooningBeacon',['../V2X-lib_8h.html#a56fe527cd724d5bb4a9efa2cb78410b1',1,'V2X-lib.h']]]
];
