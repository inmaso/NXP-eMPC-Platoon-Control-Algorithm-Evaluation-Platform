var searchData=
[
  ['firstorderlagmodel',['FirstOrderLagModel',['../controller_8c.html#a4a7940f196d5946c1a8a058646b0e8ba',1,'FirstOrderLagModel(struct car_state currentState, double a_desired, double dt_s, double tau_s):&#160;controller.c'],['../controller_8h.html#aceb05bf49dfba949d307e2311b3e4633',1,'FirstOrderLagModel(struct car_state currentState, double a_desired, double dt_s, double tau):&#160;controller.c']]]
];
