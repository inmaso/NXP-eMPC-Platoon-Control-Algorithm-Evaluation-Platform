var searchData=
[
  ['box_5fmuller_5fp',['box_muller_p',['../controller_8c.html#a66295f0494ab250e49c539483faac9e5',1,'box_muller_p(double m, double s):&#160;controller.c'],['../controller_8h.html#a66295f0494ab250e49c539483faac9e5',1,'box_muller_p(double m, double s):&#160;controller.c']]]
];
