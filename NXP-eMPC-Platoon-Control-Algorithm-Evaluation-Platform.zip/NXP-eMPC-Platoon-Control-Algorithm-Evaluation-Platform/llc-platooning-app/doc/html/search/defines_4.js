var searchData=
[
  ['ip_5faddr_5fsize',['IP_ADDR_SIZE',['../V2X-lib_8h.html#ac5af0538013580a8fc4107d7cf78a6fd',1,'V2X-lib.h']]],
  ['item_5fname_5fbuffer_5fsize',['ITEM_NAME_BUFFER_SIZE',['../V2X-lib_8h.html#afb14943e3ceb9d8bbcdee3aaa42a49af',1,'V2X-lib.h']]]
];
