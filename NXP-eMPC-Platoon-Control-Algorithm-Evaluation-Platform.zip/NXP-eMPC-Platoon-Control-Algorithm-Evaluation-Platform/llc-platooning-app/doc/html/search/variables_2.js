var searchData=
[
  ['bheader',['BHeader',['../V2X-lib_8c.html#a3523a851c2cc38f7a7ae89625709f91e',1,'V2X-lib.c']]],
  ['blank',['blank',['../structPlatooningBeacon.html#aff56b11d401effcf29f172539e377043',1,'PlatooningBeacon']]]
];
