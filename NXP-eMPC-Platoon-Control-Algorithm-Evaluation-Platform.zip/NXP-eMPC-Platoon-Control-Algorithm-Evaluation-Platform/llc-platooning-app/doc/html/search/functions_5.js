var searchData=
[
  ['ex_5fchconfig_5fenablecast',['ex_ChConfig_Enablecast',['../ex-chconfig_8c.html#a278e948291c779fa2a0bf9ad139df524',1,'ex_ChConfig_Enablecast(struct MKx *pMKx, tMKxRadio Radio, uint8_t AMSIndex, uint64_t UnicastMAC, uint64_t mask, uint8_t match):&#160;ex-chconfig.c'],['../V2X-lib_8h.html#a278e948291c779fa2a0bf9ad139df524',1,'ex_ChConfig_Enablecast(struct MKx *pMKx, tMKxRadio Radio, uint8_t AMSIndex, uint64_t UnicastMAC, uint64_t mask, uint8_t match):&#160;ex-chconfig.c']]],
  ['ex_5fchconfig_5fsinglechannelradio',['ex_ChConfig_SingleChannelRadio',['../ex-chconfig_8c.html#a7235f3e4be12da938e73c3f71cd19da5',1,'ex_ChConfig_SingleChannelRadio(struct MKx *pMKx, tMKxRadio Radio, uint16_t ChannelNo, uint8_t power):&#160;ex-chconfig.c'],['../V2X-lib_8h.html#a7235f3e4be12da938e73c3f71cd19da5',1,'ex_ChConfig_SingleChannelRadio(struct MKx *pMKx, tMKxRadio Radio, uint16_t ChannelNo, uint8_t power):&#160;ex-chconfig.c']]],
  ['ex_5fsetmode',['ex_SetMode',['../ex-chconfig_8c.html#abb5cc40ac814f3460690631641944904',1,'ex_SetMode(struct MKx *pMKx, tMKxRadio Radio, tMKxRadioMode Mode):&#160;ex-chconfig.c'],['../V2X-lib_8h.html#abb5cc40ac814f3460690631641944904',1,'ex_SetMode(struct MKx *pMKx, tMKxRadio Radio, tMKxRadioMode Mode):&#160;ex-chconfig.c']]],
  ['exitplatooning',['ExitPlatooning',['../V2X-lib_8c.html#a8ccf439c23542116338da158d16f3b3a',1,'V2X-lib.c']]]
];
