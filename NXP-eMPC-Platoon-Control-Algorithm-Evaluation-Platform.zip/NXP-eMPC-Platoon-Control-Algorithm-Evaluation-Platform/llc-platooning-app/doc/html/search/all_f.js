var searchData=
[
  ['radar',['RADAR',['../controller_8h.html#a22fd294487f8ca11526907f83b82afe0',1,'controller.h']]],
  ['radar_5finterval',['RADAR_INTERVAL',['../controller_8h.html#a3718d759de83145421864a7bcce2d522',1,'controller.h']]],
  ['radarmeasurements',['radarMeasurements',['../controller_8c.html#a80409f6db1cae1c5618aa26f0bd3eb5d',1,'controller.c']]],
  ['readconfig',['readConfig',['../readConfig_8c.html#a32937ffe6bdf6b2aa811c5655143abd7',1,'readConfig(char *filename, tAppConfig *config):&#160;readConfig.c'],['../readConfig_8h.html#a32937ffe6bdf6b2aa811c5655143abd7',1,'readConfig(char *filename, tAppConfig *config):&#160;readConfig.c']]],
  ['readconfig_2ec',['readConfig.c',['../readConfig_8c.html',1,'']]],
  ['readconfig_2eh',['readConfig.h',['../readConfig_8h.html',1,'']]],
  ['readsimulationprofile',['readSimulationProfile',['../controller_8c.html#a717508625d170699a6fdabaae8865299',1,'readSimulationProfile(char *filename):&#160;controller.c'],['../controller_8h.html#a717508625d170699a6fdabaae8865299',1,'readSimulationProfile(char *filename):&#160;controller.c']]],
  ['receivingthreadradar',['receivingThreadRadar',['../controller_8c.html#ac907c063ea0950dc49c6086b82a3f884',1,'receivingThreadRadar():&#160;controller.c'],['../controller_8h.html#ac907c063ea0950dc49c6086b82a3f884',1,'receivingThreadRadar():&#160;controller.c']]],
  ['recpackagecnt',['recPackageCnt',['../V2X-lib_8c.html#aca3f9c180d98b50bf71bbae2c6457128',1,'V2X-lib.c']]],
  ['relative_5fvelocity',['relative_velocity',['../structaccRadar.html#a4ac42727e736404d5faf1d408bef03aa',1,'accRadar']]]
];
