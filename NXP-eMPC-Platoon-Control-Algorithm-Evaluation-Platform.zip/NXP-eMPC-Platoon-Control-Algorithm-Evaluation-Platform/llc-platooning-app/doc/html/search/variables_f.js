var searchData=
[
  ['vehicleid',['vehicleId',['../structPlatooningBeacon.html#a1605e9af268c554e573594509a840259',1,'PlatooningBeacon']]],
  ['velocity',['velocity',['../structcar__state.html#accacf4e9263030d70ed79f8516c0eac5',1,'car_state']]],
  ['verbose',['verbose',['../readConfig_8h.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;V2X-lib.c'],['../V2X-lib_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;V2X-lib.c']]]
];
