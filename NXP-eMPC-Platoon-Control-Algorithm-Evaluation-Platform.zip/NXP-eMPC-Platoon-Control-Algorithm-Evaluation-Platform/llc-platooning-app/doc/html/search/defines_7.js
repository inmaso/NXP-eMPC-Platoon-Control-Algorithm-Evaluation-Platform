var searchData=
[
  ['micro_5fsec_5fto_5fsec',['MICRO_SEC_TO_SEC',['../V2X-lib_8h.html#a5e559c8c48f09aff166f63bf4a41e4e3',1,'V2X-lib.h']]],
  ['milli_5fsec_5fto_5fsec',['MILLI_SEC_TO_SEC',['../V2X-lib_8h.html#af763ac761b9d910d99bde6a68918f470',1,'V2X-lib.h']]],
  ['mkxdebug_5fdmesg_5farm',['MKXDEBUG_DMESG_ARM',['../V2X-lib_8h.html#a873ce5aa31fcd4cd08aa508fbb39ed28',1,'V2X-lib.h']]],
  ['msg_5ftype_5fsize',['MSG_TYPE_SIZE',['../V2X-lib_8h.html#a45b88652a1e61a951ef699f2259cd7a2',1,'V2X-lib.h']]]
];
