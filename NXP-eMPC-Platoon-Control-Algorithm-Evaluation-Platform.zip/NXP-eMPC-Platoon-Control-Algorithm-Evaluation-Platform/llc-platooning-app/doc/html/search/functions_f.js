var searchData=
[
  ['virtualradar',['virtualRADAR',['../controller_8c.html#a08e0aa57f90022a2c91289316f5b6e77',1,'virtualRADAR(struct accRadar *AccRadar, char *data, int count):&#160;controller.c'],['../controller_8h.html#a08e0aa57f90022a2c91289316f5b6e77',1,'virtualRADAR(struct accRadar *AccRadar, char *data, int count):&#160;controller.c']]]
];
