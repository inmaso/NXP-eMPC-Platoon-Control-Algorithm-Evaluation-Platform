var searchData=
[
  ['parsecommand',['parseCommand',['../main_8c.html#adfcd8fd0d93efa58ff18249bf9cf9336',1,'main.c']]],
  ['pdev',['pDev',['../main_8c.html#a477d23d1a55c88b4ef3e8b243fee937c',1,'pDev():&#160;main.c'],['../V2X-lib_8c.html#a477d23d1a55c88b4ef3e8b243fee937c',1,'pDev():&#160;main.c']]],
  ['periodic_5finfo',['PERIODIC_INFO',['../V2X-lib_8h.html#ad31449324ec6bdec0f38181b40fd5aa1',1,'V2X-lib.h']]],
  ['platooncommand',['platoonCommand',['../structPlatooningBeacon.html#a137700dc2840c5790a83f1f0c87ed93d',1,'PlatooningBeacon']]],
  ['platooningbeacon',['PlatooningBeacon',['../structPlatooningBeacon.html',1,'PlatooningBeacon'],['../V2X-lib_8h.html#a56fe527cd724d5bb4a9efa2cb78410b1',1,'platooningBeacon():&#160;V2X-lib.h']]],
  ['ploeg',['Ploeg',['../controller_8c.html#a08dd84cad27f30b649580735d0d2c1fb',1,'Ploeg(struct car_state currentState, struct accRadar radar, double m_controllerAcceleration, double headway, double Ts):&#160;controller.c'],['../controller_8h.html#a08dd84cad27f30b649580735d0d2c1fb',1,'Ploeg(struct car_state currentState, struct accRadar radar, double m_controllerAcceleration, double headway, double Ts):&#160;controller.c']]],
  ['pmkx',['pMKx',['../structMyApp.html#a215b304ccc43635eafbb376e9ac35eba',1,'MyApp']]],
  ['poll_5ferror',['POLL_ERROR',['../V2X-lib_8c.html#aac1f46a870807a49b73c8021ff84ce5b',1,'POLL_ERROR():&#160;V2X-lib.c'],['../V2X-lib_8h.html#aac1f46a870807a49b73c8021ff84ce5b',1,'POLL_ERROR():&#160;V2X-lib.c']]],
  ['poll_5finput',['POLL_INPUT',['../V2X-lib_8c.html#af5cd760ae657032f6e5706f5e6e47c13',1,'POLL_INPUT():&#160;V2X-lib.c'],['../V2X-lib_8h.html#af5cd760ae657032f6e5706f5e6e47c13',1,'POLL_INPUT():&#160;V2X-lib.c']]],
  ['position',['position',['../structcar__state.html#aa1b2c258efdc9e057ee99a45179692fd',1,'car_state']]],
  ['posix_5fif_5fcnt',['POSIX_IF_CNT',['../V2X-lib_8h.html#a5d24d12e24dc546c09319d6db56f34fb',1,'V2X-lib.h']]],
  ['posix_5fif_5fmkx',['POSIX_IF_MKX',['../V2X-lib_8h.html#ae713558f87b6e1a67ea856970a324748',1,'V2X-lib.h']]],
  ['printconfig',['PrintConfig',['../main_8c.html#a307d2745a57b7597a6e6196752ff9332',1,'main.c']]],
  ['printusage',['PrintUsage',['../main_8c.html#aca57470358e9f50964ccce76dd0a8ecf',1,'main.c']]],
  ['processv2x',['ProcessV2X',['../V2X-lib_8c.html#af9f656987dea5e8345702a7460aad745',1,'V2X-lib.c']]],
  ['profiledata',['profileData',['../controller_8h.html#aa6e95232fe09eb59c985b0888fb03521',1,'profileData():&#160;main.c'],['../main_8c.html#aa6e95232fe09eb59c985b0888fb03521',1,'profileData():&#160;main.c']]]
];
