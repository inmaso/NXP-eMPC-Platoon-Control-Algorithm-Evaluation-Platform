var searchData=
[
  ['stand_5fstill_5fdistance',['STAND_STILL_DISTANCE',['../controller_8h.html#aa64ad2ee582eab9ac32a05a270447fb2',1,'controller.h']]],
  ['station_5frole_5fsize',['STATION_ROLE_SIZE',['../V2X-lib_8h.html#a83d72e95e79e83f7b740ccaa9cf11b10',1,'V2X-lib.h']]]
];
