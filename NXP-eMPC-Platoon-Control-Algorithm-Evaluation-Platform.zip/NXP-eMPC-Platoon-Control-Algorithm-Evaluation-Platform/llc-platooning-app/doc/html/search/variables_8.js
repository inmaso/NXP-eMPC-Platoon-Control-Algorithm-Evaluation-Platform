var searchData=
[
  ['identifier',['identifier',['../structPlatooningBeacon.html#a1fee39121af7ce2155d6474fd8f1e936',1,'PlatooningBeacon']]]
];
