var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../V2X-lib_8h.html#a265d5cdfad6c34a870f4d0ea5f30e4d8',1,'V2X-lib.h']]],
  ['_5fdev',['_Dev',['../main_8c.html#a6c5cb921bd205f3e6ea45d2c166c5425',1,'main.c']]],
  ['_5frxbuf',['_RxBuf',['../V2X-lib_8c.html#af68839ab3e8b126e6ed158603b0d407c',1,'V2X-lib.c']]],
  ['_5ftxbuf',['_TxBuf',['../V2X-lib_8c.html#a2603cbc0c0acf6cbab93164ecf7c90d6',1,'V2X-lib.c']]]
];
