var searchData=
[
  ['ex_2dchconfig_2ec',['ex-chconfig.c',['../ex-chconfig_8c.html',1,'']]]
];
