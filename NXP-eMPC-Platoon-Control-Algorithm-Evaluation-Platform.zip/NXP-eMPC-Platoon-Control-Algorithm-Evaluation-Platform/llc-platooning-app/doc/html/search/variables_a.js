var searchData=
[
  ['msgbuff',['MsgBuff',['../structMyApp.html#abf5bbe1a01114e84d9210efd1fc6023d',1,'MyApp']]]
];
