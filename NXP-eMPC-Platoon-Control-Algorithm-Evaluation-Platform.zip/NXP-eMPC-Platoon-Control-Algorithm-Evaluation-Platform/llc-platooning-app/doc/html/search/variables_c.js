var searchData=
[
  ['radarmeasurements',['radarMeasurements',['../controller_8c.html#a80409f6db1cae1c5618aa26f0bd3eb5d',1,'controller.c']]],
  ['recpackagecnt',['recPackageCnt',['../V2X-lib_8c.html#aca3f9c180d98b50bf71bbae2c6457128',1,'V2X-lib.c']]],
  ['relative_5fvelocity',['relative_velocity',['../structaccRadar.html#a4ac42727e736404d5faf1d408bef03aa',1,'accRadar']]]
];
