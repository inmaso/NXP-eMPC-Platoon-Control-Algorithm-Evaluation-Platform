var searchData=
[
  ['file_5fline_5fbuffer_5fsize',['FILE_LINE_BUFFER_SIZE',['../V2X-lib_8h.html#a7b157b223e481a76fb4c3b1d1c9f9ca2',1,'V2X-lib.h']]],
  ['filename_5fbuffer_5fsize',['FILENAME_BUFFER_SIZE',['../V2X-lib_8h.html#a8582aa6637e4bfd8770ca7385a2babb5',1,'V2X-lib.h']]]
];
