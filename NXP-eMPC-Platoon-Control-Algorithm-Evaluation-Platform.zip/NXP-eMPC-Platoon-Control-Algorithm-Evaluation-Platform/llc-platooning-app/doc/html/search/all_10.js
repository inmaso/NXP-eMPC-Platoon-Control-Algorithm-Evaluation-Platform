var searchData=
[
  ['send_5fmsg',['send_msg',['../V2X-lib_8c.html#a6bc829da8293cd76ce2607333e94b512',1,'V2X-lib.c']]],
  ['sendingthreadradar',['sendingThreadRadar',['../controller_8c.html#aba5c3ea9a941a2cf7bd2b01c6d6e61f3',1,'sendingThreadRadar():&#160;controller.c'],['../controller_8h.html#aba5c3ea9a941a2cf7bd2b01c6d6e61f3',1,'sendingThreadRadar():&#160;controller.c']]],
  ['sequencenumber',['sequenceNumber',['../structPlatooningBeacon.html#a2d38c5cab4c11a0212dbc06554a6e1e0',1,'PlatooningBeacon']]],
  ['stand_5fstill_5fdistance',['STAND_STILL_DISTANCE',['../controller_8h.html#aa64ad2ee582eab9ac32a05a270447fb2',1,'controller.h']]],
  ['station_5frole_5fsize',['STATION_ROLE_SIZE',['../V2X-lib_8h.html#a83d72e95e79e83f7b740ccaa9cf11b10',1,'V2X-lib.h']]],
  ['subtype',['SubType',['../structMKxDebugMsgData.html#a9f3a2c9034670aec5bace09dfdaf6ff5',1,'MKxDebugMsgData::SubType()'],['../V2X-lib_8h.html#a9f3a2c9034670aec5bace09dfdaf6ff5',1,'SubType():&#160;V2X-lib.h']]]
];
