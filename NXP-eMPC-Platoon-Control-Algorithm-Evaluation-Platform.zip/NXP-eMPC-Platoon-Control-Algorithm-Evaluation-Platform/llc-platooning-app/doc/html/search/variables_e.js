var searchData=
[
  ['timestamp',['timeStamp',['../structPlatooningBeacon.html#a8e0dc7a685b16ec58c59d760a1971b4e',1,'PlatooningBeacon']]],
  ['type',['Type',['../structMKxDebugMsgData.html#a31e5049876e94f99d42c027ba525f303',1,'MKxDebugMsgData::Type()'],['../V2X-lib_8h.html#a31e5049876e94f99d42c027ba525f303',1,'Type():&#160;V2X-lib.h']]]
];
