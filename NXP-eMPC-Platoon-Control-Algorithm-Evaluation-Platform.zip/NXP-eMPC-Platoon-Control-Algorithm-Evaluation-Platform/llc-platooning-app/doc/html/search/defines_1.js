var searchData=
[
  ['config_5fbuf_5fcount',['CONFIG_BUF_COUNT',['../V2X-lib_8h.html#a3e8a5f8e07895887468bd93c4f89cd1a',1,'V2X-lib.h']]],
  ['convert_5frssi_5fto_5fdb',['CONVERT_RSSI_TO_dB',['../V2X-lib_8h.html#a1b6d4a53ef2f934e0b9ae0d01b53e054',1,'V2X-lib.h']]]
];
