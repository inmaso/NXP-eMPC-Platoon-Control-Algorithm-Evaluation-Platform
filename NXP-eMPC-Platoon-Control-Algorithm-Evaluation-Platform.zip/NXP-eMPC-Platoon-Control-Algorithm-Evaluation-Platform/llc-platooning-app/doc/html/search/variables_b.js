var searchData=
[
  ['pdev',['pDev',['../main_8c.html#a477d23d1a55c88b4ef3e8b243fee937c',1,'pDev():&#160;main.c'],['../V2X-lib_8c.html#a477d23d1a55c88b4ef3e8b243fee937c',1,'pDev():&#160;main.c']]],
  ['platooncommand',['platoonCommand',['../structPlatooningBeacon.html#a137700dc2840c5790a83f1f0c87ed93d',1,'PlatooningBeacon']]],
  ['pmkx',['pMKx',['../structMyApp.html#a215b304ccc43635eafbb376e9ac35eba',1,'MyApp']]],
  ['poll_5ferror',['POLL_ERROR',['../V2X-lib_8c.html#aac1f46a870807a49b73c8021ff84ce5b',1,'POLL_ERROR():&#160;V2X-lib.c'],['../V2X-lib_8h.html#aac1f46a870807a49b73c8021ff84ce5b',1,'POLL_ERROR():&#160;V2X-lib.c']]],
  ['poll_5finput',['POLL_INPUT',['../V2X-lib_8c.html#af5cd760ae657032f6e5706f5e6e47c13',1,'POLL_INPUT():&#160;V2X-lib.c'],['../V2X-lib_8h.html#af5cd760ae657032f6e5706f5e6e47c13',1,'POLL_INPUT():&#160;V2X-lib.c']]],
  ['position',['position',['../structcar__state.html#aa1b2c258efdc9e057ee99a45179692fd',1,'car_state']]],
  ['profiledata',['profileData',['../controller_8h.html#aa6e95232fe09eb59c985b0888fb03521',1,'profileData():&#160;main.c'],['../main_8c.html#aa6e95232fe09eb59c985b0888fb03521',1,'profileData():&#160;main.c']]]
];
