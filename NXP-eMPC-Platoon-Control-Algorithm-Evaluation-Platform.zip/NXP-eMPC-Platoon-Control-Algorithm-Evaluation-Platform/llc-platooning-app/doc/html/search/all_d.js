var searchData=
[
  ['nano_5fsec_5fto_5fsec',['NANO_SEC_TO_SEC',['../V2X-lib_8h.html#a0e40136e1c9215413e1e0169b8948710',1,'V2X-lib.h']]]
];
