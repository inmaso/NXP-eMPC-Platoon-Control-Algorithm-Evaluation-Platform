var searchData=
[
  ['initplatooning',['InitPlatooning',['../V2X-lib_8c.html#aff9bdbffd1a76e78ad10ad412b268752',1,'InitPlatooning():&#160;V2X-lib.c'],['../V2X-lib_8h.html#aff9bdbffd1a76e78ad10ad412b268752',1,'InitPlatooning():&#160;V2X-lib.c']]]
];
