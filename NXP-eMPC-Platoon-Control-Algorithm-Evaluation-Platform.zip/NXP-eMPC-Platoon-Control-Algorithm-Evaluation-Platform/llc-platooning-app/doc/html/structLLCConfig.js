var structLLCConfig =
[
    [ "LLCBitrate", "structLLCConfig.html#a926d4cf83f0fe0019a90e78f4c9ac2dc", null ],
    [ "LLCChannelNo", "structLLCConfig.html#ac0a9528e913abb421406d223d12e88c9", null ],
    [ "LLCCoding", "structLLCConfig.html#abd3728f00ba11c34beef6cb753e886e6", null ],
    [ "LLCDelay", "structLLCConfig.html#a0fd108b416949babbdb11dd03f31a7e8", null ],
    [ "LLCPower", "structLLCConfig.html#a32f813c9980b59a82cfc71095696d32b", null ],
    [ "LLCRadio", "structLLCConfig.html#a48aa3341fcf224947d96af143a144151", null ],
    [ "LLCRole", "structLLCConfig.html#a61978712fe93f6625b77582ce390016e", null ]
];