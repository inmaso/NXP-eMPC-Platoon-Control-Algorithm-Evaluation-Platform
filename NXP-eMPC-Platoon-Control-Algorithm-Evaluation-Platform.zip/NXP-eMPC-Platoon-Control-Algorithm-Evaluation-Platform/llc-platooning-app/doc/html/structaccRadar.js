var structaccRadar =
[
    [ "distance", "structaccRadar.html#a79b8e036dca6911e3295a47d99f21f43", null ],
    [ "distance_last", "structaccRadar.html#a5ab49b9ad86b114b501fd7507623a5f5", null ],
    [ "relative_velocity", "structaccRadar.html#a4ac42727e736404d5faf1d408bef03aa", null ]
];