var structPlatooningBeacon =
[
    [ "blank", "structPlatooningBeacon.html#aff56b11d401effcf29f172539e377043", null ],
    [ "CA", "structPlatooningBeacon.html#aa8aeb026b14df234a3049985a677b97e", null ],
    [ "identifier", "structPlatooningBeacon.html#a1fee39121af7ce2155d6474fd8f1e936", null ],
    [ "platoonCommand", "structPlatooningBeacon.html#a137700dc2840c5790a83f1f0c87ed93d", null ],
    [ "sequenceNumber", "structPlatooningBeacon.html#a2d38c5cab4c11a0212dbc06554a6e1e0", null ],
    [ "timeStamp", "structPlatooningBeacon.html#a8e0dc7a685b16ec58c59d760a1971b4e", null ],
    [ "vehicleId", "structPlatooningBeacon.html#a1605e9af268c554e573594509a840259", null ]
];