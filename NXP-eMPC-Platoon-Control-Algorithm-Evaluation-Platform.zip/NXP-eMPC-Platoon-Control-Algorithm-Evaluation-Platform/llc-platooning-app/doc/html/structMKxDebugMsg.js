var structMKxDebugMsg =
[
    [ "DebugMsgData", "structMKxDebugMsg.html#a2106087176b20ae50236b1f2eaf5405f", null ],
    [ "Hdr", "structMKxDebugMsg.html#af7d77b156e2048c420330c8fb1d31000", null ]
];