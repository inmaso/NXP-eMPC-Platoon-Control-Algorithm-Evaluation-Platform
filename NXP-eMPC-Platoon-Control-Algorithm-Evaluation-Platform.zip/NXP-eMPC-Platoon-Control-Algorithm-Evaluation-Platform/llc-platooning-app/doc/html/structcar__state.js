var structcar__state =
[
    [ "acceleration", "structcar__state.html#a24df1cc087cfeb6f8b7cb95deada4f19", null ],
    [ "desiredAcceleration", "structcar__state.html#a7667f6eae67f095f88321c6cc4465a92", null ],
    [ "position", "structcar__state.html#aa1b2c258efdc9e057ee99a45179692fd", null ],
    [ "velocity", "structcar__state.html#accacf4e9263030d70ed79f8516c0eac5", null ]
];