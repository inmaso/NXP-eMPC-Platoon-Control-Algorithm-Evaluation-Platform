var structMKxDebugMsgData =
[
    [ "Data", "structMKxDebugMsgData.html#a7cc5bf2d6acfe691173d65234114e2cd", null ],
    [ "SubType", "structMKxDebugMsgData.html#a9f3a2c9034670aec5bace09dfdaf6ff5", null ],
    [ "Type", "structMKxDebugMsgData.html#a31e5049876e94f99d42c027ba525f303", null ]
];