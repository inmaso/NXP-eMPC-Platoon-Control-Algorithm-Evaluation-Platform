var annotated =
[
    [ "accRadar", "structaccRadar.html", "structaccRadar" ],
    [ "AppConfig", "structAppConfig.html", null ],
    [ "car_state", "structcar__state.html", "structcar__state" ],
    [ "LLCConfig", "structLLCConfig.html", "structLLCConfig" ],
    [ "MKxDebugMsg", "structMKxDebugMsg.html", "structMKxDebugMsg" ],
    [ "MKxDebugMsgData", "structMKxDebugMsgData.html", "structMKxDebugMsgData" ],
    [ "MyApp", "structMyApp.html", "structMyApp" ],
    [ "PlatooningBeacon", "structPlatooningBeacon.html", "structPlatooningBeacon" ]
];