/**
 * @section nxp_llc_examples LLC API_H
 *
 * @copyright NXP Semiconductors NV
 * @file
 * llc-api.h: Provides the interface to MKX transceiver hardware;
 * handles sending request from upper layers;
 * decodes and preprocesses the received packets.
 */
/*
 * udp-11p.h
 *
 *  Created on: May 19, 2016
 *      Author: Joost van Doorn
 *  Modified on: May 8, 2018
 *      Author: Sijie Zhu
 */

#ifndef UDP_11P_H_
#define UDP_11P_H_

//------------------------------------------------------------------------------
// Macros & Constants
//------------------------------------------------------------------------------
/// Max number of bytes in the debug message data part intern
#define CONFIG_BUF_COUNT (16 * sizeof(uint32_t))
/// Number of files in poll array
#define POSIX_IF_CNT 1
/// MKx file index for poll
#define POSIX_IF_MKX 0

#define POLL_TIMEOUT_MSEC 1

/// Size of the IP address buffer
#define IP_ADDR_SIZE 20

/// Station role size
#define STATION_ROLE_SIZE 11

/// Size of message type id
#define MSG_TYPE_SIZE 10

/// Size of the filename buffer
#define FILENAME_BUFFER_SIZE 80

/// Size of the file line buffer
#define FILE_LINE_BUFFER_SIZE 512

/// Size of the item name buffer
#define ITEM_NAME_BUFFER_SIZE 80

/// FROM: llc-dbg.h
#define MKXDEBUG_DMESG_ARM 1

#define MESSAGE_BUFSIZE 2000

/// Time constant ns to s
#define NANO_SEC_TO_SEC ((double)(1.0 / 1000000000.0))
/// Time constant us to s
#define MICRO_SEC_TO_SEC ((double)(1.0 / 1000000.0))
/// Time constant ms to s
#define MILLI_SEC_TO_SEC ((double)(1.0 / 1000.0))
/// Constant RSSI to dB
#define CONVERT_RSSI_TO_dB (0.5)
/// Start of TimestampIts
#define Jan_01_2004 (long long)(1072915200000)
/// LLC Extra header length
#define LLC_ALLOC_EXTRA_HEADER 0
/// Blank packet field
#define BLANKFIELD {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,\
                                        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,\
                                      0.0, 0.0, 0.0}
/// zzz
#define PERIODIC_INFO 0
/// Channel Load
float LLC_CL;
int LLC_CBR;
long lLoopCountC;
uint32_t packetnumber_last;
uint32_t packetnumber;
uint32_t packetlosscounter;
/// Desired acceleration of the predecessor (V2X buffer)
double a_des_v2x_buffer;
/// Platooning Beacon Packet Format
typedef struct PlatooningBeacon {
  /// A string as the Platooning Beacon identifier (no encryption here)
  uint8_t identifier[8];
  /// Platoon Member ID: 1 - 255
  uint8_t vehicleId;
  /// Status Flag: E for Enabled; D for Disabled
  uint8_t platoonCommand;
  /// TimestampIts%65 536; TimestampIts a value in milliseconds since 2004-01-01T00:00:00:000Z
  uint16_t timeStamp;
  /// Sequence number of the packet since the platooning application has begun
  uint32_t sequenceNumber;
  /// Desired acceleration of this vehicle
  double CA;
  /// Blank field for future extensions
  double blank[35];
} platooningBeacon;

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

/// MKx debug message type
typedef uint16_t tMKxDebugMsgType;

/// MKx Debug message data structure
typedef struct MKxDebugMsgData {
  /// Message type
  tMKxDebugMsgType Type;
  /// Message sub-type
  uint16_t SubType;
  /// Data
  uint8_t Data[];
} __attribute__((packed)) tMKxDebugMsgData;

/// MKx debug message structure
typedef struct MKxDebugMsg {
  /// Interface Message Header
  tMKxIFMsg Hdr;
  /// Radio Stats Data
  tMKxDebugMsgData DebugMsgData;
} __attribute__((packed)) tMKxDebugMsg;

/// Generic LLC configuration items
typedef struct LLCConfig {
  /// Radio used to send the message through LLC.
  /** Valid values: either 0 (RadioA) or 1 (RadioB)
        NOTE: When using radio 1, make sure radio 0 is also
                      initialized. Otherwise radio 1 will not communicate.   */
  int8_t LLCRadio;
  /// Channel number used to send the message through LLC.
  /** Valid values: 172, 174, 176, 178, 180, 182, 184 */
  int16_t LLCChannelNo;
  /// Power level (* 0.5 dBm) used to send the message through LLC
  /**              Valid range: 0 <= power <= 46 (* 0.5 dBm)      */
  int8_t LLCPower;
  /// Bitrate used to send the message through LLC
  /**          Valid values: 3000, 4500, 6000, 9000, 12000, 18000, 24000, 27000 */
  int16_t LLCBitrate;
  /// Coding value is derived from the bitrate value read from file
  int16_t LLCCoding;
  /// The delay used between sending two messages, in milliseconds.
  /**              Valid range: 0 < delay <= 10000 (ms)                           */
  float LLCDelay;
  /// Platoon Member ID
  /**              Valid range: 1 <= Role <= 254;
                         */
  uint8_t LLCRole;
  int8_t CACCAccler;
  uint8_t CACCHlc;
  float CACCHeadway;
  float CACCEnginelag;
} tLLCConfig;

/// Configuration items
typedef struct AppConfig {
  tLLCConfig LLC;
} tAppConfig;

/// Application data structure
typedef struct MyApp {
  /// MKx handle
  struct MKx *pMKx;
  /// Storage for the Message Buffer (does not reserve data for Data[] content
  /// !)
  uint8_t MsgBuff[sizeof(tMKxIFMsg) + sizeof(tMKxDebugMsgData)];
  /// MKx file descriptor
  int Fd;
  /// Exit flag
  bool Exit;
  /// Application configuration
  tAppConfig Config;
} tMyApp;

/// dump format selection
typedef enum { dumpHexOnly, dumpHexAscii } tDumpFormat;

extern const int POLL_INPUT;
extern const int POLL_ERROR;

//------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------

extern void ex_SetMode(struct MKx *pMKx, tMKxRadio Radio, tMKxRadioMode Mode);
extern void ex_ChConfig_SingleChannelRadio(struct MKx *pMKx, tMKxRadio Radio,
                                           uint16_t ChannelNo, uint8_t power);
extern void ex_ChConfig_Enablecast(struct MKx *pMKx, tMKxRadio Radio,
                                   uint8_t AMSIndex, uint64_t UnicastMAC,
                                   uint64_t mask, uint8_t match);
int InitPlatooning();
int DisseminationBasicService();
// void parseCommand(int Argc, char **ppArgv);

#endif /* UDP-11P_H_ */
