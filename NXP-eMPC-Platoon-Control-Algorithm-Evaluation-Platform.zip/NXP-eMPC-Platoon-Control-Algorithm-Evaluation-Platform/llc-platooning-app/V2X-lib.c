/**
 * @section nxp_llc_examples LLC API
 *
 * @copyright NXP Semiconductors NV
 * @file
 * V2X-lib: Handles sending request from CACC App;
 * generates LLC layer packets accroding to the standard and forwards the packet to llc-api
 * which interacts to the MKX transceiver hardware (llc-source);
 * decodes and preprocesses the received packets obtained from LLC Layer.\n
 * Note that the Network Layer is bypassed in this application.
 *
 */

/*! Masks for LEDs, this is an enum, and the values are power of two to make it
     possible to build masks. The bit number also indicates the port bit number.
      Make sure compiler treats enum's efficient (e.g. as unsigned char, as enum
      by ANSI standard is int). */
typedef enum {
  LED_0 = (1 << 0), /*< Bit0 of port for LED0 */
  LED_1 = (1 << 1), /*< Bit1 of port for LED1 */
  LED_2 = (1 << 2), /*< Bit2 of port for LED2 */
  LED_3 = (1 << 3)  /*< Bit3 of port for LED3 */
} LED_Set;

//---------------------------------------------------------------------------
// Included headers
//---------------------------------------------------------------------------
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/if_tun.h>
#include <linux/serial.h>
#include <net/if.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#include "debug-levels.h"
#include <linux/cohda/llc/llc.h>

#include "V2X-lib.h"
#include "readConfig.h"

#include "version.h"
// control library
#include "controller.h"
// UDP library
#include <netdb.h>

#ifndef SVN_REVISION
#define SVN_REVISION "REV_NOT_DEFINED"
#endif

//------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------

static tMKxStatus my_RxAllocHandler(struct MKx *pMKx, int BufLen,
                                    uint8_t **ppBuf, void **ppPriv);
static tMKxStatus my_TxCnfHandler(struct MKx *pMKx, tMKxTxPacket *pTxPkt,
                                  const tMKxTxEvent *pTxEvent, void *pPriv);
static tMKxStatus my_RxIndHandler(struct MKx *pMKx, tMKxRxPacket *pRxPkt,
                                  void *pPriv);
static void mySignalHandler(int SigNum);

//------------------------------------------------------------------------------
// Variables
//------------------------------------------------------------------------------

/// Verbose level. Used values: 0, 1 and > 1.
/// 0 used for no info. 1 used for some information, >1 used for more details.
int verbose = 0;
int enableLED = 0;
//#define DEBUG
/// static buffer for data received from LLC
static uint8_t _RxBuf[8192];
/// static buffer for data to be transmitted to LLC
static uint8_t _TxBuf[8192];

/// debug output level, copied for environment variable
int D_LEVEL = 255;

/// Global state variable
static volatile int recPackageCnt = 0;
static volatile int txPackageCnt = 0;
/// Pointer to app/command state
extern struct MyApp *pDev;

/// An 802.11 broadcast header
uint8_t BHeader[] = {
    0x88, 0x00,                         //  0. Frame
    0x00, 0x00,                         //  2. Id
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, //  4. Destination (broadcast)
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 10. Source
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // 16. BSSID
    0x50, 0xd0, // 22. Fraq no 0 -> will be overwritten by LLC firmware
    0x00, 0x00, // 24. ack
};

/// The LLC header: When sending a packet through LLC a LLC header must be
/// added. This header has a fixed layout: AA AA 03 00 00 00 89 47 Description
/// of the fields:
/// 1. AA AA: Identifies this is an extended ether type. Previously only two
/// bytes were used to identify the fype.
///           This value (AA AA) indicates an extension of the type field.
/// 2. 03: Control field. Value indicates the message are unnumbered.
/// 3. 00 00 00: Vendor specification: THis value indicates the type is generic,
/// not vendor specific.
/// 4. 89 47: Identifies the type: V2X Geonetworking (ETSI TC-ITS)
uint8_t LLCHeader[] = {
    0xaa, 0xaa, //  0. Extended ether type is defined
    0x03,       //  2. Control field: unnumbered messages
    0x00, 0x00,
    0x00,       //  3. Vendor specification: In this case 'generic/not vendor
                //  specific'
    0x89, 0x47, //  6. Type: V2X Geonetworking (ETSI TC-ITS)
};

struct pollfd FDs[POSIX_IF_CNT] = {{
    -1,
}};

/// Poll mask for input
const int POLL_INPUT = (POLLIN | POLLPRI);
/// Poll mask for error
const int POLL_ERROR = (POLLERR | POLLHUP | POLLNVAL);

//------------------------------------------------------------------------------
// Functions definitions
//------------------------------------------------------------------------------
/// LLCRemote debug request
fMKx_DebugReq LLC_DebugReq = NULL;
/// LLCRemote configure
fMKx_Config LLC_Config = NULL;
/// LLCRemote transmit
fMKx_TxReq LLC_TxReq = NULL;
/// LLCRemote get UTC
// fMKx_GetTSF        LLC_GetTSF   = NULL;
/// LLCRemote set UTC time
fMKx_SetTSF LLC_SetTSF = NULL;
/// LLCRemote flush transmit
fMKx_TxFlush LLC_TxFlush = NULL;
/// LLCRemote security command
fC2XSec_CommandReq C2X_SecCmd = NULL;

/// LED GPIO address
#define GPIO_LED 66
// static tMKxStatus my_NotifIndHandler(struct MKx *pMKx, tMKxNotif Notif);


/**
* @brief Gets called every 50ms, used for statistics and feedback
* @param pMKx   - points to MKx data structure
* @param Notif - start of buffer of received data
*/
static tMKxStatus my_NotifIndHandler(struct MKx *pMKx, tMKxNotif Notif) {
  tMKxRadioStats LLC_Radio_Stats;
  memset(&LLC_Radio_Stats, '\0', sizeof(LLC_Radio_Stats));
  tMKxChannelStats myChannelStats0;
  tMKxStatus staterror;
  tMKxRadio myRadioB = MKX_RADIO_B;
  staterror = (int)MKx_GetStats(pDev->pMKx, myRadioB, &LLC_Radio_Stats);
  myChannelStats0 = LLC_Radio_Stats.RadioStatsData.Chan[MKX_CHANNEL_0];

  if (staterror != 0)
    printf("\nERR: Error in retrieving stats from LLC: %i\n", staterror);

  // General stats for DCCs updated
  LLC_CBR = (int)myChannelStats0.ChannelBusyRatio;
  LLC_CL = (float) LLC_CBR/255.0;
  return 0;
}


/**
 * @brief LED CONTROLLER_H_
 * @param on turn on or turn off
 * @param num   GPIO address
 *
 */
static void LEDout(bool on, int num) {
  char ledf[60];
  int stat;

  sprintf(ledf, "echo %c > /sys/class/gpio/gpio%d/value", on ? '1' : '0', num);
  stat = system(ledf);
  if (WIFSIGNALED(stat) &&
      (WTERMSIG(stat) == SIGINT || WTERMSIG(stat) == SIGQUIT)) {
    printf("Error LED control\n");
  }
}
/**
 * @brief Dump data to output at debug level D_INFO
 * @param data
 * @param len   number of bytes to be dumped
 * @param header dump header
 * @param dForm  dump format [dumpHexOnly|dumpHexAscii]
 *
 */
void dump_data(uint8_t *data, size_t len, char *header, tDumpFormat dForm) {
  size_t index = 0;

  d_fnstart(D_API, NULL, "%s():%d Data @ %p, %d bytes \n", __func__, __LINE__,
            data, len);
  if (len > 0) {
    d_printf(D_INFO, NULL, "%s", header);
    while (index < len) {
      size_t byte;
      char buffer[16];
      char line[81] = {0};

      /* Address */
      sprintf(buffer, "data[0x%.4x]: ", index);
      strcat(line, buffer);

      /* Bytes in HEX */
      byte = 0;
      while (byte < 16) {
        if ((index + byte) < len) {
          sprintf(buffer, " %.2x", (data[index + byte] & 0xFF));
          strcat(line, buffer);
        } else
          strcat(line, "   ");
        byte++;
      }

      if (dForm == dumpHexAscii) {
        /* Separator */
        strcat(line, "  ");

        /* Bytes in ASCII */
        byte = 0;
        while ((byte < 16) && ((index + byte) < len)) {
          if ((data[index + byte] >= ' ') && (data[index + byte] <= '~')) {
            sprintf(buffer, "%c", (data[index + byte] & 0xFF));
            strcat(line, buffer);
          } else
            strcat(line, ".");
          byte++;
        }
      }
      /* Line ending */
      d_printf(D_INFO, NULL, "%s\n", line);
      line[0] = 0;
      /* Next line */
      index += 16;
    }
  }
}
/**
 * @brief Signal Handler
 * @param SigNum the signal caught
 *
 * Set the exit flag so that application can exit following next
 * main loop iteration.
 *
 */
static void mySignalHandler(int SigNum) {
  d_printf(D_TST, NULL, "Signal %d!\n", SigNum);
	//printf("SIGINT %d, SIGTERM %d, SIGQUIT %d, SIGHUP %d, SIGPIPE %d\n",SIGINT,SIGTERM,SIGQUIT,SIGHUP,SIGPIPE);
	if (SigNum != SIGPIPE)
	pDev->Exit = true;
	//printf("\n\n\n\nMySignalHandler%d, is %d\n\n\n\n",pDev->Config.LLC.LLCRole,SigNum);
}
/**
 * @brief Send a message, by adding MAC broadcast header
 * @param buf   uint8_t pointer to start of payload buffer
 * @param lend  number of bytes buf payload to be send
 * @param Radio  the radio to be used for sending
 * @param Power  the transmit power to be used for sending
 * @param Coding  the modulation to be used for sending
 *
 */
static void send_msg(uint8_t *buf, uint16_t lend, tMKxRadio Radio,
                     uint8_t Power, uint8_t Coding) {
  tMKxTxPacket *pTxPkt = NULL;
  uint8_t *pBuf = _TxBuf;
  int len;

  if (pBuf) {

    len = lend;

    pTxPkt = (tMKxTxPacket *)(pBuf + LLC_ALLOC_EXTRA_HEADER);
    memset(pTxPkt, 0, sizeof(tMKxTxPacket) + len + 4);
    memcpy(&(pTxPkt->TxPacketData.TxFrame[0]), BHeader, sizeof(BHeader));
    memcpy(&(pTxPkt->TxPacketData.TxFrame[sizeof(BHeader)]), LLCHeader,
           sizeof(LLCHeader));
    memcpy(&(pTxPkt->TxPacketData.TxFrame[sizeof(BHeader) + sizeof(LLCHeader)]),
           buf, lend);

    pTxPkt->TxPacketData.RadioID = Radio;
    pTxPkt->TxPacketData.ChannelID = MKX_CHANNEL_0;
    pTxPkt->TxPacketData.TxAntenna = MKX_ANT_DEFAULT;
    pTxPkt->TxPacketData.MCS = Coding;
    pTxPkt->TxPacketData.TxPower = Power;
    pTxPkt->TxPacketData.Expiry = 0ULL; // don't expire
    pTxPkt->TxPacketData.TxFrameLength =
        sizeof(BHeader) + sizeof(LLCHeader) + len;

    // Print additional log information, if verbose is set
    if (verbose == 1) {
      dump_data(buf, lend, "LLC send payload data\n", dumpHexOnly);
    }

    if (verbose > 1) {
      dump_data((uint8_t *)pTxPkt, (pTxPkt->TxPacketData.TxFrameLength),
                "LLC send raw data\n", dumpHexOnly);
    }

    LLC_TxReq(pDev->pMKx, pTxPkt, pBuf);
    // EXCLUDE printf("Transmitted 11p: %d\n", len);
  }
}
/**
 * @brief MKx_RxAlloc callback function, which uses static
 * @param pMKx   - points to MKx data structure
 * @param BufLen - number of bytes requested for reception buffer
 * @param ppBuf  - returns pointer to start of payload location of allocated
 * buffer
 * @param ppPriv - returns pointer to start of allocated buffer
 * @return Zero if successful, otherwise a negative errno
 */
static tMKxStatus my_RxAllocHandler(struct MKx *pMKx, int BufLen,
                                    uint8_t **ppBuf, void **ppPriv) {
  int Res = -ENOSYS;
  d_fnstart(D_API, NULL, "(pMKx %p BufLen %d )\n", pMKx, BufLen);

  uint8_t *pBuf = _RxBuf; // use static buffer
  memset(_RxBuf, 0, sizeof(_RxBuf));
  if (!pBuf) {
    Res = -ENOMEM;
    goto Error;
  }
  *ppBuf = pBuf + LLC_ALLOC_EXTRA_HEADER;
  *ppPriv = pBuf;
  Res = 0; // no error!
  d_printf(D_INFO, NULL, "BufLen %d *ppBuf %p *ppPriv %p\n", BufLen, *ppBuf,
           *ppPriv);
Error:
  d_fnend(D_API, NULL, "(pMKx %p) = %d\n", pMKx, Res);
  return Res;
}
/**
 * @brief MKx_TxCnf callback function, called when a packed has been transmitted
 * @param pMKx   - points to MKx data structure
 * @param pTxPkt - not valid
 * @param pTxEvent - not valid
 * @param pPriv  - not valid
 * @return Zero if successful, otherwise a negative errno
 */
static tMKxStatus my_TxCnfHandler(struct MKx *pMKx, tMKxTxPacket *pTxPkt,
                                  const tMKxTxEvent *pTxEvent, void *pPriv) {
  int Res = -ENOSYS;
  d_fnstart(D_API, NULL, "(pMKx %p pTxPkt %p TxStatus %d)\n", pMKx, pTxPkt,
            pTxEvent->TxEventData.TxStatus);

  return Res;
}
/**
 * @brief Porcess the received V2X packets (Sensor Fusion)
 * @param data pointer to the packet payload of the received V2X packets
 * @return True if data shall be processed at the platoon controller,
 * otherwise a False
 *
 */
bool ProcessV2X(char *data) {
  // struct timespec   lTimeSpec;
  // double            lLoopCurrent;
  if (!strncmp(data, "CACCZHU", 7)) {
    if ((pDev->Config.LLC.LLCRole - *(uint8_t *)(&data[8]) == 1)
    || pDev->Config.LLC.LLCRole==255){
      if ( data[9] == 'E' && pDev->Config.LLC.LLCRole!=255) {
        return true;
      } else if (data[9] == 'D') {
        // clock_gettime( CLOCK_REALTIME, &lTimeSpec);
        // lLoopCurrent = (double) (lTimeSpec.tv_sec) +
        //  (double) (lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
        // //printf("Received terminating message [%lf] at %lf\n", strtod
        // (&data[2], NULL), lLoopCurrent); printf("Time difference %d-%d:
        // %lf\n", pDev->Config.LLC.LLCRole,*(uint8_t*)(&data[8]),
        // lLoopCurrent-strtod (&data[3], NULL));
        pDev->Exit = true;
				//printf("\n\n\n\nProcessV2X%d\n\n\n\n",pDev->Config.LLC.LLCRole);
        return false;
      } else
        return false;
    } else
      return false;
  } else
    return false;
}
/**
 * @brief MKx_RxInd callback function, called when a packed is received
 * @param pMKx   - points to MKx data structure
 * @param pRxPkt - start of buffer of received data
 * @param pPriv  - start of allocated buffer
 * @return Zero if successful, otherwise a negative errno
 *
 */
static tMKxStatus my_RxIndHandler(struct MKx *pMKx, tMKxRxPacket *pRxPkt,
                                  void *pPriv) {
  int Res = -ENOSYS;
  uint8_t *cp;
  int dataLen;
  int pLength = 0;
  uint8_t tempBuffer[MESSAGE_BUFSIZE];
  int lengthMessage;

  d_fnstart(D_API, NULL, "(pMKx %p pRxPkt %p)\n", pMKx, pRxPkt);

  tMKxRxPacketData *myRxData;
  myRxData = &(pRxPkt->RxPacketData);

  d_printf(D_INFO, NULL,
           " pRxPkt: RadioID %d, ChannelID %d, MCS %d, Pwr = (%d, %d), Noise "
           "(%d, %d), size %d\n",
           myRxData->RadioID, myRxData->ChannelID, myRxData->MCS,
           myRxData->RxPowerA, myRxData->RxPowerB, myRxData->RxNoiseA,
           myRxData->RxNoiseB, myRxData->RxFrameLength);

  if (verbose > 1) {
    cp = pPriv + LLC_ALLOC_EXTRA_HEADER;
    dump_data(cp, (myRxData->RxFrameLength) + 36, "LLC received raw data\n",
              dumpHexOnly);
  }

  // Check the amount of received bytes. They must be at least the size of the
  // MAC header. For some reason the received bytes contains four byes extra at
  // the end. These need to be removed.
  pLength = myRxData->RxFrameLength - 4;
  if (pLength >= (sizeof(BHeader) + sizeof(LLCHeader))) {

    if (verbose > 1) {
      dump_data(myRxData->RxFrame, myRxData->RxFrameLength,
                "LLC received frame data\n", dumpHexOnly);
    }

    // Point to real payload, so after MAC header
    cp = &myRxData->RxFrame[sizeof(BHeader) + sizeof(LLCHeader)];
    dataLen = pLength - (sizeof(BHeader) + sizeof(LLCHeader));

    // Copy the payload to the message buffer
    lengthMessage = dataLen;
    memset(tempBuffer, '\0', MESSAGE_BUFSIZE);
    memcpy(tempBuffer, cp, lengthMessage);
    // printf("Received Platooning Beacon from %c of length %d: %lf\n",
    // *(uint8_t*)(&tempBuffer[8]), lengthMessage, a_des_v2x_buffer);
    // Checking the received packet
    if (ProcessV2X((char *)tempBuffer)) {
      // a_des_v2x_buffer = strtod ((char*)&tempBuffer[3], NULL);
      // a_des_v2x_buffer = *(double*)(&tempBuffer[16]);
      memcpy(&acc_v2x_buffer, &tempBuffer[16], sizeof(double));
			memcpy(&ts_v2x_buffer, &tempBuffer[24], sizeof(double));
			memcpy(&vel_v2x_buffer, &tempBuffer[32], sizeof(double));
      memcpy(&packetnumber, &tempBuffer[12], sizeof(uint32_t));
      if (((packetnumber - 1) != packetnumber_last) &&
          (packetnumber_last != 0)) {
        packetlosscounter++;
        fprintf(stderr,
                "\nPacket loss detected @ DEVICE%d; %d Packets received \n",
                pDev->Config.LLC.LLCRole, packetnumber);
      }
      packetnumber_last = packetnumber;
      // Print the data received to the console.
#ifdef DEBUG
      printf("Received Platooning Beacon from %c of length %d: %lf\n",
             *(uint8_t *)(&tempBuffer[8]), lengthMessage, a_des_v2x_buffer);
#endif
    }
  } else {
    d_printf(D_WARN, NULL, "Short packet\n");
  }
  d_fnend(D_API, NULL, "(pMKx %p pRxPkt %p) = %d\n", pMKx, pRxPkt, Res);
  return Res;
}
/**
 * @brief Converting array to integer
 * @param u   uint8_t pointer to start of the string
 * @param len number of bytes buf payload to be converted
 * @return Integer corresponding to u
 */
uint32_t arrayToInt(uint8_t *u, int len) {
  int i;
  uint32_t rval = 0;

  for (i = 0; i < len; i++) {
    rval = (*u & 0xFF) + (rval << 8);
    u++;
  }
  return rval;
}
/**
 * @brief Exiting operations
 * @return Zero if successful, otherwise a negative errno
 *
 */
int ExitPlatooning() {
  int Res;
  long long tempTimestamp;
  struct timespec lTimeSpec;
  double lLoopCurrent;
  uint8_t tempBuffer[MESSAGE_BUFSIZE];
  // Sending terminating message
  if (pDev->Config.LLC.LLCRole != 0) {
    clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
    tempTimestamp = ((long long)(1000 * lLoopCurrent) - Jan_01_2004);
    platooningBeacon DSRC_Message = {"CACCZHU", 0, 'D', 0, 0, 0.0, BLANKFIELD};
    DSRC_Message.vehicleId = pDev->Config.LLC.LLCRole;
    DSRC_Message.timeStamp = tempTimestamp % 65536;
    DSRC_Message.sequenceNumber = lLoopCountC;
		DSRC_Message.ts=lLoopCurrent;
    memcpy((char *)tempBuffer, &DSRC_Message, sizeof DSRC_Message);
    int lengthMessage = sizeof(platooningBeacon);
    send_msg(tempBuffer, lengthMessage, pDev->Config.LLC.LLCRadio,
             pDev->Config.LLC.LLCPower, pDev->Config.LLC.LLCCoding);
    printf("Sending terminating message: [%s]\n", tempBuffer);
  }
  printf("\nTerminating llc-communication-test @ DEVICE%d; %d Packets "
         "received; %d Packets lost \n",
         pDev->Config.LLC.LLCRole, packetnumber, packetlosscounter - 1);

  ex_SetMode(pDev->pMKx, pDev->Config.LLC.LLCRadio, MKX_MODE_OFF);

  Res = MKx_Exit(pDev->pMKx);

  if (FDs[POSIX_IF_MKX].fd >= 0)
    FDs[POSIX_IF_MKX].fd = -1;
  return Res;
}
/**
 * @brief Dissemination Basic Service (DBS), controlling the timing to transmit
 * and receive
 * @return Zero if successful, otherwise a negative errno
 *
 */
int DisseminationBasicService() {
  int Cnt = 0;
  int Res = 0;
  uint8_t tempBuffer[MESSAGE_BUFSIZE];
  int lengthMessage;
  struct timespec lTimeSpec;
  double lLoopPrevious;
  double lLoopCurrent;
  long long temp;
  bool LEDon = false;
  printf("\nEntering polling loop, receiving and sending 802.11p messages\n");
  lLoopPrevious = 0.0;
  lLoopCurrent = 0.0;
  do {
    // Wait for an event on the file descriptors
    // poll() returns >0 if descriptor is readable, 0 if timeout, -1 if error
    int Data = poll(FDs, POSIX_IF_CNT, POLL_TIMEOUT_MSEC);
    if (Data < 0) // Error
    {
      d_printf(D_WARN, NULL, "Poll error %d '%s'\n", errno, strerror(errno));
      Res = -errno;
      pDev->Exit = true;
			printf("\n\n\n\nDataError%d\n\n\n\n",pDev->Config.LLC.LLCRole);
    } else if (Data == 0) // Timeout
    {
      // timeout
      Cnt++;
      // d_printf(D_DBG, NULL, "Poll timeout %d\n", Cnt );
    }

    // Identify FD unblocking
    if (FDs[POSIX_IF_MKX].revents & POLL_ERROR) {
      d_error(D_ERR, NULL, "Poll error on LLC interface (revents 0x%02x)\n",
              FDs[POSIX_IF_MKX].revents);
    }

    // Received data from LLC
    if (pDev->Config.LLC.LLCRole != 0) {
    // Every vehicle except the leader needs to receive
      if (FDs[POSIX_IF_MKX].revents & POLL_INPUT) {
        if (verbose > 1) {
          d_printf(D_DBG, NULL, "LLC received\n");
        }

        Res = MKx_Recv(pDev->pMKx);
      }
    }
    if (pDev->Config.LLC.LLCRole != 0) {
    // Every vehicle needs to transmit
      clock_gettime(CLOCK_REALTIME, &lTimeSpec);
      lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                     (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
      // Time to send
      if ((lLoopCurrent - lLoopPrevious) >=
          (pDev->Config.LLC.LLCDelay * MILLI_SEC_TO_SEC)) {
        temp = ((long long)(1000 * lLoopCurrent) - Jan_01_2004);

        // printf(
        // printf("Initialize a packet (platooningBeacon)\n" );
        platooningBeacon DSRC_Message = {"CACCZHU", 0, 'E', 0, 0, 0.0, BLANKFIELD};
        DSRC_Message.vehicleId = pDev->Config.LLC.LLCRole;
        DSRC_Message.timeStamp = temp % 65536;
        DSRC_Message.sequenceNumber = lLoopCountC + 1;
				DSRC_Message.ts= lLoopCurrent;
				DSRC_Message.vel = vel_actual;
        // platooningBeaconGenerator();
        if (pDev->Config.LLC.LLCRole > 1) {
          switch (pDev->Config.LLC.CACCAccler) {
          case 0:
            DSRC_Message.CA = a_des;
            break;
          case 1:
            DSRC_Message.CA = a_actual;
            break;
          case 2:
            DSRC_Message.CA = 0;
            break;
          }
        } else if (lLoopCountC < SIM_LENGTH){
									//(lLoopCountC * pDev->Config.LLC.LLCDelay /
                  //     (1000 * REF_MESSAGE_INTERVAL) <
                  // simulationLength) {
          // DSRC_Message.CA = a_ref[lLoopCountC*step];
          switch (pDev->Config.LLC.CACCAccler) {
          case 0:
            DSRC_Message.CA = a_des;
            break;
          case 1:
            DSRC_Message.CA = a_actual;
            break;
          case 2:
            DSRC_Message.CA = 0;
            break;
          }
        } else {
					
          pDev->Exit = true;
        }
        memcpy((char *)tempBuffer, &DSRC_Message, sizeof DSRC_Message);
        // lengthMessage = strlen((const char *) tempBuffer);
        lengthMessage = sizeof(platooningBeacon);
        send_msg(tempBuffer, lengthMessage, pDev->Config.LLC.LLCRadio,
                 pDev->Config.LLC.LLCPower, pDev->Config.LLC.LLCCoding);
#ifdef DEBUG
        printf("Send message [%s] after interval: %f sec\n", tempBuffer,
               (lLoopCurrent - lLoopPrevious));
#endif
        lLoopCountC++;
        if (enableLED) {
          LEDout(LEDon, GPIO_LED);
          LEDon = !LEDon;
        }
        lLoopPrevious = lLoopCurrent;
      }
    }
  } while (pDev->Exit == false);
  // Exit
	fprintf(stderr,"lLoopCountC= %ld, SIM_LENGTH= %d, veh= %d\n", lLoopCountC, SIM_LENGTH,pDev->Config.LLC.LLCRole);
  Res = ExitPlatooning();
  return Res;
}
/**
 * @brief Initialization of the communication functions
 * @return Zero if successful, otherwise a negative errno
 */
int InitPlatooning() {
  int Res = 0;

  // Get the debug level from the environment
  D_LEVEL_INIT();

  // setup the signal handlers to exit gracefully
  d_printf(D_DBG, NULL, "Signal handlers\n");
  pDev->Exit = false;

  signal(SIGINT, mySignalHandler);
  signal(SIGTERM, mySignalHandler);
  signal(SIGQUIT, mySignalHandler);
  signal(SIGHUP, mySignalHandler);
  signal(SIGPIPE, mySignalHandler);

  printf("V2X RoadLink LLC Initializing...\n");
  printf("Software version: %s\n\n", SVN_REVISION);

  // Initialize the MKx structure, opens the socket
  Res = MKx_Init(&(pDev->pMKx));
  if (Res != 0 || pDev->pMKx == NULL) {
    d_error(D_ERR, NULL, " Error initializing MKx structure (%d, %p)\n", Res,
            pDev->pMKx);
    return Res;
  }

  pDev->Fd = MKx_Fd(pDev->pMKx);
  if (pDev->Fd < 0) {
    d_error(D_ERR, NULL, " Error initializing interface filenumber (%d)\n",
            pDev->Fd);
    return Res;
  }

  FDs[POSIX_IF_MKX].fd = pDev->Fd;
  if (FDs[POSIX_IF_MKX].fd < 0)
    return Res; // setup the poll events
  FDs[POSIX_IF_MKX].events = POLL_INPUT;

  // Prepare the MKx handle for the potential replies
  pDev->pMKx->pPriv = (void *)pDev;

  // Prepare MKx Function pointers
  LLC_DebugReq = pDev->pMKx->API.Functions.DebugReq;
  LLC_Config = pDev->pMKx->API.Functions.Config;
  LLC_TxReq = pDev->pMKx->API.Functions.TxReq;
  // LLC_GetTSF   = pDev->pMKx->API.Functions.GetTSF;
  LLC_SetTSF = pDev->pMKx->API.Functions.SetTSF;
  LLC_TxFlush = pDev->pMKx->API.Functions.TxFlush;
  C2X_SecCmd = pDev->pMKx->API.Functions.C2XSecCmd;

  // Setup Callback handlers
  pDev->pMKx->API.Callbacks.TxCnf = my_TxCnfHandler;
  pDev->pMKx->API.Callbacks.RxAlloc = my_RxAllocHandler;
  pDev->pMKx->API.Callbacks.RxInd = my_RxIndHandler;
  pDev->pMKx->API.Callbacks.NotifInd = my_NotifIndHandler;
  ex_ChConfig_SingleChannelRadio(pDev->pMKx, pDev->Config.LLC.LLCRadio,
                                 pDev->Config.LLC.LLCChannelNo,
                                 pDev->Config.LLC.LLCPower);
  ex_ChConfig_Enablecast(pDev->pMKx, pDev->Config.LLC.LLCRadio, 0,
                         0xFFFFFFFFFFFF, 0xFFFFFFFFFFFF, 0x08); // AMS_Broadcast

  return Res;
}
