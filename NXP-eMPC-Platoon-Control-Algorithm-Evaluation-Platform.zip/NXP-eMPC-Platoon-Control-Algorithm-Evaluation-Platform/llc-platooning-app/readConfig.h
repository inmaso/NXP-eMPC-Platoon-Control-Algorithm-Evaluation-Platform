/**
 * @section nxp_llc_examples LLC API_H
 *
 * @copyright NXP Semiconductors NV
 * @file
 * eadConfig.h
 */
/*
 * readConfig.h
 *
 *  Created on: Feb 15, 2016
 *      Author: Han Raaijmakers
 */

#ifndef READCONFIG_H_
#define READCONFIG_H_

/// Verbose level. Used values: 0, 1 and > 1.
/// 0 used for no info. 1 used for some information, >1 used for more details.
extern int verbose;

int readConfig( char* filename, tAppConfig* config);

#endif /* READCONFIG_H_ */
