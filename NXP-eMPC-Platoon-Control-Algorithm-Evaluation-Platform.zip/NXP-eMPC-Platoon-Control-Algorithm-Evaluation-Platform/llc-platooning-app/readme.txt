Test application: llc-communication-test.

This application can be used to test the 11p communication using only the llc interface.
Use one MK5 to run the receiving role and one MK5 to run the transmitting role.

Commands to start the nodes:
1. Rx: sudo ./llc-communication-test -f test_rx.conf
2. Tx: sudo ./llc-communication-test -f test_tx.conf

The parameters are specified using the configuration files. Two sample configuration files are added 
with the code here. The files itself contain a description on the supported parameters and their values.


Sample output on the Rx node:
Welcome to V2X RoadLink LLC Communication test (llc-communication-test)
Software version: Unversioned directory

Configuration:
  Radio    = A
  Channel  = 182 (5910 MHz)
  Bitrate  = 6000
  Coding   = MKXMCS_R12QPSK
  Delay    = 1000 msec
  Role     = R

Entering polling loop, receiving and sending 802.11p messages
Received message of length 25: LCC-Communication-test[1]
Received message of length 25: LCC-Communication-test[2]
Received message of length 25: LCC-Communication-test[3]
Received message of length 25: LCC-Communication-test[4]
^C
Terminating llc-communication-test

At the end of llc-communication-test



Sample output on the Tx node:
Welcome to V2X RoadLink LLC Communication test (llc-communication-test)
Software version: Unversioned directory

Configuration:
  Radio    = A
  Channel  = 182 (5910 MHz)
  Bitrate  = 6000
  Coding   = MKXMCS_R12QPSK
  Delay    = 1000 msec
  Role     = T

Entering polling loop, receiving and sending 802.11p messages
Send message [LCC-Communication-test[1]] after interval: 1486732709.921752 sec
Send message [LCC-Communication-test[2]] after interval: 1.000008 sec
Send message [LCC-Communication-test[3]] after interval: 1.000005 sec
Send message [LCC-Communication-test[4]] after interval: 1.000006 sec
^C
Terminating llc-communication-test

At the end of llc-communication-test
