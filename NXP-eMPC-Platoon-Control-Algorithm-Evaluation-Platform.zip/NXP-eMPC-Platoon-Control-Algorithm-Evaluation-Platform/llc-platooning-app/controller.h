/**
 * @section nxp_llc_examples LLC API_H
 *
 * @copyright NXP Semiconductors NV
 * @file
 * contoller.h: Provides the interface to MKX transceiver hardware;
 * handles sending request from upper layers;
 * decodes and preprocesses the received packets.
 */
#ifndef CONTROLLER_H_
#define CONTROLLER_H_
/// Vehicle settings
#define VEHICLE_LENGTH              (4)
#define INITIAL_SPEED								(0) //Not working for different that 0. Difficult to coordinate cars
#define LEADER_POSITION							(100) //Starting position of the leader
#define STAND_STILL_DISTANCE        (2) //distance separating the vehicles when the speed is 0
#define PROFILE											(5) //0 = truck, 1 = car, 2 = amr standard, 3 = emergency braking, 4 = fuel analysis, 5 = amr profile 2

#define ENGINE_LAG_TIME_CONSTANT    (0.1)
#define ENGINE_SAMPLING_TIME        (0.002)

#define TIMEHEADWAY                 (0.2)
#define MESSAGE_RATE       					(2)//in Hz. valid range 1-10. Suggested 10, 5, 2, 1.
#define NO_MESSAGE_ACC							1	//when 1, if the message rate is lower, the car still uses radar
#define SATURATE_ACTUATOR						0 //when 1, the acceleration will be limited to +/- 3 (m/s^2)
#define BIRD												0 //when >0, a bird will pass BIRD meters in front of the 2nd vehicle
/// Radar measurement time interval
#define RADAR_INTERVAL              (0.1) //Base rate of sending messages. Do NOT use to modify message rate
//Lower layer configuration
#define PHI11												(0.999996484021898)
#define PHI12												(-0.003296764379863)
#define PHI21												(0.001648382189931)
#define PHI22												(0.670303562213740)
#define GAMMA1											(0.000026369835765)
#define GAMMA2											(0.024725732848969)
#define K1													(-202.0850076179109)
#define K2													(5.4610677487553)
#define FF														(202.2183409512441)
#define HORIZON										(15) //Horizon length - do not modify
// UDP configurations
#define RADAR_DESTINATION_2 "fe80::6e5:48ff:fe20:00ec"
#define RADAR_ETH_PORT12 "1114"
#define RADAR_DESTINATION_3 "fe80::6e5:48ff:fe20:0048"
#define RADAR_ETH_PORT23 "1117"
#define RADAR_DESTINATION_4 "fe80::6e5:48ff:fe20:027c"
#define RADAR_ETH_PORT34 "1120"
//Simulation configuration
#define SIM_LENGTH (800) //Number of messages sent before closing (ignoring message rate), roughly sim_length=seconds*10
													//if you use the profiles 1 2 or 3, sim_length 400 is sufficient. For profile 0, 4 and 5 use 800.

extern struct MyApp *pDev;
extern int DCC_SM;

double a_des;
double a_actual;
/// Vehicle State; note that the values in this structure are all one-dimensional on x-axis
#ifndef CARSTATE_DEFINED
#define CARSTATE_DEFINED
typedef struct car_state{
	/// Current position of this vehicle.
	double position;
	/// Current velocity of this vehicle.
	double velocity;
	/// Actual acceleration of this vehicle.
	double acceleration;
	/// Current jerk of this vehicle.
	double jerk;
	/// Desired acceleration of this vehicle.
	double desiredAcceleration;
	/// Gap with respect to the predecessor
	//double gap;
}car;
#endif
/// Radar Measurement
typedef struct accRadar{
	/// Distance to the predecessor
	double distance;
	/// Last measurement of distance
	double distance_last;
	/// Relative velocity to the predecessor
	double relative_velocity;
	/// Acceleration of the predecessor
	double acceleration;
	/// Derivative of the acceleration (jerk) of the predecessor
	double jerk;
}RADAR;
/// Pointer to the data read from look-up table
extern double * profileData;

// Functions
void message_decoder(struct car_state *car, struct car_state *car_clean, char * data, int count);

void gap_filter(struct car_state *pred, struct car_state *foll);

double * readSimulationProfile(char * filename);

struct car_state SpeedController(struct car_state currentState, double h_lower, 
double phi11, double phi12, double phi21, double phi22, double gamma1, double gamma2, double f, 
double k1, double k2);

void compute_matrices(double horizon, double feed_forward, const double k1[2], double tauh, 
											double h_upper, double h_lower, double G_array[225], double twoGamaQ_barfi_array[60], 
											double twoGamaQ_barpsi_array[225], double L_array[2700], double w_array[640],	
											double Mpsi_array[2400], double c_array[160], double *min_eig, double* max_eig);


void print_car_state(char* msg, struct car_state car);

void *sendingThreadRadar();

void *receivingThreadRadar();

void *low_level_thread();

void *high_level_thread();

#endif
