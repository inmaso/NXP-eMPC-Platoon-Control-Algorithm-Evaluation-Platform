/**
 * @section control function library
 * @author Sijie Zhu
 * @date May/2018
 * @copyright NXP Semiconductors NV
 * @file
 * control functions: includes high-level controller, low-level controller
 * and a longitudinal vehicle dynamics model, and their thread functions.
 *
 *
 */
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/if_tun.h>
#include <linux/serial.h>
#include <math.h>
#include <net/if.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>
#include <gsl/gsl_math.h>  //For eigenvalue computation
#include <gsl/gsl_matrix.h>//For eigenvalue computation
#include <gsl/gsl_eigen.h> //For eigenvalue computation

#include "debug-levels.h"
#include <linux/cohda/llc/llc.h>

#include "version.h"
// control library
#include "controller.h"
// UDP library
#include <netdb.h>
// V2X library
#include "V2X-lib.h"
//MPC related
#include "mpc/rt_nonfinite.h"
#include "mpc/rtwtypes.h"
#include "mpc/matrix_init_types.h"
#include "mpc/FGM.h"
#include "mpc/matrix_init.h"
#include "mpc/matrix_final.h"
#include "mpc/matrix_init_emxAPI.h"


/// Vehicle state buffer
car current = {0, INITIAL_SPEED, 0, 0, 0};
car predecessor = {0, INITIAL_SPEED, 0, 0, 0};
car predecessor_clean = {0, INITIAL_SPEED, 0, 0, 0};

int new_message_received=0;
int headway_change = 0;
double time_headway = TIMEHEADWAY;
int start=0;
double time_difference;
double timestamp=0;
//Temporary stuff to delete
double time_rcv;
double time_snd;

static clock_t tic_timestart[4];
void tic(int index) {
  tic_timestart[index] = clock();
}
float tocq(int index) {
  clock_t tic_timestop;
  tic_timestop = clock();
  return (float)((float)(tic_timestop - tic_timestart[index]) / CLOCKS_PER_SEC);
}

void print_array(double* A, int x, int y){
	int i,j;
	for (i=0; i<x; i++){
		for (j=0; j<y; j++){
			fprintf(stderr,"%010.6f  ",*(A+j+i*x));
		}
		fprintf(stderr,"\n");
	}
}

double leader_profile(int j){
	double aref;	
	if (PROFILE==0){
	//Power consistent profile - Truck
		if ( j<=16) 
		  aref= (j)*0.0625;    
		else if (j>16 && j<=95) 
		  aref=1;
		else if (j>95&& j<=157 )
		  aref=-(j-95)*(0.008)+1;
		else if (j>157&& j<=560)
		  aref=-(j-157)*(0.0012)+0.5;
		else if (j>500 && j<=600)
			aref=0;
		else if (j>600&& j<=630 )
		  aref=-(j-600)*(0.1);
		else if (j>630&& j<=660 )
		  aref=(j-630)*0.1-3;  
		else if (j>660&& j<=700) 
		  aref=0; 
		else
			aref=0;  
	}else if (PROFILE==1){
//Power consistent car profile
		if ( j<=25) 
	    aref= (j)*0.08;    
		else if (j>25 && j<=100) 
	    aref=2;
		else if (j>100 && j <= 120)
			aref=-(j-100)*(0.025)+2;
	  else if (j>120&& j<=135 )
	    aref=-(j-120)*(0.1)+1.5;
		else if (j>135&& j<=200)
	    aref=0;
		else if (j>200&& j<=230 )
	    aref=-(j-200)*(0.1);
		else if (j>230&& j<=260 )
	    aref=(j-230)*0.1-3;  
		else if (j>260&& j<=400) 
	    aref=0; 
		else
			aref=0;       
	}else if (PROFILE==2){
	//AMR original profile
		if ( j<=30) 
	    aref= (j)*0.08;    
		else if (j>30 && j<=100) 
	    aref=2.4;
	  else if (j>100&& j<=120 )
	    aref=-(j-100)*(0.12)+2.4;
		else if (j>120&& j<=200)
	    aref=0;
		else if (j>200&& j<=230 )
	    aref=-(j-200)*(0.1);
		else if (j>230&& j<=260 )
	    aref=(j-230)*0.1-3;  
		else if (j>260&& j<=400) 
	    aref=0; 
		else
			aref=0;       
	}else if (PROFILE==3){
//Emergency braking profile (unreasonably jerky profile, do not measure comfort)
		if ( j<=120) 
	    aref=2.4;
	  else if (j>120&& j<=230 )
	    aref=0;
		else if (j>230&& j<=325 )
	    aref=-3;
		else if (j>325&& j<=400) 
	    aref=0; 
		else
			aref=0;  
	}else if (PROFILE==4){
	//Fuel consumption analysis
		if ( j<=30) 
	    aref= (j)*0.08;    
		else if (j>30 && j<=100) 
	    aref=2.4;
	  else if (j>100&& j<=120 )
	    aref=-(j-100)*(0.12)+2.4;
		else
			aref=0;  
	}else if (PROFILE==5){
	//AMR new profile
		if ( j<=30)  
    	aref= (j)*0.08;   
		else if (j>30 && j<=131)  
    	aref=2.4;
		else if (j>131 && j<=200)
    	aref=0;
		else if (j>200 && j<=230)
   		aref=0 ;
		else if (j>230 && j<=260)
    	aref=0 ; 
    else if (j>260 && j<=300)
    	aref=0;     
    else if (j>300 && j<=356)
      aref= -3;
    else if (j>356 && j<=500)
      aref= 0;
    else if (j>500 && j<=600)
      aref=1.5;
    else if (j>600)
      aref= 0;  
	} else {
		aref=0;
	}     
  return aref;
}

void eigenvalues(double G[225],double* min, double* max)
{
	gsl_eigen_nonsymm_workspace* w;
	w = gsl_eigen_nonsymm_alloc(15);
	gsl_matrix_view G_gsl = gsl_matrix_view_array (G, 15, 15);
	gsl_vector_complex *res_gsl = gsl_vector_complex_alloc (15);
	gsl_eigen_nonsymm(&G_gsl.matrix, res_gsl,w);
	gsl_eigen_nonsymm_free(w); 


	int i;
	double smallest, largest;
	gsl_complex eval_i = gsl_vector_complex_get (res_gsl, 0);
	smallest=GSL_REAL(eval_i);
	largest= GSL_REAL(eval_i);
	for (i = 1; i < 15; i++)
	{
		gsl_complex eval_i = gsl_vector_complex_get (res_gsl, i);
		if (GSL_REAL(eval_i)>largest) largest = GSL_REAL(eval_i);
		if (GSL_REAL(eval_i)<smallest) smallest = GSL_REAL(eval_i);
	}
	gsl_vector_complex_free(res_gsl);
	*min=smallest;
	*max=largest;
}


void mpc(double u_start[15],double G_array[225],double twoGamaQ_barfi_array[60],double twoGamaQ_barpsi_array[225], double w_array[640], double Mpsi_array[2400], double c_array[160],double L_array[2700],	double old_u[15], struct car_state foll, struct car_state pred, double min, double max) {
	double F[15];
	double bi[15];
	double eta = 0.0001;
	double u_min = -3;
	double u_max = 3;
	double gap = pred.position - foll.position;
	matrix_final(gap, foll.velocity, foll.acceleration, foll.jerk,
						 		pred.velocity, pred.acceleration, STAND_STILL_DISTANCE+VEHICLE_LENGTH,
 								twoGamaQ_barfi_array, twoGamaQ_barpsi_array, w_array, Mpsi_array, c_array, 
								time_headway, HORIZON, F, bi);//, pDev->Config.LLC.LLCRole);
	
	FGM(u_min, u_max, eta, min, max, G_array, old_u, F, HORIZON, u_start);//umin,umax,eta,mu,L(eigenvalue),...
	if (u_start[0]<-2.0){
		fprintf(stderr,"Gap: %f, Verr: %f, Apre: %f\n",gap,pred.velocity-foll.velocity,pred.acceleration);
	}
}


/**
 * @brief Thread where the low-level controller, LVDM and logging functions execute
 *
 */
void *low_level_thread(){
  // vehicle state initailization
  if (pDev->Config.LLC.LLCRole == 1){
    current.position = LEADER_POSITION;
		start=1;
	}
  else if (pDev->Config.LLC.LLCRole == 2){
    current.position = LEADER_POSITION-(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);
		predecessor.position = LEADER_POSITION;
		predecessor_clean.position = LEADER_POSITION;}
  else if (pDev->Config.LLC.LLCRole == 3){
    current.position = LEADER_POSITION-2*(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);
		predecessor.position = LEADER_POSITION-(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);
		predecessor_clean.position = LEADER_POSITION-(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);}
  else{ // vehicle 4 or the jammmer
    current.position = LEADER_POSITION-3*(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);
		predecessor.position = LEADER_POSITION-2*(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);
		predecessor_clean.position = LEADER_POSITION-2*(STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY);}
  struct timespec lTimeSpec;
  double lLoopCurrent, old_lLoopCurrent;
	//int first_time=1;
	int logging_period=0;
  char logName[] = "Log***.csv";
  sprintf(logName, "Log%d.csv", pDev->Config.LLC.LLCRole);
  printf("Logging into %s\n", logName);
  FILE *pFile = fopen(logName, "w");
	float time_elapsed=0;
	int i;
	double sleep;
	int detected=0;
	clock_gettime(CLOCK_REALTIME, &lTimeSpec);
		old_lLoopCurrent = (double)(lTimeSpec.tv_sec) + (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
  while (1) {
    // Delay of the lower level. (Default frequency: 500Hz)
		sleep=(ENGINE_SAMPLING_TIME / MICRO_SEC_TO_SEC)-1e6*time_elapsed;
		if (sleep>0) usleep(sleep);
    // low-level controller and LVDM
		tic(0);
		clock_gettime(CLOCK_REALTIME, &lTimeSpec);
		lLoopCurrent = (double)(lTimeSpec.tv_sec) + (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
		if (start==1){
		for (i=0;i<1+detected;i++){
			current = SpeedController(current, ENGINE_SAMPLING_TIME, PHI11, 
															PHI12, PHI21, PHI22, GAMMA1, GAMMA2, FF, K1, K2);	
			
			predecessor = SpeedController(predecessor, ENGINE_SAMPLING_TIME, PHI11, 
																PHI12, PHI21, PHI22, GAMMA1, GAMMA2, FF, K1, K2);
			predecessor_clean = SpeedController(predecessor_clean, ENGINE_SAMPLING_TIME, PHI11, 
																PHI12, PHI21, PHI22, GAMMA1, GAMMA2, FF, K1, K2);
			timestamp=lLoopCurrent;
		}
		detected=0;
		}
		logging_period++;
		clock_gettime(CLOCK_REALTIME, &lTimeSpec);
		lLoopCurrent = (double)(lTimeSpec.tv_sec) + (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
		timestamp=lLoopCurrent;
		if (logging_period == 1 && lLoopCurrent-old_lLoopCurrent>0.004) detected=round((lLoopCurrent-old_lLoopCurrent)/0.002);
		if (logging_period == 10){
			fprintf(pFile, "%lf,%.15f,%.15f,%.15f,%.15f,%.15f,%.15f,%.15f,%d,%lf,%ld,%f,%.15f,%.15f,%.15f,%d,%f,%f,%f,%f\r\n",
			        lLoopCurrent, 													//1
							current.position,												//2 
							current.velocity,												//3
			        current.acceleration,										//4 
							current.jerk, 													//5
							a_des, 																	//6
							((predecessor.position - current.position) - STAND_STILL_DISTANCE - VEHICLE_LENGTH) - time_headway * current.velocity,			//7
							predecessor.velocity - current.velocity,//8
							packetnumber, 													//9
							a_des_v2x_buffer, 											//10
							lLoopCountC, 														//11
							LLC_CL, 																//12
							predecessor_clean.position , 						//13
							predecessor.velocity,  									//14
							predecessor.acceleration , 							//15
							new_message_received, 									//16
							time_elapsed,  													//17
							timestamp,															//18
							time_headway,													  //19
							predecessor.position-current.position); //20
			logging_period=0;
			detected=0;
		}

	  a_actual = current.acceleration;
		//fflush(pFile);
		old_lLoopCurrent=lLoopCurrent;
		time_elapsed=tocq(0);
  }
	fflush(pFile);
  fclose(pFile);
  return NULL;
}
/**
 * @brief Thread where the High-level controller executes
 *
 */
void *high_level_thread() {
	int i=0;
	//Initilization of MPC matrices
	double K_llconstant[2];
	double G_array[225];
	double twoGamaQ_barfi_array[60];
	double twoGamaQ_barpsi_array[225];
	double w_array[640];
	double Mpsi_array[2400];
	double c_array[160];
	double L_array[2700];
	double u_start[15];
	double old_u[15];
	double min_eig;
	double max_eig;
	K_llconstant[0] = K1;
	K_llconstant[1] = K2;
	if (pDev->Config.LLC.LLCRole > 1) {
		compute_matrices(HORIZON, FF, K_llconstant, TIMEHEADWAY, RADAR_INTERVAL, ENGINE_SAMPLING_TIME, G_array, twoGamaQ_barfi_array, twoGamaQ_barpsi_array, L_array, w_array, Mpsi_array, c_array,&min_eig,&max_eig);
		for(i=0;i<15;i++){
			old_u[i]=0;
		}
		i=0;
	}
	//int last_input_used = 0;
  float HLC_Inteval = pDev->Config.LLC.CACCHlc * MILLI_SEC_TO_SEC;
	float time_elapsed=0;
	struct timespec lTimeSpec;
  double lLoopCurrent;
  char logName[] = "UL***.csv";
  sprintf(logName, "UL%d.csv", pDev->Config.LLC.LLCRole);
  printf("Logging into %s\n", logName);
  FILE *pFile = fopen(logName, "w");
  while (1) {
    // Delay of the high-level. (Default frequency in MPC: 10Hz)
    usleep((HLC_Inteval / MICRO_SEC_TO_SEC)-1e6*time_elapsed);
		tic(1);
		if (headway_change==1) {
			headway_change=0;
			compute_matrices(HORIZON, FF, K_llconstant, time_headway, RADAR_INTERVAL, ENGINE_SAMPLING_TIME, G_array, twoGamaQ_barfi_array, twoGamaQ_barpsi_array, L_array, w_array, Mpsi_array, c_array,&min_eig,&max_eig);
		}
		clock_gettime(CLOCK_REALTIME, &lTimeSpec);
	  lLoopCurrent = (double)(lTimeSpec.tv_sec) +
	                 (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
	  fprintf(pFile, "%lf,%d,%lf,%lf,%lf\r\n", lLoopCurrent, new_message_received, timestamp, time_rcv, time_snd);
    if (pDev->Config.LLC.LLCRole > 1) {
			// Follower nodes (FN)
			if (new_message_received && start){
				new_message_received=0;
				mpc(u_start, G_array, twoGamaQ_barfi_array, twoGamaQ_barpsi_array,  w_array,  Mpsi_array,  c_array, L_array,	old_u, current, predecessor, min_eig, max_eig);
				a_des=u_start[0];
				//memcpy(old_u, u_start, sizeof(old_u));
				//last_input_used=0;
			}else{
				//a_des=u_start[last_input_used];
				//last_input_used++;
				a_des=u_start[0];	//Modification until Amr reaches mathematical proof of the other option
			}
			
			current.desiredAcceleration = a_des;
			i++;
/*			if (pDev->Config.LLC.LLCRole == 2 && i>=125 && time_headway<0.5) { //Hard coded time_headway change*/
/*				headway_change=1;*/
/*				time_headway=0.5;*/
/*			}*/
    } else {
      // Leading vehicle (LN)
      // No PCA for leader. Taking the value from look-up table
			a_des = leader_profile(i);
			current.desiredAcceleration = a_des;
      i++;
    }
		time_elapsed=tocq(1);
  }
	fclose(pFile);
  return NULL;
}
/**
 * @brief UDP receiving thread (emulating radar receiver)
 *
 */
void *receivingThreadRadar() {
	    struct timespec lTimeSpec;
    double lLoopCurrent;
  // Initail Ethernet UDP server represneting RADAR
  // create a DGRAM (UDP) socket in the INET6 (IPv6) protocol
  int sock;
  socklen_t clilen;
  sock = socket(PF_INET6, SOCK_DGRAM, 0);
  if (sock < 0) {
    perror("creating socket");
    exit(1);
  }
  /* create server address: this will say where we will be willing to
     accept datagrams from */
  struct sockaddr_in6 server_addr, client_addr;
  /* clear it out */
  memset(&server_addr, 0, sizeof(server_addr));
  /* it is an INET6 address */
  server_addr.sin6_family = AF_INET6;
  /* the client IP address, in network byte order */
  /* in this example we accept datagrams from ANYwhere */
  server_addr.sin6_addr = in6addr_any;
  /* the port we are going to listen on, in network byte order */
  if (pDev->Config.LLC.LLCRole == 2)
    server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT12));
  else if (pDev->Config.LLC.LLCRole == 3)
    server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT23));
  else if (pDev->Config.LLC.LLCRole == 4)
    server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT34));
  /* associate the socket with the address and port */
  if (bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
    perror("bind failed");
    exit(2);
  }
  char time[MESSAGE_BUFSIZE];
  // Parse time sync message
  clilen = sizeof(client_addr);
  if (recvfrom(sock, time, MESSAGE_BUFSIZE, 0, (struct sockaddr *)&client_addr,
               &clilen) < 0) {
    perror("recvfrom failed");
    exit(4);
  } else {

    clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
    char fileName[30];
    sprintf(fileName, "TimeDifference%d-%d.csv", pDev->Config.LLC.LLCRole,
            pDev->Config.LLC.LLCRole - 1);
    FILE *pFile = fopen(fileName, "w");
		time_difference=lLoopCurrent - strtod(time, NULL);
    fprintf(pFile, "%lf\n", time_difference);
    fclose(pFile);

    // send ack
    char ACK[] = "TIMESYNC_ACK";
    if (sendto(sock, ACK, MESSAGE_BUFSIZE, 0, (struct sockaddr *)&client_addr,
               sizeof(client_addr)) < 0) {
      perror("send ACK failed");
      exit(5);
    }
  }

  char buffer[MESSAGE_BUFSIZE];
  int LoopCountRadar = 0;
	int i;
  while (1) {
    clilen = sizeof(client_addr);
    if (recvfrom(sock, buffer, MESSAGE_BUFSIZE, 0,
                 (struct sockaddr *)&client_addr, &clilen) < 0) {
      perror("recvfrom failed");
      exit(4);
		}
    message_decoder(&predecessor,&predecessor_clean, buffer, LoopCountRadar);
		if (pDev->Config.LLC.LLCRole == 2 && BIRD>0 && LoopCountRadar == 250){
			predecessor.position=current.position+BIRD;
		}
		for (i=0;i<ceil((lLoopCurrent-timestamp)/ENGINE_SAMPLING_TIME);i++){
			predecessor = SpeedController(predecessor, ENGINE_SAMPLING_TIME, PHI11, 
																PHI12, PHI21, PHI22, GAMMA1, GAMMA2, FF, K1, K2);
			predecessor_clean = SpeedController(predecessor_clean, ENGINE_SAMPLING_TIME, PHI11, 
																PHI12, PHI21, PHI22, GAMMA1, GAMMA2, FF, K1, K2);
			timestamp=lLoopCurrent;
		}
		gap_filter(&predecessor,&current);	//Use this for filtered, comment for unfiltered
		new_message_received=1;
    LoopCountRadar++;
		clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
		time_rcv=lLoopCurrent;
		//start=1;
  }
  //  fclose (pFile);
  /* the function must return something - NULL will do */
  return NULL;
}
/**
 * @brief UDP sending thread
 *
 */
void *sendingThreadRadar() {
  int sock;
  sock = socket(PF_INET6, SOCK_DGRAM, 0);
  if (sock < 0) {
    perror("creating socket");
    exit(1);
  }
  struct sockaddr_in6 server_addr, client_addr;
  /* clear it out */
  memset(&server_addr, 0, sizeof(server_addr));
  /* it is an INET6 address */
  server_addr.sin6_family = AF_INET6;
  /* the client IP address, in network byte order */
  /* in this example we accept datagrams from ANYwhere */
  if (pDev->Config.LLC.LLCRole == 1)
    inet_pton(AF_INET6, RADAR_DESTINATION_2, &server_addr.sin6_addr);
  else if (pDev->Config.LLC.LLCRole == 2)
    inet_pton(AF_INET6, RADAR_DESTINATION_3, &server_addr.sin6_addr);
  else if (pDev->Config.LLC.LLCRole == 3)
    inet_pton(AF_INET6, RADAR_DESTINATION_4, &server_addr.sin6_addr);
  /* the port we are going to listen on, in network byte order */
  if (pDev->Config.LLC.LLCRole < 4) {
    if (pDev->Config.LLC.LLCRole == 1)
      server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT12));
    else if (pDev->Config.LLC.LLCRole == 2)
      server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT23));
    else if (pDev->Config.LLC.LLCRole == 3)
      server_addr.sin6_port = htons(atoi(RADAR_ETH_PORT34));
    // Time sync
    struct timespec lTimeSpec;
    double lLoopCurrent;
    clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
    char time_sync[MESSAGE_BUFSIZE]; // Time sync sent via Ethernet
    sprintf(time_sync, "%lf", lLoopCurrent);

    if (sendto(sock, time_sync, strlen(time_sync), 0,
               (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
      perror("sendto failed");
      exit(4);
    }
    printf("waiting for a response...\n");
    socklen_t clilen;
    clilen = sizeof(client_addr);
    while (strcmp(time_sync, "TIMESYNC_ACK")) {
      if (recvfrom(sock, time_sync, MESSAGE_BUFSIZE, 0,
                   (struct sockaddr *)&client_addr, &clilen) < 0) {
        perror("recvfrom failed");
        exit(4);
      } else
        printf("ACK received\n");
    }
    // FILE *pFile = fopen ("RADAR.csv","w");
		//float time_elapsed=0;
		//while (start==0 && pDev->Config.LLC.LLCRole > 1) usleep(100);
    while (1) {
#if	NO_MESSAGE_ACC
			usleep(RADAR_INTERVAL / MICRO_SEC_TO_SEC);//-time_elapsed); // 10Hz
#else
		  usleep((RADAR_INTERVAL / MICRO_SEC_TO_SEC)*(10/MESSAGE_RATE));//-time_elapsed); // 10Hz
#endif
			//tic(2);
      char radarInfo[MESSAGE_BUFSIZE]; // Radar info. sent via Ethernet
			clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    	lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
      sprintf (radarInfo, "%.15f\n%.15f\n%.15f\n%.15f\n%d", current.position, current.velocity, current.acceleration,lLoopCurrent,start);
      //sprintf(radarInfo, "%.15f", current.position);
      if (sendto(sock, radarInfo, strlen(radarInfo), 0,
                 (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("sendto failed");
        exit(4);
      }
			//time_elapsed=tocq(2);
			//fprintf(stderr,"message sent");
					clock_gettime(CLOCK_REALTIME, &lTimeSpec);
    lLoopCurrent = (double)(lTimeSpec.tv_sec) +
                   (double)(lTimeSpec.tv_nsec * NANO_SEC_TO_SEC);
		time_snd=lLoopCurrent;
    }
  }

  // fclose (dbg);
  /* the function must return something - NULL will do */
  return NULL;
}
/**
 * @brief Read the acceleration profile for the leader or the radar variance look-up table
 * @param filename  filename of the acceleration profile
 * @return the pointer to the array where the look-up table is saved
 *
 */
double *readSimulationProfile(char *filename) {
  int i = 0;
  double *ReferenceData = NULL;
  FILE *Comm = fopen(filename, "r");
  if (Comm == NULL) {
    Comm = fopen("radar_variance.csv", "r");
    if (Comm != NULL) {
      //fprintf(stderr, "#####FILE NOT FOUND. CONFIGURED AS THE FOLLOWER#####\n");
      char buf[256];
      // Get the rows of the profile first
      while (fgets(buf, sizeof buf, Comm) != NULL) {
        i++;
      }

      ReferenceData = (double *)calloc(i, sizeof(double)); // Allocate memory
      i = 0;
      rewind(Comm); // refresh and go again
      while (fgets(buf, sizeof buf, Comm) != NULL) {
        ReferenceData[i] = atof(buf);
        i++;
      }
      fclose(Comm);
      //simulationLength = i;
    }
  } 
/*		else {*/
/*    char buf[256];*/
/*    // Get the rows of the profile first*/
/*    while (fgets(buf, sizeof buf, Comm) != NULL) {*/
/*      i++;*/
/*    }*/

/*    ReferenceData = (double *)calloc(i, sizeof(double)); // Allocate memory*/
/*    i = 0;*/
/*    rewind(Comm); // refresh and go again*/
/*    while (fgets(buf, sizeof buf, Comm) != NULL) {*/
/*      ReferenceData[i] = atof(buf);*/
/*      i++;*/
/*    }*/
/*    fclose(Comm);*/
/*    simulationLength = i;*/
/*  }*/
  return ReferenceData;
}
/**
 * @brief Virtual radar which converts the state of the predecessor into
      inter-vehicle distance and relative velocity
 * @param AccRadar  radar measurement buffer that contains the distance and relative velocity
 * @param data  new position information obtained from UDP
 * @param count  cycle counts since started
 *
 */
void message_decoder(struct car_state *car, struct car_state *car_clean, char *data, int count) {
#if NO_MESSAGE_ACC
	static int counter=10;
	const int condition=round(10/MESSAGE_RATE);
#endif
	double pos = strtod(strsep(&data,"\n"), NULL);
	double vel = strtod(strsep(&data,"\n"), NULL);
	double acc = strtod(strsep(&data,"\n"), NULL);
	timestamp=strtod(strsep(&data,"\n"), NULL);

	if (start==0){
		start=strtod(strsep(&data,"\n"), NULL);
	}
	if (start==1){
		car->position = pos + profileData[rand() % 1000]; //(Un)comment to (add) remove radar noise, originally count in place of rand
#if NO_MESSAGE_ACC
		if (counter>=condition){
			car->velocity = vel;
			car->acceleration = acc;
			//fprintf(stderr,"Counter: %d, Acc: %f",counter,acc);
			car->desiredAcceleration = car->acceleration; //To predict the behaviour of the predecessor we assume that the current acc. is also the des. acc.
			counter=1;
		}else{
			//Noise = +-0.1km/h ~ +-0.028 ms. rand()%1000 gives a number between 0 and 1000. Divided by 17857 = 0 to 0.056. that - 0.028 = +- 0.028
			car->velocity = vel+(rand()%1000)/17857-0.028;
			counter++;
		}
#else
		car->velocity = vel;
		car->acceleration = acc;
		car->desiredAcceleration = car->acceleration; //To predict the behaviour of the predecessor we assume that the current acc. is also the des. acc.
#endif
		//Car_clean is only used for logging and for visualization and debugging in MATLAB
		car_clean->position = pos;		
		car_clean->velocity = vel;
		car_clean->acceleration = acc;
		car_clean->desiredAcceleration = car->acceleration; //To predict the behaviour of the predecessor we assume that the current acc. is also the des. acc.
	}
}
/**
 * @brief Low Level Controller + Longitudinal Vehicle Dynamics Model (LVDM)
 * @param currentState   vehicle state buffer that stores the current state
 * @param a_desired  desired acceleration for achieve the control goal
 * @param dt_s  execution period of the actuator
 * @param tau_s  engine lag time constant in seconds
 * @return the vehicle's next state
 *
 */
struct car_state SpeedController(struct car_state currentState,
                                 double h_lower, double phi11, double phi12, 
																 double phi21, double phi22, double gamma1, double gamma2, 
																 double f, double k1, double k2) {
	
	double a_des, p_old, v_old, a_old, j_old, p_new, v_new, a_new, j_new;
	struct car_state output;
	a_des = currentState.desiredAcceleration;
	p_old = currentState.position;
	v_old = currentState.velocity;
	a_old = currentState.acceleration;
	j_old = currentState.jerk;
#if SATURATE_ACTUATOR
	if (a_des>3) a_des=3;			//Saturate acceleration
	if (a_des<-3) a_des=-3;		//Saturate acceleration
#endif
	double u = k1 * a_old + k2 		* j_old + f * a_des;
	a_new = phi11 * a_old + phi21 * j_old + gamma1 * u; 
	j_new = phi12 * a_old + phi22 * j_old + gamma2 * u;
	v_new = v_old + a_old * h_lower + ((h_lower*h_lower)/2) * j_old;
	p_new = p_old + v_old * h_lower + ((h_lower*h_lower)/2) * a_old; //+ h_lower^3 / 6 * j_old?
	//if (v_new<0) v_new=0;
	output.position 		= p_new;
	output.velocity 		= v_new;
	output.acceleration = a_new;
	output.jerk 				= j_new;

	return output;
}

void print_car_state(char* msg, struct car_state car){
	fprintf(stderr, "%sPosition: %f\nVelocity: %f\nAcceleration: %f\nJerk: %f\nDesired acceleration: %f\n\n", msg, car.position, car.velocity, car.acceleration, car.jerk, car.desiredAcceleration);
}

void compute_matrices(double horizon, double feed_forward, const double k1[2], double tauh, 
											double h_upper, double h_lower, double G_array[225], double twoGamaQ_barfi_array[60], 
											double twoGamaQ_barpsi_array[225], double L_array[2700], double w_array[640],	
											double Mpsi_array[2400], double c_array[160], double *min_eig, double* max_eig){

	emxArray_real_T *G;
	emxArray_real_T *twoGamaQ_barfi;
	emxArray_real_T *twoGamaQ_barpsi;
	emxArray_real_T *L;
	emxArray_real_T *w;
	emxArray_real_T *Mpsi;
	emxArray_real_T *c;
	emxInitArray_real_T(&G, 2);
	emxInitArray_real_T(&twoGamaQ_barfi, 2);
	emxInitArray_real_T(&twoGamaQ_barpsi, 2);
	emxInitArray_real_T(&L, 2);
	emxInitArray_real_T(&w, 2);
	emxInitArray_real_T(&Mpsi, 2);
	emxInitArray_real_T(&c, 1);
	int i;
	matrix_init(horizon, feed_forward, k1, tauh, h_upper, h_lower, G, twoGamaQ_barfi, twoGamaQ_barpsi, L, w, Mpsi, c);
		//FORMAT CONVERSION
	for(i=0;i<60;i++){
		twoGamaQ_barfi_array[i]=*(twoGamaQ_barfi->data+i);
	}
 	for(i=0;i<225;i++){
		twoGamaQ_barpsi_array[i]=*(twoGamaQ_barpsi->data+i);
	}
	for(i=0;i<640;i++){
		w_array[i]=*(w->data+i);
	}
	for(i=0;i<2400;i++){
		Mpsi_array[i]=*(Mpsi->data+i);
	}
	for(i=0;i<160;i++){
		c_array[i]=*(c->data+i);
	}
	for(i=0;i<2700;i++){
		L_array[i]=*(L->data+i);
	}
	for(i=0;i<225;i++){
		G_array[i]=*(G->data+i);
	}
	eigenvalues(G_array,min_eig,max_eig);
}

void gap_filter(struct car_state *pred, struct car_state *foll){
	static double pre9 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call
	static double pre8 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call	
	static double pre7 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call	
	static double pre6 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call	
	static double pre5 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call	
	static double pre4 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call	
	static double pre3 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call
	static double pre2 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call
	static double pre1 = STAND_STILL_DISTANCE+VEHICLE_LENGTH+INITIAL_SPEED*TIMEHEADWAY; //Static variable keeps the last value for the next function call
	static double aux; //to help restoring wrong rejections
	static int last_rejected; //to avoid 2 succesive rejections

	double gap_raw = pred->position-foll->position;
/*	if (abs(gap_raw-pre1)>4 && last_rejected==0){ */
/*		aux=gap_raw;*/
/*		gap_raw=pre1;*/
/*		last_rejected=1;*/
/*	}else if (abs(gap_raw-pre1)>4){ //last one was erroneously rejected*/
/*		pre1=aux;*/
/*		last_rejected=0;*/
/*	}else{*/
/*		last_rejected=0;*/
/*	}*/
	pred->position = foll->position + (pre9 + pre8 + pre7 + pre6 + pre5 + pre4 + pre3+ pre2 + pre1 + gap_raw)/10; //Floating window average, window size=10
	pre9=pre8;	
	pre8=pre7;
	pre7=pre6;	
	pre6=pre5;		
	pre5=pre4;	
	pre4=pre3;	
	pre3=pre2;	
	pre2=pre1;
	pre1=gap_raw;
	
	}


