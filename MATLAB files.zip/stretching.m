slope1=a1(length(a1),1)/length(a1);
slope2=a2(length(a2),1)/length(a2);
slope3=a3(length(a3),1)/length(a3);
slope4=a4(length(a4),1)/length(a4);