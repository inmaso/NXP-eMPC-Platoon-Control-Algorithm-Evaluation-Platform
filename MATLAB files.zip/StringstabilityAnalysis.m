close all;
clear;

veh1 = csvread('Log1.csv');
if veh1(1,1)~=0 % If the log has been processed
    [veh1,veh2,veh3,veh4] = LogPreprocessing;
else
    veh2 = csvread('Log2.csv');
    veh3 = csvread('Log3.csv');
    veh4 = csvread('Log4.csv');
end

ascend_veh1 = veh1(1:1800,:);
descend_veh1 = veh1(1801:length(veh1),:);

ascend_veh2 = veh2(1:1800,:);
descend_veh2 = veh2(1801:length(veh2),:);

ascend_veh3 = veh3(1:1800,:);
descend_veh3 = veh3(1801:length(veh3),:);

ascend_veh4 = veh4(1:1800,:);
descend_veh4 = veh4(1801:length(veh4),:);

if checkPartition(ascend_veh1,ascend_veh2,ascend_veh3,ascend_veh4)
    % Check the descending part
    if checkPartition(descend_veh1,descend_veh2,descend_veh3,descend_veh4)
        disp('String stable!');
    else
        disp('String unstable!');
    end
else
    disp('String unstable!');
end

%% ReadConfig
% filetext = fileread('platoontest.conf');
% filetext(1:4)=[];
% fileID = fopen('configuration.csv','w');
% fprintf(fileID,'%s',filetext);
% fclose(fileID);
% conf = csvread('configuration.csv');
% TimeHeadway = conf(9);

% figure
% plot (veh1(:,1),veh1(:,3));
% title('Reference Velocity')
% ylabel('Velocity (m/s)')
% xlabel('Time (s)')
% legend('Vehicle 1 (Leader)')
% xlim([0 40])
% ylim([0 25])
% 
% figure
% plot (veh1(:,1),veh1(:,3));
% hold on
% plot (veh2(:,1),veh2(:,3));
% hold on
% plot (veh3(:,1),veh3(:,3));
% hold on
% plot (veh4(:,1),veh4(:,3));
% % title('Velocity response (from the device log)')
% ylabel('Velocity (m/s)')
% xlabel('Time (s)')
% legend('Vehicle 1 (Leader)', 'Vehicle 2','Vehicle 3','Vehicle 4')
% xlim([0 40])
% ylim([0 25])

%%
conf = csvread('configuration.csv');
TimeHeadway = conf(9);
actual_gap12 = veh1(:,2)-veh2(:,2)-4;
desired_gap12 = 2+veh2(:,3)*TimeHeadway;
error12 = actual_gap12-desired_gap12;
actual_gap23 = veh2(:,2)-veh3(:,2)-4;
desired_gap23 = 2+veh3(:,3)*TimeHeadway;
error23 = actual_gap23-desired_gap23;
actual_gap34 = veh3(:,2)-veh4(:,2)-4;
% figure
% plot (veh1(:,1), actual_gap12);
% hold on
% plot (veh2(:,1), actual_gap23);
% hold on
% plot (veh3(:,1), actual_gap34);
% hold on
% plot (veh1(:,1), (actual_gap12+actual_gap23+actual_gap34)/3);
% title('Inter-vehicle distance')
% ylabel('Distance (m)')
% xlabel('Time (s)')
% legend('q1-q2', 'q2-q3', 'q3-q4', 'Average')
% ylim([0 25])
%%
% fig1 = figure('Units','pixels','Position',[0 0 1920 500]);
% subplot(1,4,1);
% 
% % plot (veh1(:,1),actual_gap12);
% % hold on
% plot (veh2(:,1),desired_gap12);
% hold on
% plot (veh2(:,1),veh2(:,6));
% 
% title('1-2 Actual Gap vs. Desired Gap (from devices logs)')
% ylabel('Distance (m)')
% xlabel('Time (s)')
% legend('Desired', 'Actual')
% % ylim([1.5 8])
% xlim([0 40])
% subplot(1,4,2);
%  
% % plot (veh2(:,1),actual_gap23);
% % hold on
% plot (veh3(:,1),desired_gap23);
% hold on
% plot (veh3(:,1),veh3(:,6));
% title('2-3 Actual Gap vs. Desired Gap (from devices logs)')
% ylabel('Distance (m)')
% xlabel('Time (s)')
% legend('Desired', 'Actual')
% % ylim([-5 5])
% % ylim([1.5 8])
% xlim([0 40])
% 
% subplot(1,4,3);
% plot (veh1(:,1),veh1(:,3));
% hold on
% plot (veh2(:,1),veh2(:,3));
% hold on
% plot (veh3(:,1),veh3(:,3));
% hold on
% plot (veh4(:,1),veh4(:,3));
% title('Actual velocity from devices logs')
% ylabel('Velocity (m/s)')
% xlabel('Time (s)')
% legend('Actual velocity vehicle 1', 'Actual velocity vehicle 2','Actual velocity vehicle 3','Actual velocity vehicle 4')
% xlim([0 40])
% % 
% subplot(1,4,4);
% plot (veh1(:,1),veh1(:,4));
% hold on
% plot (veh2(:,1),veh2(:,4));
% hold on
% plot (veh3(:,1),veh3(:,4));
% title('Actual accelerations from devices logs')
% ylabel('Acceleration (m/s^2)')
% xlabel('Time (s)')
% legend('Actual acceleration vehicle 1', 'Actual acceleration vehicle 2', 'Actual acceleration vehicle 3', 'Actual acceleration vehicle 4')
% xlim([0 40])