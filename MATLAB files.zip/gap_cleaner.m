function [clean]=gap_cleaner(a)
int(1,:)=a(1,:);
j=2;
for i=3:length(a)
    if a(i-1,16)==1 && a(i-2,16)==0
        int(j,:)=a(i,:);
        j=j+1;
    end
end
clean=[int(:,1),int(:,18),int(:,13)-int(:,2),int(:,13),int(:,2)];
clean(1,1)=0;
end