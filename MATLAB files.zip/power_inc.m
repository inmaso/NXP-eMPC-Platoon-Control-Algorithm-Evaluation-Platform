function [power,cd]=power_inc(other,target,position)
%% Vehicle dependent parameters
%Toyota Prius
    m=1450; %Mass
    af=7.28472; %Frontal Area
    cd_base=0.26; %Standalone drag coefficient
    R=0.015; %Rolling resistance parameter
%Generic truck
%     m=36000; %Mass 4 axle truck (steer, drive and 2 trailer)(https://www.jpisla.es/resources/Download+JPIsla+20130106+Pesos+maximos+de+los+camiones+comparativa+paises.pdf)
%     af=10.07; %https://www.camionactualidad.es/noticias-camiones/pruebas-test-camiones/item/757-iveco-stralis-as440s56t-p-euro-5-el-poderoso-caballero-negro
%     cd_base=0.6; %Standalone drag coefficient (0.544-0.9)
%     R=0.008; %Rolling resistance parameter (0.005 to 0.01)
%% External factors    
    wind=0; %No wind
    inclination=0; %No inclination
    rho=1.225; %Air density at sea level
    g=9.81; %Gravity
%% Computation    
    %Attenuation model based on the Rational 1 num and 1 den model
    if position==1
       p1 = -10.84;
       p2 = 171.4;
       q1 = 11.53;
    elseif position==2 || position==-1
       p1 = 19.12;
       p2 = 408.8;  
       q1 = 6.425;
    else
        p1 = 28.89;
        p2 = 420.7;
        q1 = 6.034;
    end
    if position==-1
       gap=50;
    else
        gap=abs(other-target(2));
    end
    attenuation = (p1*gap + p2) / (gap + q1);
    if attenuation<0
        attenuation=0;
    end
    attenuation=attenuation/100; %change percentage to portion
    
    if position ~= 0
        cd=cd_base*(1-attenuation);
    else
        cd=cd_base; %No attenuation case for benefit analysis
    end
    Force=m*target(4)+0.5*rho*cd*af*(target(3)-wind)^2+R*m*g*cos(inclination)+m*g*sin(inclination);
    power=Force*target(3);
end