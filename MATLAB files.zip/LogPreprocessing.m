function [a1,a2,a3,a4] = LogPreprocessing %Basic low-level controller
a1 = csvread('Log1.csv');
a2 = csvread('Log2.csv');
a3 = csvread('Log3.csv');
a4 = csvread('Log4.csv');
diff2to1 = csvread('TimeDifference2-1.csv');
diff3to2 = csvread('TimeDifference3-2.csv');
diff4to3 = csvread('TimeDifference4-3.csv');
%% ReadConfig
filetext = fileread('platoontest.conf');
filetext(1:4)=[];
fileID = fopen('configuration.csv','w');
fprintf(fileID,'%s',filetext);
fclose(fileID);
conf = csvread('configuration.csv');
TimeHeadway = conf(9);

%% Eliminate useless data
if a1(1,1)~=0
    a1(:,1)=a1(:,1);
    a2(:,1)=a2(:,1)-diff2to1; %- 1521000000;
    a3(:,1)=a3(:,1)-diff3to2-diff2to1; %- 1521000000; %+ 1.3;
    a4(:,1)=a4(:,1)-diff4to3-diff3to2-diff2to1; %- 1521000000; %+ 1.3;
    t0 = max([a1(1) a2(1) a3(1)]);%- 1521000000

    while abs (a1(1,1)- t0) >=0.011
        a1(1,:)=[];
    end
    while abs (a2(1,1)- t0) >=0.011
        a2(1,:)=[];
    end
    while abs (a3(1,1)- t0) >=0.011
        a3(1,:)=[];
    end
    while abs (a4(1,1)- t0) >=0.011
        a4(1,:)=[];
    end
    % i=1;
    % while abs (a1(i,1)- t0) >=0.011
    %     a1(i,:)=[];
    %     i=i+1;
    % end
    % j=1;
    % while abs (a2(j,1)- t0) >=0.011
    %     a2(j,:)=[];
    %     j=j+1;
    % end
    % k=1;
    % while abs (a3(k,1)- t0) >=0.011
    %     a3(k,:)=[];
    %     k=k+1;
    % end
    % Clear the last row
    a1(length(a1),:)=[];
    a2(length(a2),:)=[];
    a3(length(a3),:)=[];
    a4(length(a4),:)=[];
    % Aligning
    n = min([length(a1) length(a2) length(a3) length(a4)]);
    a1 = a1(1:n,:);   
    a2 = a2(1:n,:);
    a3 = a3(1:n,:);
    a4 = a4(1:n,:);

    a1(:,1) = a1(:,1) - t0;
    a2(:,1) = a2(:,1) - t0;
    a3(:,1) = a3(:,1) - t0;
    a4(:,1) = a4(:,1) - t0;
end;
%%
actual_gap12 = a1(:,2)-a2(:,2)-4;
desired_gap12 = 2+a2(:,3)*TimeHeadway;
error12 = actual_gap12-desired_gap12;
actual_gap23 = a2(:,2)-a3(:,2)-4;
desired_gap23 = 2+a3(:,3)*TimeHeadway;
error23 = actual_gap23-desired_gap23;
%%
fig1 = figure('Units','pixels','Position',[0 0 1920 500]);
subplot(1,4,1);

% plot (a1(:,1),actual_gap12);
% hold on
plot (a2(:,1),desired_gap12);
hold on
plot (a2(:,1),a2(:,6));

title('1-2 Actual Gap vs. Desired Gap (from devices logs)')
ylabel('Distance (m)')
xlabel('Time (s)')
legend('Desired', 'Actual')
% ylim([1.5 8])
xlim([0 40])
subplot(1,4,2);
 
% plot (a2(:,1),actual_gap23);
% hold on
plot (a3(:,1),desired_gap23);
hold on
plot (a3(:,1),a3(:,6));
title('2-3 Actual Gap vs. Desired Gap (from devices logs)')
ylabel('Distance (m)')
xlabel('Time (s)')
legend('Desired', 'Actual')
% ylim([-5 5])
% ylim([1.5 8])
xlim([0 40])

subplot(1,4,3);
plot (a1(:,1),a1(:,3));
hold on
plot (a2(:,1),a2(:,3));
hold on
plot (a3(:,1),a3(:,3));
hold on
plot (a4(:,1),a4(:,3));
title('Actual velocity from devices logs')
ylabel('Velocity (m/s)')
xlabel('Time (s)')
legend('Actual velocity vehicle 1', 'Actual velocity vehicle 2','Actual velocity vehicle 3','Actual velocity vehicle 4')
xlim([0 40])

subplot(1,4,4);
plot (a1(:,1),a1(:,4));
hold on
plot (a2(:,1),a2(:,4));
hold on
plot (a3(:,1),a3(:,4));
title('Actual accelerations from devices logs')
ylabel('Acceleration (m/s^2)')
xlabel('Time (s)')
legend('Actual acceleration vehicle 1', 'Actual acceleration vehicle 2', 'Actual acceleration vehicle 3', 'Actual acceleration vehicle 4')
xlim([0 40])
folderName = [num2str(1000/conf(5)) 'Hz, h=' num2str(TimeHeadway) 's_' num2str(conf(7))];
mkdir (folderName)
filename = [num2str(1000/conf(5)) 'Hz, h=' num2str(TimeHeadway) 's_' num2str(conf(7)) '.png'];
pathname = fullfile(folderName, filename);
print(fig1,pathname,'-dpng')
% figure
% da1 = diff(a1(:,4));
% da2 = diff(a2(:,4));
% da3 = diff(a3(:,4));
% i = 1:length(da1);
% plot (i,da1);
% hold on
% plot (i,da2);
% hold on
% plot (i,da3);
% title('Delta accelerations from devices logs')
% ylabel('Delta Acceleration (m/s^3)')
% xlabel('Time (s)')
% legend('Delta acceleration vehicle 1', 'Delta acceleration vehicle 2', 'Delta acceleration vehicle 3')
% ylim([-0.35 0.35])


% fig2=figure('Units','pixels','Position',[0 0 1920 1080]);
% plot (a1(:,1),a1(:,3));
% hold on
% plot (a2(:,1),a2(:,3));
% hold on
% plot (a3(:,1),a3(:,3));
% hold on
% plot (a4(:,1),a4(:,3));
% title('Actual velocity from devices logs')
% ylabel('Velocity (m/s)')
% xlabel('Time (s)')
% legend('Actual velocity vehicle 1', 'Actual velocity vehicle 2','Actual velocity vehicle 3', 'Actual velocity vehicle 4')
% xlim([5 30])
% ylim([4 18])
% % set(gcf,'Units','pixels','Position',[10 10 1920 1080]);
% filename = ['ResponseofVelocity('  num2str(1000/conf(5)) 'Hz, h=' num2str(TimeHeadway) 's)_' num2str(conf(7)) '.png'];
% pathname = fullfile(folderName, filename);
% print(fig2,pathname,'-dpng')
%% saving data
pathname = fullfile(folderName, 'log1.csv');
csvwrite(pathname,a1);
pathname = fullfile(folderName, 'log2.csv');
csvwrite(pathname,a2);
pathname = fullfile(folderName, 'log3.csv');
csvwrite(pathname,a3);
pathname = fullfile(folderName, 'log4.csv');
csvwrite(pathname,a4);
end