function [Force]=resistance(speed,gap,mass)
acc=0;
%% Vehicle dependent parameters
%Toyota Prius
%     m=mass; %Mass
%     af=7.28472; %Frontal Area
%     cd_base=0.26; %Standalone drag coefficient
%     R=0.015; %Rolling resistance parameter
%Generic truck
    m=mass; %Mass 4 axle truck (steer, drive and 2 trailer)(https://www.jpisla.es/resources/Download+JPIsla+20130106+Pesos+maximos+de+los+camiones+comparativa+paises.pdf)
    af=10.07; %https://www.camionactualidad.es/noticias-camiones/pruebas-test-camiones/item/757-iveco-stralis-as440s56t-p-euro-5-el-poderoso-caballero-negro
    cd_base=0.6; %Standalone drag coefficient (0.544-0.9)
    R=0.008; %Rolling resistance parameter (0.005 to 0.01)
%% External factors    
    wind=10; %No wind
    inclination=0; %No inclination
    rho=1.225; %Air density at sea level
    g=9.81; %Gravity
%% Computation    
    %Attenuation model based on the Rational 1 num and 1 den model
       p1 = 19.12;
       p2 = 408.8;  
       q1 = 6.425;

    attenuation = (p1*gap + p2) / (gap + q1);
    if attenuation<0
        attenuation=0;
    end
    attenuation=attenuation/100; %change percentage to portion

    cd=cd_base*(1-attenuation);

    Force=m*acc+0.5*rho*cd*af*(speed-wind)^2+R*m*g*cos(inclination)+m*g*sin(inclination);
    power=Force*speed;
end