close all
limit_x_to=70;
%% Amr graphs - ACCELERATION
figure('Units','pixels','Position',[0 0 1000 720]);
plot (a1(:,1),a1(:,4),'LineWidth',3);
hold on
plot (a2(:,1),a2(:,4),'LineWidth',3);
hold on
plot (a3(:,1),a3(:,4),'LineWidth',3);
hold on
plot (a4(:,1),a4(:,4),'LineWidth',3);
grid on

ylabel('Acceleration (m/s^2)','FontSize',30)

xlabel('Time (s)','FontSize',30)

legend({'Veh0','Veh1','Veh2','Veh3'},'FontSize',20)

set(gca,'fontsize',30, 'FontName', 'Times New Roman')
%title('Actual accelerations from devices logs')
%ylabel('Acceleration (m/s^2)')
%xlabel('Time (s)')
%legend('Actual acceleration vehicle 1', 'Actual acceleration vehicle 2', 'Actual acceleration vehicle 3', 'Actual acceleration vehicle 4')
if (limit_x)
    xlim([0 limit_x_to])
end
axes('position',[.65 .175 .25 .25])
box on
%i=a1(:,1)>20 & a1(:,1)<25
plot(a1(:,1),a1(:,4),a2(:,1),a2(:,4),a3(:,1),a3(:,4),a4(:,1),a4(:,4),'LineWidth',3)
axis tight

%% Extra graphs - VELOCITY ERROR EXT
figure('Units','pixels','Position',[0 0 1000 720]);
plot (a2(:,1),errorv12, 'LineWidth',3);
hold on
plot (a3(:,1),errorv23, 'LineWidth',3);
hold on
plot (a4(:,1),errorv34, 'LineWidth',3);
grid on

legend({'between veh0 and veh1 ','between veh1 and veh2 ','between veh2 and veh3'},'FontSize',30);

ylabel('Velocity error \Delta v (m/s)','FontSize',30)

xlabel('Time (s)','FontSize',30);

set(gca,'fontsize',30, 'FontName', 'Times New Roman')
if (limit_x)
    xlim([0 limit_x_to])
end

%% Extra graphs - GAP ERROR INT FILTERED
figure('Units','pixels','Position',[0 0 1000 720]);
plot (a2(:,1),error12, 'LineWidth',3);
hold on
plot (a3(:,1),error23, 'LineWidth',3);
hold on
plot (a4(:,1),error34, 'LineWidth',3);
% hold on
% y = 0;
% line([0,limit_x_to],[y,y])
ylabel('Position error \Delta d (m)','FontSize',30)

xlabel('Time (s)','FontSize',30); grid on

legend({'between veh0 and veh1 ','between veh1 and veh2 ', 'between veh2 and veh3'},'FontSize',30)

set(gca,'fontsize',40, 'FontName', 'Times New Roman')
 if (limit_x)
    xlim([0 limit_x_to])
end
 %% EXTRA GRAPHS - VELOCITY EXT
figure('Units','pixels','Position',[0 0 1000 720]);
plot (a1(:,1),a1(:,3)*3.6, 'LineWidth',3);
set(gca,'fontsize',30);
hold on
plot (a2(:,1),a2(:,3)*3.6, 'LineWidth',3);set(gca,'fontsize',30);
hold on
plot (a3(:,1),a3(:,3)*3.6, 'LineWidth',3);set(gca,'fontsize',30);
hold on
plot (a4(:,1),a4(:,3)*3.6, 'LineWidth',3);set(gca,'fontsize',30);
grid on;
legend({'veh0','veh1','veh2','veh3'},'FontSize',20)

set(gca,'fontsize',30, 'FontName', 'Times New Roman')

ylabel('Velocity (km/h)','FontSize',30)

xlabel('Time (s)','FontSize',30)
if (limit_x)
    xlim([0 limit_x_to])
end
% axes('position',[.65 .175 .25 .25])
% box on
% plot(a1(:,1),a1(:,3)*3.6,a2(:,1),a2(:,3)*3.6,a3(:,1),a3(:,3)*3.6,a4(:,1),a4(:,3)*3.6,'LineWidth',3)
% axis tight
