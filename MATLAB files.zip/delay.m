function delay(var)
%close all;
x=1;
pos(1)=0;
exit=0;
i=1;
while exit==0
    if var(i,16)==1
        delay(x)=var(i,1)-var(i,18);
        pos(x)=i;
        x=x+1;
        while var(i,16)==1
            i=i+1;
        end
    end
    i=i+1;
    if i>length(var)
        exit=1;
    end
end
pos=pos/50;
plot(pos,delay);
end