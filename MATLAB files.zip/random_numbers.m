clear all
a(1000,1)=0;
num=1000;
for i=1:num
    a(i,1)=normrnd(0,0.15);
end
csvwrite('radar_variance_soft.csv',a);
b=sort(abs(a));
for i=1:num
    if b(i)>0.25
        (num-i)*100/num
        break
    end
end
for i=1:num
    if b(i)>0.10
        (num-i)*100/num
        break
    end
end
