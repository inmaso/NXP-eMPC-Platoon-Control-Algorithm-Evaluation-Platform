function [b]=plot_slope(a)
for i=2:length(a)
    b(i-1)=a(i)-a(i-1);
end
