function [energy_in, energy_waste] = energy_in(p)
    energy_in = 0;
    energy_waste = 0;
    for i=1:1:length(p)
        if p(i)>0
           energy_in = energy_in + p(i)*0.02; %Logging rate is 20msec
        else
           energy_waste = energy_waste + p(i)*0.02; %Logging rate is 20msec
        end
    end
end