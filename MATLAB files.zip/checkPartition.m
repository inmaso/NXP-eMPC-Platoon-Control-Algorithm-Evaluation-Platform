function stringstable = checkPartition(veh1,veh2,veh3,veh4)
    S2 = stepinfo(veh2(:,3),veh2(:,1),veh1(length(veh1),3));
    S3 = stepinfo(veh3(:,3),veh3(:,1),veh1(length(veh1),3));
    S4 = stepinfo(veh4(:,3),veh4(:,1),veh1(length(veh1),3));
%     disp(S2.Overshoot);
%     disp(S3.Overshoot);
%     disp(S4.Overshoot);
    error32 = (S3.Overshoot-S2.Overshoot)/veh1(length(veh1),3);
    error43 = (S4.Overshoot-S3.Overshoot)/veh1(length(veh1),3);
%     disp(error32);
%     disp(error43);
    
%     v2tov1 = veh1(:,3)-veh2(:,3);
%     v3tov2 = veh2(:,3)-veh3(:,3);
%     v4tov3 = veh3(:,3)-veh4(:,3);
%     sum21 = sum(v2tov1);
%     sum32 = sum(v3tov2);
%     sum43 = sum(v4tov3);
%     
%     R_diff1 = (sum32-sum21)/sum32;
%     R_diff2 = (sum43-sum32)/sum43;
%     figure
%     plot(veh1(:,1),v2tov1)
%     hold on
%     plot(veh1(:,1),v3tov2)
%     hold on
%     plot(veh1(:,1),v4tov3)
%     xlim([0 40])
%     if R_diff1<0.02 && R_diff2<0.02
%         disp('String stable!');
%         stringstable = true;
%     else
%         disp('String unstable!');
%         stringstable = false;
%     end
    %%
    
    if error32<=0.01 && error43<=0.01
        stringstable = true;
    else
        stringstable = false;
    end
end