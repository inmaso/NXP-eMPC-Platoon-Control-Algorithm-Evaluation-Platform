function [final]=filler(x,y)
x=round(x*10000)/10000;
finalx(1)=x(1);
finaly(1)=y(1);
for i=2:length(x)
    distance=x(i)-x(i-1);
    slope=(y(i)-y(i-1))/distance;
    newx=x(i-1):0.0001:x(i);
    newy=y(i-1)+slope*(newx-x(i-1));
    finalx=[finalx;newx'];
    finaly=[finaly;newy'];
end
final=[finalx,finaly];
end